#!/usr/bin/env node
// ============================================================================
// preparar.js — paso PREVIO de /actualizar-dashboard (determinista, sin IA)
// ----------------------------------------------------------------------------
// 1) Localiza el datos.js del proyecto.
// 2) Hace copia de seguridad con marca de tiempo.
// 3) Guarda una "foto antes" (fecha + recuento por sección) para que
//    verificar.js detecte después si se perdió algo.
// 4) Imprime un resumen legible.
// ============================================================================
const fs = require('fs');
const path = require('path');
const { findDatos, loadDatos, snapshot, backupsDir, snapshotPath } = require('./lib');

function stamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

function main() {
  const datosPath = findDatos();
  if (!datosPath) {
    console.error('ERROR: no encuentro BUILD/dashboard/datos.js desde aquí.');
    console.error('Ejecuta el comando desde la carpeta del proyecto (la que contiene BUILD/dashboard).');
    process.exit(1);
  }

  let datos;
  try {
    datos = loadDatos(datosPath);
  } catch (e) {
    console.error('ERROR: el datos.js actual no es válido: ' + e.message);
    process.exit(1);
  }

  // Copia de seguridad
  const dir = backupsDir(datosPath);
  fs.mkdirSync(dir, { recursive: true });
  const backup = path.join(dir, `datos-${stamp()}.js`);
  fs.copyFileSync(datosPath, backup);

  // Foto antes
  const snap = snapshot(datos);
  fs.writeFileSync(snapshotPath(datosPath), JSON.stringify(snap, null, 2), 'utf8');

  // Resumen
  console.log('Dashboard:   ' + datosPath);
  console.log('Backup:      ' + backup);
  console.log('actualizado: ' + (snap.actualizado || '(sin fecha)'));
  console.log('Secciones (recuento antes):');
  for (const k of Object.keys(snap.counts).sort()) {
    console.log('  ' + k.padEnd(34) + snap.counts[k]);
  }
  console.log('\nListo. Edita datos.js y luego ejecuta: node scripts/verificar.js');
}

main();
