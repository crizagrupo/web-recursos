# AGENTS.md — Mapa del harness para agentes de IA

> Motor del harness — vive en `~/.claude/harness/` y es heredado por todos los proyectos.
> El estado del proyecto (backlog, specs, progress) vive en `harness/` dentro del proyecto.
> Lee solo lo que necesites, cuando lo necesites.

---

## 1. Dos modos de trabajo

**Modo operación (por defecto).** Preguntas de negocio, consultas, operación diaria →
responde directamente usando las capas del proyecto. No hace falta el flujo de construcción.

**Modo construcción.** Cuando se pide **construir/automatizar algo nuevo** → actúa como
`leader` (agente global en `~/.claude/agents/`) y sigue el flujo SDD de §4.

> El nivel negocio (global) **no construye**: no tiene cola propia. Toda construcción
> ocurre **dentro de un proyecto**, sobre el `harness/` de ese proyecto.

## 2. Las capas del proyecto (contexto)

| Capa | Carpeta | Para qué |
|------|---------|----------|
| 1 Context | `CONTEXT/` | Quién es el negocio. Leerlo antes de especificar. |
| 2 Data | `DATA/` | Datos e integraciones. |
| 3 Intelligence | `INTELLIGENCE/` | Reuniones, briefs, seguimientos. |
| 4 Automation | `AUTOMATION/` | Dónde se construyen las automatizaciones. |
| 5 Build | `BUILD/` | Dónde se construyen las herramientas. |

## 3. Mapa del harness

| Archivo / carpeta | Qué contiene | Cuándo leerlo |
|-------------------|--------------|---------------|
| `harness/build_backlog.json` | Cola de módulos con su estado | Siempre, al empezar una construcción |
| `harness/progress/current.md` | Estado de la sesión activa | Siempre, al empezar |
| `harness/progress/history.md` | Bitácora de sesiones | Si necesitas contexto histórico |
| `harness/specs/<modulo>/` | requirements + design + tasks | Antes de construir ese módulo |
| `~/.claude/harness/docs/architecture.md` | Qué es "buen trabajo" | Antes de construir |
| `~/.claude/harness/docs/conventions.md` | Nombres, ubicaciones, estilo | Antes de construir |
| `~/.claude/harness/docs/specs.md` | Proceso SDD | Antes de redactar o leer un spec |
| `~/.claude/harness/docs/verification.md` | Cómo verificar un módulo | Antes de declarar `done` |
| `~/.claude/harness/CHECKPOINTS.md` | Criterios de "estado final correcto" | Para auto-evaluarte |
| `harness/verify.ps1` | Verificación de invariantes | Al empezar y al cerrar |

## 4. Flujo de construcción (SDD)

```
pending → [spec_author] → spec_ready → ⏸ APROBACIÓN → in_progress → [builder → reviewer] → done
```

1. El `leader` detecta el primer módulo `pending` en `harness/build_backlog.json`.
2. (Opcional) lanza 1-3 `explorer` que escriben en `harness/progress/explore_<modulo>.md`.
3. El `leader` lanza `spec_author`, que crea `harness/specs/<modulo>/{requirements,design,tasks}.md` y marca `spec_ready`.
4. **Pausa.** El responsable lee el spec y aprueba (o pide cambios).
5. Aprobado → el `leader` pasa a `in_progress` y lanza `builder`.
6. El `builder` ejecuta `tasks.md` una a una, construye en `AUTOMATION/` o `BUILD/`, verifica y escribe `harness/progress/impl_<modulo>.md`.
7. El `reviewer` comprueba trazabilidad y CHECKPOINTS → `harness/progress/review_<modulo>.md`.
8. Si aprueba, se marca `done` y el resumen se mueve a `harness/progress/history.md`.

## 5. Reglas duras

- **Un módulo a la vez.** Nunca más de un `in_progress`.
- **No construyas sin spec aprobado.**
- **No saltes la puerta de aprobación** entre `spec_ready` e `in_progress`.
- **No marques `done` sin verificación** (`harness/verify.ps1` verde + prueba funcional).
- **Estado en disco, no en chat.**
- **Nunca commitees credenciales.** Variables de entorno.
- **Documenta mientras trabajas** en `harness/progress/current.md`, no al final.

## 6. Cierre de sesión

1. Ejecuta `harness/verify.ps1` — todo verde.
2. Si el módulo está acabado: `status: "done"` en `harness/build_backlog.json`.
3. Mueve el resumen de `harness/progress/current.md` al final de `harness/progress/history.md`.
4. Vacía `harness/progress/current.md` dejando la plantilla.
5. Sin archivos temporales ni TODOs sin contexto.

## 7. Si te bloqueas

Relee `~/.claude/harness/docs/`. No inventes workarounds: documenta el bloqueo en
`harness/progress/current.md`, marca el módulo `blocked` y para.
