# Guía de contexto de proyecto — qué preguntar y qué escribir en `proyecto.md`

Referencia para la skill `onboarding-proyecto`. Define **qué preguntar** (solo lo específico de
este cliente/proyecto, sin repetir lo del negocio) y **qué secciones** lleva
`CONTEXT/proyecto.md`. Todo el contenido debe ser **real** (lo que ha dicho el usuario o lo
extraído de su archivo) y quedar **sin `TODO`**.

## Principio: qué NO preguntar (se hereda del negocio)

`Mi-Empresa/CONTEXT/` ya define el negocio. **No** vuelvas a preguntar (ni copies aquí):

- Qué hace el negocio, su propuesta de valor o su diferencial → está en `negocio.md`.
- Su catálogo y precios generales → `servicios-pricing.md`.
- Su equipo interno completo → `equipo.md` (aquí solo interesa **quién lleva este proyecto**).
- Su cliente objetivo general → `clientes-objetivo.md`.
- Su estrategia global → `estrategia.md`.
- Sus procesos generales → `procesos.md`.

Solo capturas lo que es **propio de este proyecto** y que no se deduce del negocio.

## Reglas del archivo

- Título: `# Proyecto: <nombre reconocible del proyecto>` y, debajo, una línea indicando a qué
  negocio pertenece (`Proyecto de <NOMBRE_NEGOCIO>`).
- Redacta en frases claras o viñetas, lo que se lea mejor. Breve: es un proyecto, no el negocio.
- Si una sección no aplica, dilo explícito ("Sin plazo de cierre definido aún"), no la dejes
  vacía.
- No dejes ninguna línea con `TODO`, `TBD`, `{{...}}` ni "por completar".

---

## Secciones de `CONTEXT/proyecto.md`

### 1. Qué es este proyecto
Tema de entrevista: *qué es y cómo se llama el cliente/proyecto*.
- En una o dos frases: quién es el cliente (o qué iniciativa interna es) y de qué va el proyecto.
- Si es un cliente externo, un par de datos útiles para situarlo (sector, tamaño), **si** el
  usuario los da; no lo alargues.

### 2. Alcance
Tema de entrevista: *qué entra y qué no entra*.
- **Qué incluye** — el trabajo o los entregables comprometidos en este proyecto.
- **Qué NO incluye** — lo que queda fuera, para evitar malentendidos (si el usuario lo tiene
  claro).

### 3. Objetivos
Tema de entrevista: *qué se quiere conseguir y cómo se mide*.
- **Objetivos** — qué busca este proyecto (para el cliente y/o para el negocio).
- **Cómo se mide el éxito** — señal o indicador de que va bien (si aplica).

### 4. Interlocutores
Tema de entrevista: *con quién se habla y quién decide*.
- **Por parte del cliente** — persona(s) de contacto y quién decide/aprueba.
- **Por nuestra parte** — quién del negocio lleva este proyecto (referido al equipo de
  `Mi-Empresa/CONTEXT/equipo.md`, sin recopiar todo el equipo).

### 5. Particularidades
Tema de entrevista: *plazos, condiciones y cualquier cosa singular*.
- **Plazos / hitos** — fechas clave, si las hay.
- **Condiciones** — precio pactado para este proyecto, forma de pago, restricciones,
  confidencialidad… lo que aplique (sin escribir aquí ninguna credencial).
- **Notas** — tono con el cliente, historia previa, riesgos, o cualquier detalle que convenga
  recordar.

---

## Mapa rápido tema → sección

| Tema de la entrevista | Sección de `proyecto.md` |
|-----------------------|--------------------------|
| Qué es y cómo se llama el cliente/proyecto | Qué es este proyecto |
| Qué entra y qué no | Alcance |
| Qué se quiere conseguir y cómo se mide | Objetivos |
| Con quién se habla y quién decide | Interlocutores |
| Plazos, condiciones y cosas singulares | Particularidades |

Todo en un solo archivo `CONTEXT/proyecto.md` (no seis archivos como en la empresa): el proyecto
es más ligero.
