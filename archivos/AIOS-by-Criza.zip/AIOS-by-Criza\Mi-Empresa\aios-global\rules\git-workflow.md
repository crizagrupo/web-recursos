# Cómo se guarda el trabajo — AIOS {{NOMBRE_NEGOCIO}}

No necesitas saber de Git ni de programación. El trabajo se guarda solo con el comando
**`/commit`**, sobre **una sola rama**. Es un flujo simple, pensado para el dueño del
negocio y no para un equipo de desarrollo.

## Guardar = `/commit`

Cuando quieras dejar constancia de lo hecho, ejecuta **`/commit`**. El sistema:

- Reúne los cambios de la sesión y crea **un único punto de guardado**.
- Redacta por ti una **descripción clara en frase llana** de lo que cambió (o usa la que le
  des tú), para que dentro de meses entiendas qué hiciste sin abrir los archivos.
- Antes de guardar, comprueba que no se cuele ninguna credencial ni dato sensible.

No hace falta que escribas mensajes con formatos técnicos: basta con lenguaje natural.

## Cada commit es una versión guardada

Cada `/commit` deja una **versión guardada y navegable** del negocio: un punto de
restauración con su descripción. El historial queda ordenado por fecha, así que siempre
puedes ver qué se hizo y cuándo, y volver a un estado anterior si algo se tuerce.

## Antes de tocar los archivos de verdad, {{DUENO}} aprueba

Cuando se construye algo nuevo con el harness, el trabajo se presenta y **{{DUENO}} lo
aprueba** antes de aplicarlo. Una vez aprobado, se guarda con `/commit` como una versión más
del historial.
