# AUTOMATION — Automatizaciones del proyecto

Capa 4. Automatizaciones del proyecto: contenido, propuestas,
seguimiento de clientes, procesado de reuniones, tareas programadas (`cron/`).
Se construyen con el harness (modo construcción).
