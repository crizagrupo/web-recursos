# -*- coding: utf-8 -*-
"""
Pipeline de informes (genérico, multi-cliente).

Flujo en UNA ejecución:
  fuentes (txt/md/docx) -> redacción con IA (CLI de Claude) -> Markdown -> .docx

La IA (CLI de Claude Code, sin API key) hace SOLO la redacción del borrador.
La maquetación corporativa la hace `docx_estilo` (identidad en `branding.json`)
sin consumir tokens.

Ejemplo:
  py -X utf8 AUTOMATION/generar-informe.py ^
     --tipo auditoria ^
     --cliente "Cid Abogados" ^
     --proyecto "Cid Abogados - Generador de Contenido (Fase 1)" ^
     --fecha "Mayo 2026" ^
     --reglas ".claude/rules/sector-legal.md" ^
     --salida "INTELLIGENCE/reuniones/Informe_Auditoria_Cid_Abogados.docx" ^
     "INTELLIGENCE/reuniones/20260522 Auditoria 1_Resumen.md" ^
     "INTELLIGENCE/reuniones/20260522 Auditoría 1_Notas.docx"
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import docx_estilo  # noqa: E402


# --- Estructuras por tipo de informe (guían a la IA, no son código rígido) ----
ESTRUCTURAS = {
    "auditoria": (
        "Estructura obligatoria (usa estos títulos de sección, numerados):\n"
        "# Informe de Auditoría: <Cliente>\n"
        "## 1. Resumen ejecutivo  (1 párrafo)\n"
        "## 2. Contexto y objetivo de la auditoría\n"
        "## 3. Situación actual\n"
        "### 3.1 Canales y cuentas\n"
        "### 3.2 Contenido\n"
        "### 3.3 Fuentes de información\n"
        "### 3.4 Herramientas y operativa\n"
        "## 4. Necesidades y objetivos detectados\n"
        "## 5. Hallazgos clave y puntos de atención\n"
        "## 6. Próximos pasos y responsabilidades  (tabla GFM: # | Acción | Responsable | Estado)\n"
        "Es un diagnóstico: describe la situación y las necesidades; NO propongas enfoque ni roadmap."
    ),
    "tareas": (
        "Estructura orientativa (numera las secciones):\n"
        "# Informe Técnico: <Tarea>\n"
        "## 1. Objetivo de la tarea\n"
        "## 2. Trabajo realizado\n"
        "## 3. Resultados y conclusiones\n"
        "## 4. Próximos pasos  (tabla GFM: # | Acción | Responsable | Estado)"
    ),
    "generico": (
        "Organiza el informe en secciones numeradas con ## y subsecciones ### según el contenido. "
        "Si procede, cierra con una tabla GFM de próximos pasos (# | Acción | Responsable | Estado)."
    ),
}

FORMATO = (
    "FORMATO DE SALIDA (estricto):\n"
    "- Devuelve SOLO Markdown, sin texto introductorio ni explicaciones, sin bloques de código.\n"
    "- Un único título de nivel 1 (#) al principio.\n"
    "- Secciones con ##, subsecciones con ###.\n"
    "- Viñetas con '- '. Para puntos con etiqueta, usa '- **Etiqueta:** desarrollo'.\n"
    "- Tablas en formato Markdown con barras: | Col1 | Col2 |.\n"
    "- No incluyas la cabecera (Empresa / Proyecto / Fecha) ni el pie: se añaden automáticamente.\n"
    "- Español correcto con tildes."
)


def leer_fuente(path):
    if path.lower().endswith(".docx"):
        with zipfile.ZipFile(path) as z:
            xml = z.read("word/document.xml").decode("utf-8")
        import html
        xml = re.sub(r"</w:p>", "\n", xml)
        xml = re.sub(r"<[^>]+>", "", xml)
        return html.unescape(xml).strip()
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def construir_prompts(tipo, cliente, reglas_txt, fuentes_txt):
    estructura = ESTRUCTURAS.get(tipo, ESTRUCTURAS["generico"])
    system = (
        "Eres redactor de informes profesionales. "
        "Redactas en español, con tono profesional, claro y directo, "
        "sin lenguaje hinchado ni relleno. Sintetizas las fuentes con fidelidad: no "
        "inventas datos, cifras ni nombres; si algo es aproximado o dudoso, lo indicas.\n\n"
        + estructura + "\n\n" + FORMATO
    )
    if reglas_txt:
        system += ("\n\nLÍNEAS ROJAS QUE DEBES RESPETAR (del cliente):\n" + reglas_txt)
    user = (
        f"Cliente: {cliente}\n"
        f"Tipo de informe: {tipo}\n\n"
        "Redacta el informe a partir EXCLUSIVAMENTE de las siguientes fuentes "
        "(transcripciones, notas y/o resúmenes de la sesión):\n\n"
        "=== FUENTES ===\n" + fuentes_txt + "\n=== FIN FUENTES ==="
    )
    return system, user


def llamar_claude(system, user, modelo):
    exe = shutil.which("claude") or shutil.which("claude.cmd") or "claude"
    prompt = system + "\n\n" + user
    try:
        result = subprocess.run(
            [exe, "-p", prompt, "--model", modelo, "--output-format", "text"],
            capture_output=True, text=True, encoding="utf-8", timeout=600,
        )
    except FileNotFoundError:
        result = subprocess.run(
            f'claude -p --model {modelo} --output-format text',
            input=prompt, capture_output=True, text=True, encoding="utf-8",
            timeout=600, shell=True,
        )
    if result.returncode != 0:
        raise RuntimeError("Claude CLI error (%s): %s" % (result.returncode, (result.stderr or "")[:400]))
    return result.stdout.strip()


def limpiar_markdown(md):
    md = md.strip()
    if md.startswith("```"):
        lineas = md.split("\n")
        if lineas[-1].strip() == "```":
            lineas = lineas[1:-1]
        else:
            lineas = lineas[1:]
        md = "\n".join(lineas).strip()
    return md


def main():
    ap = argparse.ArgumentParser(description="Genera un informe .docx con IA.")
    ap.add_argument("fuentes", nargs="+", help="Archivos de origen (txt/md/docx)")
    ap.add_argument("--tipo", default="generico", choices=list(ESTRUCTURAS.keys()))
    ap.add_argument("--cliente", required=True)
    ap.add_argument("--proyecto", required=True, help="Texto de la línea 'Proyecto:'")
    ap.add_argument("--fecha", required=True, help="Texto de la línea 'Fecha:'")
    ap.add_argument("--salida", required=True, help="Ruta del .docx de salida")
    ap.add_argument("--reglas", default=None, help="Archivo con líneas rojas (opcional)")
    ap.add_argument("--modelo", default="sonnet", help="sonnet | haiku | opus")
    ap.add_argument("--guardar-md", action="store_true", help="Guardar también el .md")
    args = ap.parse_args()

    fuentes_txt = "\n\n".join(
        "----- %s -----\n%s" % (os.path.basename(p), leer_fuente(p)) for p in args.fuentes
    )
    reglas_txt = leer_fuente(args.reglas) if args.reglas else None

    print("Redactando con IA (modelo: %s)..." % args.modelo)
    system, user = construir_prompts(args.tipo, args.cliente, reglas_txt, fuentes_txt)
    md = limpiar_markdown(llamar_claude(system, user, args.modelo))

    if args.guardar_md:
        md_path = os.path.splitext(args.salida)[0] + ".md"
        with open(md_path, "w", encoding="utf-8") as f:
            f.write(md)
        print("Markdown:", md_path)

    docx_estilo.markdown_a_docx(md, args.proyecto, args.fecha, args.salida)
    print("Generado:", args.salida)


if __name__ == "__main__":
    main()
