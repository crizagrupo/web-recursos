# Plantilla del scoreboard

Formato exacto del archivo `INTELLIGENCE/task-audit/scoreboard.md` que escribe la skill
`task-audit`. Es un `.md` con **checklist marcable** (`[ ]` / `[x]`) para que el usuario vaya
tachando las tareas a medida que las resuelve. Sustituye los `<...>` por el contenido real.

- La **fecha** de la evaluación va al principio (R13).
- La sección **Quick wins** va **primero** (R11).
- Cada tarea es un **elemento de checklist** `[ ]` (R12); las heredadas como resueltas de una
  evaluación anterior van `[x]` (R16).
- Las tareas **solo humano** van al final, como referencia (no son objetivo de
  automatización).
- Donde una skill o comando ya instalado resuelve la tarea, se indica como **→ Próximo paso**
  (R17).

---

```markdown
# Scoreboard de tareas — <NOMBRE del negocio o proyecto>

- **Evaluación:** <AAAA-MM-DD>
- **Ámbito:** <Mi-Empresa (negocio) | Proyecto: NOMBRE>
- **Tareas registradas:** <n>  ·  **Quick wins:** <n>

> Marca `[x]` una tarea cuando la tengas resuelta/automatizada. Al reejecutar `/task-audit`,
> lo ya marcado se conserva y la evaluación anterior se guarda en `historico/`.

## Quick wins (alto impacto + alta facilidad) — empieza por aquí

- [ ] **<Tarea>** — <área> · <frecuencia>, <tiempo por vez> → **<impacto> h/mes** ·
  Totalmente automatizable
  → Próximo paso: <skill/comando que la resuelve, si existe> _(o: sin herramienta aún)_

## Resto de tareas automatizables (por prioridad)

- [ ] **<Tarea>** — <área> · <frecuencia>, <tiempo por vez> → **<impacto> h/mes** ·
  <Parcialmente automatizable | No automatizable todavía>
  → Próximo paso: <skill/comando que la resuelve, si existe> _(o: sin herramienta aún)_
- [ ] **<Tarea>** — <área> · <frecuencia>, <tiempo por vez> → **<impacto> h/mes** ·
  <categoría>

## Solo humano (referencia — no se automatizan)

- [ ] **<Tarea>** — <área> · <por qué es solo humano en una frase>

---

## Cómo se leyó esto (metodología)

- **Impacto** = tiempo por vez × frecuencia (en horas/mes). **Facilidad** = según la
  categoría de automatización. **Quick win** = impacto alto + facilidad alta.
- Contexto usado: `CONTEXT/` de esta carpeta (Fase 1). No se repreguntó lo que ya constaba.
```

---

## Notas de uso de la plantilla (no van en el archivo final)

- Ordena **Quick wins** primero y, dentro de cada sección, por prioridad descendente
  (`impacto × factor_facilidad`, ver `areas.md`).
- Muestra el **impacto en h/mes** con un número redondo (p. ej. "3,5 h/mes"), para que el
  usuario entienda el porqué del orden.
- La línea `→ Próximo paso` **solo** aparece cuando de verdad hay una skill o comando
  instalado que resuelve esa tarea; si no lo hay, omite la línea o pon "sin herramienta aún".
  No inventes herramientas que no existen.
- Al **reevaluar**, conserva el estado `[x]` de las tareas que el usuario ya había marcado
  como resueltas (se reconocen por su texto), aunque cambien de sección.
