# Guía de Datos y conexiones (Fase 3) — cómo conectar y qué contar

Referencia para la skill `onboarding-datos`. Define **cómo elegir la vía de conexión**
(MCP oficial vs. conector a medida) y **qué debe contener `DATA/key-metrics.md`**
(distinguir "conectado" de "útil"). Léela antes de conectar y antes de escribir
`key-metrics.md`.

Regla de oro: el usuario no es técnico. Tú haces el trabajo; él decide qué conectar y en
qué orden. Nunca guardas una credencial en un archivo del repo.

---

## 1. MCP en una frase

**MCP (Model Context Protocol)** es el "enchufe estándar" que permite a la IA leer y usar
las herramientas del negocio (su Drive, su CRM, sus reuniones…). Conectas la herramienta una
vez y la IA puede consultarla cuando la necesita, sin que tú copies y pegues datos.

Dos formas de conectar una herramienta:

1. **Servidor MCP oficial/conocido** — la vía preferida: alguien ya hizo el enchufe; solo hay
   que registrarlo y autenticarse.
2. **Conector a medida** — solo si no existe servidor MCP para esa herramienta; se monta
   siguiendo la skill `mcp-integration`.

## 2. Cómo elegir la vía

**¿Hay servidor MCP para esta herramienta?**

- **Sí → regístralo con alcance de usuario** (Paso 4a de la skill). Suelen tener servidor
  MCP conocido, entre otras:
  - **Almacenamiento:** Google Drive, Microsoft 365 / OneDrive.
  - **Reuniones/notas y otras** según disponibilidad del ecosistema MCP del momento.
  Antes de dar por hecho que no existe, compruébalo: el ecosistema MCP crece rápido.
- **No → conector a medida** siguiendo `mcp-integration` (Paso 4b). Típico cuando la
  herramienta es de nicho, local, o solo expone una API propia sin servidor MCP publicado.

**Regla de alcance (vale para las dos vías):** siempre **alcance de usuario**
(`claude mcp add --scope user …`), nunca alcance de carpeta/proyecto (un `.mcp.json` dentro
de `Mi-Empresa/`, o `--scope project` / `--scope local`). Motivo: las conexiones son una
propiedad del **ordenador**; con alcance de usuario, cualquier carpeta que se cree después
con `/crear-proyecto` las hereda sin reconectar. (R6, R7)

## 3. Alcances MCP en Claude Code (para no equivocarse)

| Alcance | Dónde se guarda | ¿Lo heredan otras carpetas? | ¿Usarlo aquí? |
|---------|-----------------|------------------------------|----------------|
| `user` | Config del usuario del ordenador | **Sí, todas** | **Sí — siempre esta** |
| `project` | `.mcp.json` en la carpeta | No (solo esa carpeta / quien la comparta) | No |
| `local` | Config privada de esa carpeta | No | No |

Comando de alta: `claude mcp add --scope user <nombre> <comando-o-url> [args]`.
Comprobar: `claude mcp list` (debe salir con alcance de usuario).

## 4. Credenciales: dónde SÍ y dónde NO (R10)

- **Autenticación por OAuth** (típica de Google Drive, Microsoft 365): la gestiona el propio
  cliente MCP. Cuando el servidor lo pida, el usuario hace login en su navegador; las
  credenciales las guarda el sistema/cliente MCP. **Tú no guardas nada** en el repo.
- **Clave de API** (algún conector a medida): va en una **variable de entorno** o en el
  gestor de credenciales del sistema. En la ficha `DATA/integraciones/<herramienta>.md`
  documenta solo el **nombre** de la variable (p. ej. `FIREFLIES_API_KEY`), **nunca** su
  valor.
- **Prohibido**: escribir claves, tokens o contraseñas en cualquier archivo versionado
  (fichas, `key-metrics.md`, README, commits).

## 5. Qué poner en DATA/integraciones/<herramienta>.md (R9)

Una ficha por herramienta conectada, partiendo de `PLANTILLA-integracion.md`. Debe dejar
claro, sin `TODO`:

- **Para qué se usa** — el caso de uso real que contó el usuario.
- **Tipo de conexión** — `MCP (alcance de usuario)` o `Conector a medida (patrón mcp-integration)`.
- **Estado** — `Conectada` (fecha + qué se verificó) o `Pendiente de conectar`.
- **Credenciales** — nombre de la variable de entorno si aplica, o "gestionada por el cliente
  MCP (OAuth), sin clave en el repo". Nunca el valor.

## 6. Qué debe contener DATA/key-metrics.md — "conectado" vs. "útil" (R11, R12, R13)

`key-metrics.md` es el resumen legible de **qué sabe la IA gracias a las conexiones**. La
clave: no basta con decir que algo "está conectado"; hay que decir **qué información o
capacidad aporta**. (R12)

Distingue:

- ❌ *Solo "conectado"* (insuficiente): "Google Drive: conectado."
- ✅ *"Útil"* (lo correcto): "Google Drive (MCP): la IA puede leer y buscar en los documentos
  del negocio en Drive — propuestas, contratos, notas — para responder y redactar con ellos."

Incluye siempre dos secciones: **Conectado** (con el aporte de cada herramienta) y
**Pendientes de conectar** (lo que el usuario aplazó, R13).

### Plantilla de `key-metrics.md`

```markdown
# Key metrics — <NOMBRE_NEGOCIO real>

> Qué sabe la IA de este negocio gracias a las herramientas conectadas (Fase 3 del
> onboarding). Se regenera cada vez que se conecta o cambia una herramienta.
> Actualizado: <fecha>.

## Conectado
- **<Herramienta> (<tipo: MCP alcance usuario | conector a medida>)** — <qué información o
  capacidad gana la IA gracias a esta conexión: qué puede leer, buscar o hacer ahora>.

## Pendientes de conectar
- **<Herramienta>** — <para qué la usa el negocio; aplazada, se conectará al retomar>.
```

Si no hay nada conectado todavía, deja la sección "Conectado" con una nota ("Aún sin
conexiones") y lista todo en "Pendientes". Si no queda nada pendiente, di "ninguna" en esa
sección.

## 7. Resumen para no equivocarse

| Pregunta | Respuesta correcta |
|----------|--------------------|
| ¿Con qué alcance registro el servidor MCP? | Usuario (`--scope user`). Nunca carpeta/proyecto. |
| ¿Y si no hay servidor MCP? | Conector a medida siguiendo `mcp-integration`, también alcance usuario. |
| ¿Dónde van las claves? | Variable de entorno / gestor de credenciales / OAuth del cliente MCP. Nunca en el repo. |
| ¿Qué escribo en `key-metrics.md`? | Qué **sabe/puede** la IA por cada conexión, no solo que está conectada. + pendientes. |
| ¿Dónde consta "Fase 3 hecha"? | `~/.claude/aios/estado-usuario.md` (nivel usuario), no dentro de `Mi-Empresa/`. |
