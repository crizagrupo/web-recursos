# Procesos — {{NOMBRE_NEGOCIO}}

> Capa 1 (Context). Flujo de lead → cierre → entrega y herramientas en cada paso.
> Estado: scaffold — responde las secciones `TODO`.

## Cómo entra un lead
TODO — de dónde viene y qué pasa al entrar.

## De lead a cliente
TODO — pasos hasta el cierre.

## Entrega del servicio / producto
TODO — cómo se entrega y se da seguimiento.

## Herramientas por paso
TODO — qué herramienta se usa en cada fase (CRM, facturación, reuniones…).
