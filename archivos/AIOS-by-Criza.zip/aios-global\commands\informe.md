---
description: Genera un informe con formato profesional a partir de notas o reuniones.
---

Usa la skill `informe` para generar un documento .docx con formato corporativo.

1. Pregunta (si no se ha dado) qué tipo de informe es (auditoría, tareas, genérico) y cuál es la fuente (transcripción, notas, resumen).
2. Invoca la skill `informe` con esa entrada.
3. Devuelve la ruta del documento generado.
