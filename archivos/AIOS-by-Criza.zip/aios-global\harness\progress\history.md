# Bitácora — Historial de construcciones

> Append-only. Al cerrar cada sesión se añade aquí el resumen del módulo construido.
