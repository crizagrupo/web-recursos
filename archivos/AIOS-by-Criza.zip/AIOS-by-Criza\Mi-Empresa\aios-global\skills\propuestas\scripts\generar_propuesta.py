# -*- coding: utf-8 -*-
"""
Pipeline de propuestas de transformación IA (multi-cliente).

Genera la propuesta interactiva HTML que el negocio dueño del AIOS presenta a SUS
clientes. La marca que firma la propuesta (nombre, colores, tipografías y logo) sale
de branding.json y de CONTEXT/branding/, no de valores fijos.

Flujo en UNA ejecución:
  contexto del proyecto (CONTEXT/, notas de descubrimiento)
  -> redacción estructurada con IA (CLI de Claude, JSON)
  -> ensamblado determinista (ensamblar_html.py, sin IA)
  -> HTML autocontenido en INTELLIGENCE/propuestas/

La IA (CLI de Claude Code, sin API key) hace SOLO la redacción y la elección
de KPIs (guiada por referencia-kpis.md). El HTML/CSS/JS lo genera
`ensamblar_html` sin consumir tokens.

Ejemplo:
  py -X utf8 generar_propuesta.py ^
     --cliente "Nombre Cliente" ^
     --fecha-reunion "15/07/2026" ^
     "CONTEXT/proyecto.md" "INTELLIGENCE/reuniones/2026-07-15-descubrimiento.md"
"""
import argparse
import datetime
import glob
import json
import os
import re
import shutil
import subprocess
import sys

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(SCRIPT_DIR)
sys.path.insert(0, SCRIPT_DIR)
import ensamblar_html  # noqa: E402

ESQUEMA = """
Devuelve un ÚNICO objeto JSON (sin texto antes ni después, sin bloques ```)
con EXACTAMENTE esta forma. "areas" tiene tantos elementos como áreas de
necesidad reales tenga el cliente (normalmente 2 a 5, no fuerces siempre 4).

{
  "cliente": "Nombre del cliente",
  "fecha_reunion": "DD/MM/AAAA",
  "vision_titulo": "Frase corta (h2) que resume la operativa del cliente.",
  "vision_sub": "1-2 frases: nº de áreas detectadas y en qué reunión.",
  "vision_objetivo": "1 frase: qué busca la propuesta en conjunto.",
  "areas": [
    {
      "id": "slug_corto_sin_espacios",
      "nombre": "Nombre del área (p.ej. Producción)",
      "prioridad": "critica" | "oportunidad",
      "resumen_mapa": "Frase muy corta para la tarjeta del mapa de áreas",
      "kicker": "ÁREA N · PRIORIDAD CRÍTICA|OPORTUNIDAD",
      "titulo": "Frase corta (h2) del problema de esta área",
      "sub": "1-3 frases describiendo el proceso manual actual",
      "mock": {
        "tipo": "mail" | "kpis" | "chain",
        "// si tipo=mail": "de, para, asunto, caption, cuerpo (con \\n), adjunto (opcional)",
        "// si tipo=kpis": "tiles: [{v, l}, ...] (2-3 tiles con números/estados actuales)",
        "// si tipo=chain": "pasos: [{titulo, texto}, ...] (3-5 pasos del proceso actual)"
      },
      "nota": {"tipo": "bad" | null, "texto": "HTML simple con <b> para el riesgo u oportunidad de esta área"},
      "simulacion": [
        "6 pasos EXACTOS con esta secuencia de kind (así se ve en la demo interactiva):",
        {"kind": "doc", "label": "...", "bar": "nombre_archivo.ext", "title": "...", "lines": [["campo", "valor"], ["campo", "valor"], ["campo", "valor"]]},
        {"kind": "proceso", "title": "IA hace X", "desc": "..."},
        {"kind": "proceso", "title": "IA hace Y", "desc": "..."},
        {"kind": "zoho", "bar": "Nombre del sistema/CRM del cliente", "title": "...", "rows": [{"txt": "fila anterior"}, {"txt": "fila nueva creada", "neu": true}]},
        {"kind": "proceso", "title": "...", "desc": "..."},
        {"kind": "aviso", "title": "Quién queda avisado", "desc": "..."}
      ]
    }
  ],
  "roadmap": [
    {"area_id": "slug_de_un_area", "descripcion": "Qué se automatiza en esta fase"}
  ],
  "fase1_en_marcha": {
    "// opcional pero recomendado si hay un área crítica": "antes/después del área de FASE 1 del roadmap",
    "area_nombre": "Nombre del área fase 1",
    "titulo": "Frase corta del ejemplo concreto",
    "antes": [{"time": "hh:mm", "texto": "..."}, "4-5 pasos manuales con tiempos realistas"],
    "despues": [{"time": "hh:mm:ss", "texto": "..."}, "mismos pasos, segundos, con el negocio"],
    "nota": "Ejemplo ilustrativo, con tiempos representativos."
  },
  "modelo_colaboracion_sub": "1 frase sobre el tipo de colaboración que busca el cliente (puntual vs largo plazo)",
  "impacto_esperado": {
    "titulo": "Lo que esto libera cada mes. (o variación)",
    "sub": "1 frase: estimación ilustrativa a partir de volúmenes habituales para un negocio de este tamaño",
    "horas_mes": 0,
    "valor_eur_mes": "número o null si no hay tarifa horaria defendible para este cliente (ver referencia-kpis.md)",
    "nota_headline": "Frase con la equivalencia en jornadas + tarifa asumida + % de la cuota, si hay valor_eur_mes",
    "por_area": [{"valor": "~N h", "etiqueta": "Área — qué se libera"}],
    "destacados": [
      "4 tarjetas siguiendo las 4 lentes de referencia-kpis.md (riesgo, velocidad, calidad/cobertura, capacidad de crecer)",
      {"icono": "un único carácter/emoji simple", "titulo": "cifra o afirmación corta", "texto": "1 frase de contexto"}
    ],
    "nota_final": "Aviso de que las cifras son ilustrativas y se recalculan con datos reales en la Fase 1"
  },
  "presupuesto": {
    "titulo": "NNN €/mes. Sin permanencia. (o el modelo acordado)",
    "sub": "1 frase",
    "cuota_mensual": 0,
    "sin_iva": true,
    "incluye": ["ítem 1", "ítem 2", "..."],
    "condiciones": "Cancelable cualquier mes, sin permanencia. (o lo acordado)",
    "nota_exclusiones": "Qué no incluye la cuota (licencias de terceros del cliente, etc.)"
  }
}

Reglas:
- NUNCA incluyas nombres propios de personas (ni del cliente ni del negocio); usa
  áreas, roles o cargos.
- Cada cifra de "impacto_esperado" debe rastrearse a algo dicho en las fuentes;
  si no hay dato real, usa una estimación ilustrativa razonable y dilo en
  nota_final. Sigue la regla de honestidad económica de referencia-kpis.md.
- "areas" ordénalas por prioridad (crítica primero) y usa esas mismas "id" en
  "roadmap" y en "fase1_en_marcha".
- Español correcto, con tildes. Tono profesional, directo, sin relleno.
"""


def leer_fuente(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def descripcion_negocio():
    """Frase con lo que hace el negocio, leída de CONTEXT/negocio.md si existe.
    Devuelve "" si no hay descripción disponible (redacción neutra sin sector)."""
    ruta = os.path.join("CONTEXT", "negocio.md")
    if not os.path.exists(ruta):
        return ""
    try:
        with open(ruta, "r", encoding="utf-8") as f:
            texto = f.read()
    except OSError:
        return ""
    # Primer párrafo con contenido, sin encabezados markdown ni marcadores.
    for bloque in re.split(r"\n\s*\n", texto):
        limpio = " ".join(
            l.strip() for l in bloque.splitlines() if l.strip() and not l.lstrip().startswith("#")
        ).strip()
        if limpio and "{{" not in limpio:
            return limpio[:400]
    return ""


def construir_prompts(cliente, fecha_reunion, kpis_ref, fuentes_txt):
    empresa = ensamblar_html.BRANDING["empresa"]
    desc = descripcion_negocio()
    quien = "Eres el redactor de propuestas de transformación con IA de %s" % empresa
    if desc:
        quien += ". Contexto del negocio: %s" % desc
    quien += "."
    system = (
        quien + " Lees el contexto de descubrimiento "
        "de un cliente y produces el CONTENIDO ESTRUCTURADO (JSON) de una "
        "propuesta interactiva, reutilizando el formato ya validado con clientes "
        "anteriores. No maquetas HTML: solo produces los datos; el ensamblado es "
        "automático.\n\n"
        "CÓMO ELEGIR LOS KPIs DE 'IMPACTO ESPERADO' (léelo con atención):\n\n"
        + kpis_ref + "\n\n"
        "ESQUEMA DE SALIDA (obligatorio):\n" + ESQUEMA
    )
    user = (
        f"Cliente: {cliente}\n"
        f"Fecha de la reunión de descubrimiento: {fecha_reunion}\n\n"
        "Genera el JSON de la propuesta a partir EXCLUSIVAMENTE del siguiente "
        "contexto del proyecto (documento de contexto y/o notas de descubrimiento):\n\n"
        "=== CONTEXTO ===\n" + fuentes_txt + "\n=== FIN CONTEXTO ==="
    )
    return system, user


def llamar_claude(system, user, modelo):
    exe = shutil.which("claude") or shutil.which("claude.cmd") or "claude"
    prompt = system + "\n\n" + user
    try:
        result = subprocess.run(
            [exe, "-p", prompt, "--model", modelo, "--output-format", "text"],
            capture_output=True, text=True, encoding="utf-8", timeout=900,
        )
    except FileNotFoundError:
        result = subprocess.run(
            f'claude -p --model {modelo} --output-format text',
            input=prompt, capture_output=True, text=True, encoding="utf-8",
            timeout=900, shell=True,
        )
    if result.returncode != 0:
        raise RuntimeError("Claude CLI error (%s): %s" % (result.returncode, (result.stderr or "")[:400]))
    return result.stdout.strip()


def limpiar_json(txt):
    txt = txt.strip()
    if txt.startswith("```"):
        lineas = txt.split("\n")
        if lineas[-1].strip() == "```":
            lineas = lineas[1:-1]
        else:
            lineas = lineas[1:]
        txt = "\n".join(lineas).strip()
    return txt


REQUERIDOS = ["cliente", "areas", "roadmap", "impacto_esperado", "presupuesto"]


def validar(contenido):
    faltan = [k for k in REQUERIDOS if k not in contenido]
    if faltan:
        raise ValueError("Faltan claves obligatorias en el JSON generado: %s" % ", ".join(faltan))
    if not contenido["areas"]:
        raise ValueError("'areas' no puede estar vacío")
    ids = {a["id"] for a in contenido["areas"]}
    for fase in contenido["roadmap"]:
        if fase.get("area_id") not in ids:
            raise ValueError("roadmap referencia area_id '%s' que no existe en 'areas'" % fase.get("area_id"))


def slug(texto):
    s = re.sub(r"[^a-z0-9]+", "-", (texto or "").lower().strip())
    return s.strip("-") or "propuesta"


def salida_por_defecto(cliente):
    """INTELLIGENCE/propuestas/YYYY-MM-DD-<nombre>.html (R12)."""
    fecha = datetime.date.today().isoformat()
    return os.path.join("INTELLIGENCE", "propuestas", "%s-%s.html" % (fecha, slug(cliente)))


def resolver_logo():
    """Ruta del logo del negocio (CONTEXT/branding/logo.<ext>), o None si no hay."""
    for p in sorted(glob.glob(os.path.join("CONTEXT", "branding", "logo.*"))):
        if os.path.splitext(p)[1].lower() in ensamblar_html.MIME_POR_EXT:
            return p
    return None


def main():
    ap = argparse.ArgumentParser(description="Genera una propuesta interactiva (HTML autocontenido) con IA.")
    ap.add_argument("fuentes", nargs="+", help="Archivos de contexto (CONTEXT/proyecto.md, notas de descubrimiento, .md/.txt)")
    ap.add_argument("--cliente", required=True)
    ap.add_argument("--fecha-reunion", required=True, help="Fecha de la reunión de descubrimiento, p.ej. 15/07/2026")
    ap.add_argument("--salida", default=None, help="Ruta del .html de salida (por defecto INTELLIGENCE/propuestas/YYYY-MM-DD-<nombre>.html)")
    ap.add_argument("--modelo", default="sonnet", help="sonnet (defecto) | haiku | opus")
    ap.add_argument("--guardar-json", action="store_true", help="Guardar también el JSON intermedio")
    args = ap.parse_args()

    salida = args.salida or salida_por_defecto(args.cliente)

    fuentes_txt = "\n\n".join(
        "----- %s -----\n%s" % (os.path.basename(p), leer_fuente(p)) for p in args.fuentes
    )
    kpis_ref = leer_fuente(os.path.join(SKILL_DIR, "referencia-kpis.md"))

    print("Redactando contenido con IA (modelo: %s)..." % args.modelo)
    system, user = construir_prompts(args.cliente, args.fecha_reunion, kpis_ref, fuentes_txt)
    raw = llamar_claude(system, user, args.modelo)
    contenido = json.loads(limpiar_json(raw))
    validar(contenido)

    if args.guardar_json:
        json_path = os.path.splitext(salida)[0] + ".json"
        os.makedirs(os.path.dirname(os.path.abspath(json_path)) or ".", exist_ok=True)
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(contenido, f, ensure_ascii=False, indent=2)
        print("JSON:", json_path)

    html = ensamblar_html.ensamblar(contenido, logo_path=resolver_logo())
    os.makedirs(os.path.dirname(os.path.abspath(salida)) or ".", exist_ok=True)
    with open(salida, "w", encoding="utf-8") as f:
        f.write(html)
    print("Generado:", salida)


if __name__ == "__main__":
    main()
