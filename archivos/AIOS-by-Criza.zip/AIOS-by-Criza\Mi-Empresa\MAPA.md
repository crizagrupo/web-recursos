# MAPA — {{NOMBRE_NEGOCIO}}

> Índice de navegación del negocio. Abre solo lo que necesites; no leas todo por
> defecto.

## Por intención

| Quiero… | Voy a… |
| --- | --- |
| Saber qué es este negocio | `CONTEXT/` |
| Ver el estado del AIOS | `ESTADO.md` |
| Ver los hitos del negocio | `HISTORICO.md` |
| Ver/conectar herramientas del negocio | `DATA/` |
| Consultar conocimiento vivo (reuniones, briefs, task-audit) | `INTELLIGENCE/` |
| Ver/lanzar automatizaciones del negocio | `AUTOMATION/` |
| Ver/lanzar herramientas internas | `BUILD/` |
| Ver el molde de proyecto / recursos internos | `Recursos/` |
| Abrir un cliente o iniciativa nueva | comando `/crear-proyecto` |
| Construir algo nuevo (harness) | `~/.claude/harness/AGENTS.md` |

## Las 5 capas

| Capa | Carpeta | Para qué |
| --- | --- | --- |
| 1 Context | `CONTEXT/` | Quién es el negocio (lo rellena `/onboarding` · Fase 1). |
| 2 Data | `DATA/` | Conexiones del negocio y qué sabe la IA (Fase 3). |
| 3 Intelligence | `INTELLIGENCE/` | Conocimiento vivo (p. ej. `task-audit/`). Se crea sola al primer uso. |
| 4 Automation | `AUTOMATION/` | Automatizaciones del negocio. Se crea sola al primer uso. |
| 5 Build | `BUILD/` | Herramientas internas. Se crea sola al primer uso. |

Los comandos y skills se heredan de `~/.claude` (instalados una vez para todo el
ordenador). De fábrica, esta carpeta trae una copia en `aios-global/`; la **primera**
ejecución de `/onboarding` la instala en `~/.claude` y la borra de aquí. **Tras** esa
primera ejecución ya no hay copia propia de la herramienta en esta carpeta.
