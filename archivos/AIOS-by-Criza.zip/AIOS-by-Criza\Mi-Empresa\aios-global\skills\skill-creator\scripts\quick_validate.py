#!/usr/bin/env python3
# quick_validate.py - Validacion basica del SKILL.md de una skill del AIOS.
# Uso: py quick_validate.py <ruta-carpeta-skill>
#   Comprueba que la carpeta contiene un SKILL.md bien formado:
#   1. Existe SKILL.md.
#   2. Empieza con un frontmatter ---...--- parseable.
#   3. Tiene 'name' y 'description', ambos no vacios.
#   4. 'name' esta en kebab-case y coincide con el nombre de la carpeta.
#   5. 'name' <= 64 caracteres y 'description' <= 1024 caracteres.
# Sale con codigo 0 e imprime "OK" si todo pasa; codigo != 0 y un mensaje claro
# por cada fallo si algo no cumple. Solo usa la libreria estandar (portable Win/Mac).

import re
import sys
from pathlib import Path

NAME_MAX = 64
DESCRIPTION_MAX = 1024
KEBAB_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")


def parse_frontmatter(text):
    """Devuelve (dict, None) si el frontmatter es parseable, o (None, error)."""
    # Quitar BOM si lo hubiera.
    if text.startswith("﻿"):
        text = text[1:]
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return None, "SKILL.md no empieza con un bloque de frontmatter '---'."
    # Buscar el cierre '---'.
    end = None
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            end = i
            break
    if end is None:
        return None, "El frontmatter no esta cerrado con una segunda linea '---'."
    fields = {}
    for raw in lines[1:end]:
        line = raw.rstrip()
        if not line.strip():
            continue
        if ":" not in line:
            return None, ("Linea de frontmatter sin 'clave: valor': " + line.strip())
        key, value = line.split(":", 1)
        fields[key.strip()] = value.strip()
    return fields, None


def validate(skill_dir):
    errores = []
    folder = Path(skill_dir)

    if not folder.exists() or not folder.is_dir():
        return ["La ruta indicada no es una carpeta: " + str(folder)]

    skill_md = folder / "SKILL.md"
    if not skill_md.is_file():
        return ["Falta SKILL.md en la carpeta: " + str(folder)]

    text = skill_md.read_text(encoding="utf-8")
    fields, err = parse_frontmatter(text)
    if err:
        return [err]

    name = fields.get("name", "").strip()
    description = fields.get("description", "").strip()

    if not name:
        errores.append("Falta el campo obligatorio 'name' (o esta vacio) en el frontmatter.")
    if not description:
        errores.append("Falta el campo obligatorio 'description' (o esta vacio) en el frontmatter.")

    # Las comprobaciones que dependen de 'name' solo tienen sentido si hay 'name'.
    if name:
        if not KEBAB_RE.match(name):
            errores.append(
                "El campo 'name' no esta en kebab-case (solo minusculas, numeros y "
                "guiones, sin empezar/terminar en guion): '" + name + "'."
            )
        if name != folder.name:
            errores.append(
                "El 'name' del frontmatter ('" + name + "') no coincide con el nombre "
                "de la carpeta ('" + folder.name + "')."
            )
        if len(name) > NAME_MAX:
            errores.append(
                "El 'name' excede " + str(NAME_MAX) + " caracteres (" + str(len(name)) + ")."
            )

    if description and len(description) > DESCRIPTION_MAX:
        errores.append(
            "La 'description' excede " + str(DESCRIPTION_MAX) + " caracteres ("
            + str(len(description)) + ")."
        )

    return errores


def main(argv):
    if len(argv) != 2:
        sys.stderr.write("Uso: py quick_validate.py <ruta-carpeta-skill>\n")
        return 2
    errores = validate(argv[1])
    if errores:
        sys.stderr.write("VALIDACION FALLIDA - la skill NO esta terminada:\n")
        for e in errores:
            sys.stderr.write("  - " + e + "\n")
        return 1
    print("OK")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
