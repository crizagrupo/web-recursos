# -*- coding: utf-8 -*-
"""
Ensamblador determinista de la propuesta interactiva — SIN IA.

Toma un JSON de contenido (redactado por la IA siguiendo referencia-kpis.md) y
produce el HTML autocontenido (CSS + JS + logo incluidos inline, sin ninguna
petición de red). La identidad visual (colores, tipografías y nombre) se lee de
branding.json, en la raíz de este skill; el logo del negocio se toma de
CONTEXT/branding/logo.<ext>. Esta capa no redacta nada ni consume tokens: solo maqueta.

Uso como librería:
    from ensamblar_html import ensamblar
    html = ensamblar(contenido_dict, logo_path="CONTEXT/branding/logo.png")

Uso como script (para probar con un fixture, sin IA):
    py -X utf8 ensamblar_html.py contenido.json salida.html [logo.<ext>]
"""
import base64
import json
import os
import sys

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BRANDING_PATH = os.path.join(SKILL_DIR, "branding.json")

MIME_POR_EXT = {
    ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
    ".svg": "image/svg+xml", ".webp": "image/webp", ".gif": "image/gif",
}


def _load_branding():
    """Lee branding.json con defaults neutros seguros (mismo patrón que
    informe/docx_estilo.py). Un campo vacío o con {{...}} cae al default para que
    la skill nunca rompa aunque la marca no esté todavía propagada."""
    data = {}
    try:
        with open(BRANDING_PATH, encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        pass

    def clean(value, fallback):
        if not value or "{{" in str(value):
            return fallback
        return str(value)

    def clean_hex(value, fallback):
        return clean(value, fallback).lstrip("#") or fallback

    return {
        "empresa": clean(data.get("empresa"), "Tu negocio"),
        "email": clean(data.get("email"), ""),
        "color_primario": clean_hex(data.get("color_primario"), "14306E"),
        "color_tabla_cabecera": clean_hex(data.get("color_tabla_cabecera"), "0E2350"),
        "color_acento": clean_hex(data.get("color_acento"), "1F66F0"),
        "tipografia_titulares": clean(data.get("tipografia_titulares"), "Georgia"),
        "tipografia_cuerpo": clean(data.get("tipografia_cuerpo"), "Segoe UI"),
    }


BRANDING = _load_branding()


def esc(t):
    if t is None:
        return ""
    return str(t).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def b64(path):
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("ascii")


def logo_data_uri(logo_path):
    """Devuelve el data: URI del logo del negocio, o None si no hay logo utilizable
    (no existe, sin ruta, o extensión no soportada). Nunca lanza: si no hay logo,
    la propuesta se genera sin imagen (R6)."""
    if not logo_path or not os.path.exists(logo_path):
        return None
    ext = os.path.splitext(logo_path)[1].lower()
    mime = MIME_POR_EXT.get(ext)
    if not mime:
        return None
    return "data:%s;base64,%s" % (mime, b64(logo_path))


# ---------------------------------------------------------------------------
# CSS — sistema de diseño; los tokens de marca (--navy, --navy-deep, --accent y
# las dos familias tipográficas) salen de branding.json, con fallbacks de sistema.
# El resto de tokens de superficie neutros se mantienen fijos.
# ---------------------------------------------------------------------------
def build_css(brand):
    font_display = "'%s',Georgia,'Times New Roman',serif" % brand["tipografia_titulares"]
    font_body = "'%s',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif" % brand["tipografia_cuerpo"]
    root = (
        ":root{\n"
        "  --navy:#%s; --navy-deep:#%s; --ink:#16213d; --muted:#5c6475; --line:#e7e6e0;\n"
        "  --bg:#f7f6f3; --surface:#ffffff; --accent:#%s;\n"
        "  --ok:#1f6e4c; --ok-bg:#e7f3ec; --warn:#8a5a12; --warn-bg:#faf1e2; --bad:#8f2c2c; --bad-bg:#fbeaea;\n"
        "  --radius:14px; --shadow:0 1px 2px rgba(20,30,60,.05),0 8px 24px rgba(20,30,60,.06);\n"
        "  --font-display:%s;\n"
        "  --font-body:%s;\n"
        "}\n"
    ) % (
        brand["color_primario"], brand["color_tabla_cabecera"], brand["color_acento"],
        font_display, font_body,
    )
    return root + CSS_BODY


CSS_BODY = """
*{box-sizing:border-box}
html,body{height:100%}
body{margin:0;font-family:var(--font-body);color:var(--ink);background:var(--bg);font-size:14.5px;line-height:1.6;-webkit-font-smoothing:antialiased;font-variant-numeric:tabular-nums}
button{font-family:inherit}
h1,h2,h3{font-family:var(--font-display);margin:0;letter-spacing:-.01em}

.app{display:flex;min-height:100vh}

/* ===== SIDEBAR ===== */
.sidebar{width:280px;flex-shrink:0;background:linear-gradient(180deg,var(--navy),var(--navy-deep));
  color:#eef2fb;display:flex;flex-direction:column;position:sticky;top:0;height:100vh}
.brand{padding:24px 22px 18px;border-bottom:1px solid rgba(255,255,255,.12)}
.brand .logo{display:flex;align-items:center;gap:10px;font-weight:600;font-size:15px}
.brand .logo img{height:24px;width:auto;border-radius:6px;display:block}
.brand p{margin:12px 0 0;font-size:11.5px;color:#a9bde3;line-height:1.5}
.nav{padding:12px 12px;flex:1;overflow-y:auto}
.nav .grp{font-size:10.5px;text-transform:uppercase;letter-spacing:.09em;color:#7d95c4;padding:16px 12px 6px;font-weight:600}
.nav button{display:flex;align-items:center;gap:11px;width:100%;background:none;border:0;color:#cfd9f0;
  text-align:left;padding:10px 12px;font-size:13.5px;cursor:pointer;border-radius:10px;transition:background .15s}
.nav button:hover{background:rgba(255,255,255,.07);color:#fff}
.nav button.activo{background:rgba(31,102,240,.28);color:#fff;font-weight:600;box-shadow:inset 0 0 0 1px rgba(120,160,250,.35)}
.nav button .n{width:24px;height:24px;flex-shrink:0;border-radius:7px;background:rgba(255,255,255,.10);
  display:grid;place-items:center;font-size:11.5px;font-weight:700}
.nav button.activo .n{background:var(--accent);color:#fff}
.pie{padding:14px 20px;border-top:1px solid rgba(255,255,255,.12);font-size:10.5px;color:#7d95c4}

/* ===== MAIN ===== */
.main{flex:1;min-width:0;background:var(--bg);display:flex;flex-direction:column}
.topbar{background:#fff;border-bottom:1px solid var(--line);padding:12px 30px;display:flex;align-items:center;
  gap:16px;position:sticky;top:0;z-index:5}
.crumb{font-size:12.5px;color:var(--muted)}
.crumb b{color:var(--ink)}
.pill{font-size:11px;font-weight:600;padding:4px 11px;border-radius:30px}
.pill.critica{background:var(--bad-bg);color:var(--bad)}
.pill.oportunidad{background:#e8edfb;color:var(--navy)}
.pill.bloqueada{background:var(--warn-bg);color:var(--warn)}
.pill.info{background:#eef1f8;color:var(--muted)}
.pill.ok{background:var(--ok-bg);color:var(--ok)}
.topbar .right{margin-left:auto;display:flex;align-items:center;gap:10px}
.navbtn{border:1px solid var(--line);background:#fff;color:var(--ink);padding:8px 14px;border-radius:9px;
  font-size:13px;cursor:pointer;font-weight:600}
.navbtn:hover{background:#eef1f8;border-color:#c9d6ef}
.navbtn:disabled{opacity:.4;cursor:default}
.navbtn.primario{background:var(--navy);border-color:var(--navy);color:#fff}
.navbtn.primario:hover{background:var(--navy-deep)}

.scroll{flex:1;overflow-y:auto}
.content{max-width:960px;margin:0 auto;padding:32px 32px 80px}

.vista{display:none;animation:fade .35s ease}
.vista.activa{display:block}
@keyframes fade{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
@media(prefers-reduced-motion:reduce){.vista{animation:none}}

h2.titulo{font-size:26px;font-weight:600;margin:0 0 6px;max-width:22ch}
.sub{color:var(--muted);font-size:14px;margin:0 0 22px;max-width:70ch}
.step-kicker{display:inline-flex;align-items:center;gap:8px;font-size:11.5px;font-weight:600;
  color:var(--navy);background:#e8edfb;padding:5px 12px;border-radius:30px;margin-bottom:14px}
.step-kicker.k-critica{color:var(--bad);background:var(--bad-bg)}
.step-kicker.k-oportunidad{color:var(--navy);background:#e8edfb}
.step-kicker.k-bloqueada{color:var(--warn);background:var(--warn-bg)}
.step-kicker.k-ok{color:var(--ok);background:var(--ok-bg)}

.card{background:var(--surface);border:1px solid var(--line);border-radius:var(--radius);box-shadow:var(--shadow);
  padding:22px 24px;margin:0 0 18px}
.card h3{margin:0 0 12px;font-size:15px;font-family:var(--font-body);font-weight:600}
.muted-card{background:#f2f1ec;border-style:dashed}

.grid{display:grid;gap:16px}
.g2{grid-template-columns:repeat(2,1fr)}
.g3{grid-template-columns:repeat(3,1fr)}
@media(max-width:760px){.g2,.g3{grid-template-columns:1fr}}

.kpi{background:#fff;border:1px solid var(--line);border-radius:12px;padding:16px}
.kpi .v{font-family:var(--font-display);font-size:28px;font-weight:700;color:var(--navy)}
.kpi .l{font-size:12px;color:var(--muted);margin-top:3px}

.note{font-size:12.5px;color:var(--muted);border-left:3px solid var(--navy);background:#eef1f8;
  padding:10px 14px;border-radius:0 8px 8px 0;margin-top:12px}
.note.warn{border-left-color:var(--warn);background:var(--warn-bg);color:#6b4a0e}
.note.bad{border-left-color:var(--bad);background:var(--bad-bg);color:#6f2222}
.note b{color:inherit}

.badge{display:inline-flex;align-items:center;gap:5px;font-size:11px;font-weight:700;padding:3px 9px;
  border-radius:20px;white-space:nowrap}
.b-ok{background:var(--ok-bg);color:var(--ok)}
.b-wait{background:var(--warn-bg);color:var(--warn)}
.b-no{background:var(--bad-bg);color:var(--bad)}
.b-info{background:#e8edfb;color:var(--navy)}

/* mapa de pasos (visión general + roadmap) */
.mapa{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}
@media(max-width:760px){.mapa{grid-template-columns:repeat(2,1fr)}}
.mapa .paso{background:#fff;border:1px solid var(--line);border-top:3px solid var(--muted);border-radius:12px;
  padding:14px;cursor:pointer;position:relative;transition:.15s}
.mapa .paso:hover{box-shadow:var(--shadow);transform:translateY(-2px)}
.mapa .paso.cat-critica{border-top-color:var(--bad)}
.mapa .paso.cat-oportunidad{border-top-color:var(--navy)}
.mapa .paso.cat-bloqueada{border-top-color:var(--warn)}
.mapa.static .paso{cursor:default}
.mapa.static .paso:hover{box-shadow:none;transform:none}
.mapa .paso .pn{font-size:11px;font-weight:700;color:var(--navy)}
.mapa .paso .pt{font-size:13.5px;font-weight:600;margin-top:4px}
.mapa .paso .pd{font-size:11.5px;color:var(--muted);margin-top:4px;line-height:1.4}

/* email mock */
.mail{border:1px solid var(--line);border-radius:12px;overflow:hidden;background:#fff}
.mail .head{background:#f7f8fb;border-bottom:1px solid var(--line);padding:12px 16px;font-size:12.5px}
.mail .head .row{display:flex;gap:8px;margin:2px 0}
.mail .head .k{color:#9aa5bd;width:64px;flex-shrink:0}
.mail .head .subj{font-weight:700;font-size:14px;margin-bottom:6px}
.mail .body{padding:16px 18px;font-size:13px;white-space:pre-wrap;line-height:1.6}
.mail .body .attach{margin-top:14px;display:inline-flex;align-items:center;gap:8px;border:1px solid var(--line);
  background:#f7f8fb;border-radius:9px;padding:7px 12px;font-size:12px;font-weight:600}
.ca{font-size:11px;color:#9aa5bd;font-style:italic;margin-bottom:6px;display:block}

/* tabla */
table{width:100%;border-collapse:collapse;font-size:12.5px}
th,td{padding:9px 12px;text-align:left;border-bottom:1px solid #eef0f5}
th{background:#f7f8fb;color:var(--muted);font-weight:600;font-size:11.5px;text-transform:uppercase;letter-spacing:.03em}

/* funnel comercial (cadena de pasos) */
.chain{display:grid;grid-template-columns:1fr auto 1fr auto 1fr auto 1fr auto 1fr;gap:8px;align-items:center}
@media(max-width:900px){.chain{grid-template-columns:1fr}.chain .arr{display:none}}
.chain .box{background:#fff;border:1px solid var(--line);border-radius:12px;padding:13px 10px;text-align:center}
.chain .box h4{margin:0 0 4px;font-size:12.5px;font-family:var(--font-body);font-weight:600}
.chain .box p{margin:0;font-size:11px;color:var(--muted);line-height:1.4}
.chain .arr{font-size:18px;color:#b7bfd1;text-align:center}

/* simulación: tabs + demo interactiva paso a paso */
.sim-tabs{display:flex;flex-wrap:wrap;gap:9px;margin-bottom:22px}
.sim-tab{font-size:12px;font-weight:600;color:var(--muted);background:#fff;border:1px solid var(--line);
  border-radius:20px;padding:8px 16px;cursor:pointer;transition:.15s}
.sim-tab:hover{border-color:var(--navy)}
.sim-tab.active{background:var(--navy);border-color:var(--navy);color:#fff}

.demo-wrap{display:flex;gap:26px;align-items:flex-start}
@media(max-width:820px){.demo-wrap{flex-direction:column}}
.demo-checklist{list-style:none;margin:0;padding:0;width:236px;flex:none;display:flex;flex-direction:column;gap:2px}
.demo-checklist li{display:flex;align-items:flex-start;gap:10px;padding:9px 8px;border-radius:9px;
  font-size:12.5px;color:var(--muted);cursor:pointer;transition:background .15s,color .15s}
.demo-checklist li:hover{background:#f2f4fa}
.demo-checklist li .dchk{flex:none;width:20px;height:20px;margin-top:1px;border-radius:50%;border:1.5px solid var(--line);
  display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;color:var(--muted);
  background:#fff;transition:.2s}
.demo-checklist li.active{background:#e8edfb;color:var(--navy);font-weight:600}
.demo-checklist li.active .dchk{border-color:var(--accent);color:var(--accent)}
.demo-checklist li.done{color:var(--ink)}
.demo-checklist li.done .dchk{background:var(--navy);border-color:var(--navy);color:#fff}
.demo-stage{flex:1;min-width:0;min-height:250px;display:flex;align-items:center}
.demo-stage-in{width:100%;opacity:0;transform:translateY(8px);transition:opacity .3s ease,transform .3s ease}
.demo-stage-in.in{opacity:1;transform:none}
.demo-controls{margin-top:20px;display:flex;align-items:center;gap:12px;flex-wrap:wrap}

.demo-proc{display:flex;align-items:center;gap:16px;background:#fff;border:1px solid var(--line);border-radius:12px;
  padding:22px 24px;box-shadow:0 4px 18px rgba(20,30,60,.1)}
.demo-proc .dicon{flex:none;width:38px;height:38px;border-radius:50%;background:#e8edfb;color:var(--navy);
  display:flex;align-items:center;justify-content:center;font-size:16px}
.demo-proc.thinking .dicon{animation:dpulse 1.1s ease-in-out infinite}
@keyframes dpulse{0%,100%{opacity:1}50%{opacity:.4}}
.demo-proc h4{margin:0 0 4px;font-size:14px;font-weight:600;color:var(--ink)}
.demo-proc p{margin:0;font-size:12.5px;color:var(--muted);line-height:1.4}

.slot-label{display:block;margin-top:9px;font-size:11px;font-weight:600;color:var(--muted)}

.mock{width:100%;border-radius:12px;background:#fff;box-shadow:0 4px 18px rgba(20,30,60,.14);overflow:hidden;
  border:1px solid var(--line)}
.mock-titlebar{display:flex;align-items:center;gap:6px;padding:8px 12px;font-size:11px;font-weight:600;color:#fff}
.mock-doc .mock-titlebar{background:var(--navy)}
.mock-zoho .mock-titlebar{background:#c85a2e}
.mock-body{padding:14px}
.mock-doc .line{font-size:12px;color:#33394a;padding:6px 0;border-bottom:1px dashed #ececf2;opacity:0;
  transform:translateY(4px);transition:.35s}
.mock-doc .line.in{opacity:1;transform:translateY(0)}
.mock-doc .line b{color:var(--ink)}
.mock-zoho .mock-body{background:#faf9f6;display:flex;flex-direction:column;gap:7px}
.mock-zoho .zrow{font-size:11px;color:#645f4f;background:#f0ede4;border-radius:5px;padding:8px 9px}
.mock-zoho .zrow.new{opacity:0;transform:translateY(6px);background:#eaf1ff;color:var(--navy);
  border:1px solid #c6d7f7;transition:.4s}
.mock-zoho .zrow.new.in{opacity:1;transform:translateY(0)}
.mock-aviso{width:100%;border-radius:12px;background:#fff;box-shadow:0 4px 18px rgba(20,30,60,.14);padding:13px 15px;
  display:flex;gap:11px;align-items:flex-start;opacity:0;transform:translateY(-8px);transition:.4s;
  border:1px solid var(--line)}
.mock-aviso.in{opacity:1;transform:translateY(0)}
.mock-aviso .aicon{flex:none;width:28px;height:28px;border-radius:50%;background:var(--accent);color:#fff;
  display:flex;align-items:center;justify-content:center}
.mock-aviso .aicon svg{width:15px;height:15px}
.mock-aviso .atitle{font-weight:700;font-size:12.5px;margin-bottom:2px}
.mock-aviso .abody{font-size:11.5px;color:var(--muted);line-height:1.4}

/* antes/después: comparativa */
.logs{display:grid;grid-template-columns:1fr 1fr;gap:40px;margin-top:6px}
@media(max-width:760px){.logs{grid-template-columns:1fr;gap:26px}}
.log-col h3{font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin-bottom:14px}
.log-col.antes h3{color:var(--muted)}
.log-col.despues h3{color:var(--navy)}
.log-item{display:flex;gap:12px;padding:9px 0;border-top:1px solid var(--line);font-size:13.5px}
.log-col .log-item:last-child{border-bottom:1px solid var(--line)}
.log-item time{font-size:11.5px;color:var(--muted);flex:none;width:64px;padding-top:1px}
.log-col.antes .log-item{color:var(--muted)}
.log-col.despues .log-item{opacity:0;transform:translateY(6px);transition:.4s}
.log-col.despues .log-item.in{opacity:1;transform:translateY(0)}

.status-chip{display:inline-flex;align-items:center;gap:8px;font-size:11.5px;font-weight:600;color:var(--muted)}
.status-chip .dot{width:8px;height:8px;border-radius:50%;background:var(--warn);transition:.3s}
.status-chip.done{color:var(--ok)}
.status-chip.done .dot{background:var(--ok)}

/* modelo de colaboración: icon cards */
.icongrid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px}
@media(max-width:760px){.icongrid{grid-template-columns:1fr}}
.icard{display:flex;gap:13px;align-items:flex-start;background:#fff;border:1px solid var(--line);
  border-radius:12px;padding:16px}
.icard .iico{flex:none;width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;
  background:#e8edfb;color:var(--navy)}
.icard .iico svg{width:17px;height:17px}
.icard .ititle{font-size:13.5px;font-weight:600}
.icard .icap{margin-top:3px;font-size:11.5px;color:var(--muted)}

/* presupuesto / impacto esperado (cifra de cabecera) */
.presu-total{display:flex;align-items:center;gap:20px;flex-wrap:wrap;background:linear-gradient(135deg,var(--navy),var(--navy-deep));
  color:#eaf1ff;border-radius:14px;padding:24px 26px;margin-top:4px}
.presu-total .lbl{font-size:12.5px;color:#a9bde3;font-weight:600;text-transform:uppercase;letter-spacing:.05em}
.presu-total .num{font-family:var(--font-display);font-size:42px;font-weight:700;line-height:1;letter-spacing:-.02em}
.presu-total .num small{font-size:19px;font-weight:600;margin-left:2px}
.presu-total .desc{font-size:13px;color:#c8d6f2;max-width:34ch}
.cta-row{margin-top:22px;display:flex;align-items:center;gap:16px;flex-wrap:wrap}
.btn-primary{display:inline-flex;align-items:center;gap:10px;font-size:13.5px;font-weight:600;color:#fff;
  background:var(--navy);border:1px solid var(--navy);padding:13px 22px;border-radius:10px;text-decoration:none;
  transition:background .2s}
.btn-primary:hover{background:var(--navy-deep)}

.legend{display:flex;gap:18px;flex-wrap:wrap;font-size:12px;color:var(--muted);margin-top:10px}
.legend span{display:inline-flex;align-items:center;gap:6px}
.swatch{width:12px;height:12px;border-radius:4px;display:inline-block}

.flow-progress{height:4px;background:var(--line);border-radius:30px;overflow:hidden;margin-bottom:26px}
.flow-progress .fill{height:100%;background:linear-gradient(90deg,var(--navy),var(--accent));transition:width .4s}

ul.clean{margin:8px 0 0;padding-left:18px}
ul.clean li{margin:5px 0;font-size:13px}
"""


# ---------------------------------------------------------------------------
# Helpers de render por tipo de bloque
# ---------------------------------------------------------------------------
def render_mock(mock):
    if not mock:
        return ""
    tipo = mock.get("tipo")
    if tipo == "mail":
        adjunto = ('<span class="attach">📎 %s</span>' % esc(mock.get("adjunto"))) if mock.get("adjunto") else ""
        return (
            '<div class="mail"><div class="head">'
            '<div class="subj">%s</div>'
            '<div class="row"><span class="k">De:</span> %s</div>'
            '<div class="row"><span class="k">Para:</span> %s</div>'
            '</div><div class="body"><span class="ca">%s</span>%s%s</div></div>'
        ) % (esc(mock.get("asunto")), esc(mock.get("de")), esc(mock.get("para")),
             esc(mock.get("caption")), esc(mock.get("cuerpo")).replace("\n", "\n"), adjunto)
    if tipo == "kpis":
        tiles = "".join(
            '<div class="kpi"><div class="v">%s</div><div class="l">%s</div></div>' % (esc(t.get("v")), esc(t.get("l")))
            for t in mock.get("tiles", [])
        )
        return '<div class="card"><div class="grid g3">%s</div></div>' % tiles
    if tipo == "chain":
        cols = mock.get("pasos", [])
        template_cols = "1fr auto " * (len(cols) - 1) + "1fr" if cols else "1fr"
        boxes = []
        for i, p in enumerate(cols):
            boxes.append('<div class="box"><h4>%s</h4><p>%s</p></div>' % (esc(p.get("titulo")), esc(p.get("texto"))))
            if i < len(cols) - 1:
                boxes.append('<div class="arr">→</div>')
        return '<div class="card"><div class="chain" style="grid-template-columns:%s">%s</div></div>' % (
            template_cols, "".join(boxes)
        )
    return ""


def render_nota(nota):
    if not nota:
        return ""
    cls = "note" + (" " + nota["tipo"] if nota.get("tipo") else "")
    return '<div class="%s">%s</div>' % (cls, nota.get("texto", ""))


def render_area_vista(area, data_v):
    kicker_cls = "k-critica" if area.get("prioridad") == "critica" else "k-oportunidad"
    return (
        '<section class="vista" data-v="%d">\n'
        '  <div class="step-kicker %s">%s</div>\n'
        '  <h2 class="titulo">%s</h2>\n'
        '  <p class="sub">%s</p>\n'
        '  %s\n'
        '  %s\n'
        '</section>\n'
    ) % (
        data_v, kicker_cls, esc(area.get("kicker")), esc(area.get("titulo")), esc(area.get("sub")),
        render_mock(area.get("mock")), render_nota(area.get("nota")),
    )


def render_mapa_visiongeneral(areas):
    cards = []
    for i, a in enumerate(areas, start=1):
        cards.append(
            '<div class="paso cat-%s" data-go="%d"><div class="pn">ÁREA %d</div>'
            '<div class="pt">%s</div><div class="pd">%s</div></div>'
            % (a.get("prioridad", "oportunidad"), i, i, esc(a.get("nombre")), esc(a.get("resumen_mapa")))
        )
    return "".join(cards)


def render_mapa_roadmap(roadmap, areas_by_id):
    cards = []
    for i, fase in enumerate(roadmap, start=1):
        area = areas_by_id.get(fase.get("area_id"), {})
        prioridad = "critica" if i == 1 else "oportunidad"
        cards.append(
            '<div class="paso cat-%s"><div class="pn">FASE %d</div>'
            '<div class="pt">%s</div><div class="pd">%s</div></div>'
            % (prioridad, i, esc(area.get("nombre", fase.get("area_id"))), esc(fase.get("descripcion")))
        )
    return "".join(cards)


DEFAULT_MODELO_COLABORACION = [
    {"icono": "⇄", "titulo": "Vuestras herramientas, no otras nuevas", "texto": "Nada nuevo que aprender: se integra con lo que ya usáis."},
    {"icono": "◎", "titulo": "Empezamos por lo urgente", "texto": "La prioridad primero, sin alcance cerrado de meses."},
    {"icono": "✓", "titulo": "Desarrollo, PM, IA, formación y soporte", "texto": "Un único acompañamiento mensual."},
    {"icono": "↺", "titulo": "Sin permanencia", "texto": "Cancelable cualquier mes."},
]


def render_icongrid(items):
    return "".join(
        '<div class="icard"><span class="iico">%s</span><div><div class="ititle">%s</div>'
        '<div class="icap">%s</div></div></div>' % (esc(it.get("icono")), esc(it.get("titulo")), esc(it.get("texto")))
        for it in items
    )


def render_impacto_esperado(impacto):
    por_area = "".join(
        '<div class="kpi"><div class="v">%s</div><div class="l">%s</div></div>' % (esc(a.get("valor")), esc(a.get("etiqueta")))
        for a in impacto.get("por_area", [])
    )
    destacados = render_icongrid(impacto.get("destacados", []))
    valor_block = ""
    if impacto.get("valor_eur_mes") is not None:
        valor_block = (
            '<div style="border-left:1px solid rgba(255,255,255,.15);padding-left:20px">'
            '<div class="lbl">Valor liberado</div><div class="num">%s<small> € / mes</small></div></div>'
        ) % esc(impacto["valor_eur_mes"])
    return (
        '<div class="presu-total">'
        '<div><div class="lbl">Tiempo liberado</div><div class="num">%s<small> h / mes</small></div></div>'
        '%s'
        '<div style="width:100%%;margin-top:14px;padding-top:14px;border-top:1px solid rgba(255,255,255,.15);'
        'font-size:12.5px;color:#c8d6f2">%s</div>'
        '</div>'
        '<div class="card" style="margin-top:18px"><h3>Tiempo liberado por área</h3>'
        '<div class="grid g3">%s</div></div>'
        '<div class="card"><h3>Más allá del tiempo</h3><div class="icongrid">%s</div></div>'
        '<div class="note">%s</div>'
    ) % (
        esc(impacto.get("horas_mes")), valor_block, esc(impacto.get("nota_headline")),
        por_area, destacados, esc(impacto.get("nota_final")),
    )


def render_presupuesto(p):
    incluye = "".join("<li>%s</li>" % esc(i) for i in p.get("incluye", []))
    iva = '<div class="iva" style="font-size:12px;color:#c8d6f2;margin-top:3px">(sin IVA)</div>' if p.get("sin_iva", True) else ""
    return (
        '<div class="presu-total">'
        '<div><div class="lbl">Cuota mensual</div><div class="num">%s<small> € / mes</small></div>%s</div>'
        '<div class="desc"><ul class="clean" style="color:inherit">%s</ul>'
        '<div style="margin-top:10px">%s</div></div>'
        '</div>'
        '<div class="note" style="margin-top:18px">%s</div>'
    ) % (esc(p.get("cuota_mensual")), iva, incluye, esc(p.get("condiciones")), esc(p.get("nota_exclusiones")))


# ---------------------------------------------------------------------------
# Ensamblado principal
# ---------------------------------------------------------------------------
def ensamblar(c, logo_path=None):
    """c: dict de contenido (ver referencia-kpis.md y SKILL.md para el esquema).
    logo_path: ruta al logo del negocio (CONTEXT/branding/logo.<ext>); si es None o no
    existe, la propuesta se genera sin imagen de logo. Devuelve el HTML final (str)."""
    areas = c["areas"]
    areas_by_id = {a["id"]: a for a in areas}
    n = len(areas)
    tiene_fase1 = bool(c.get("fase1_en_marcha"))

    # --- construir, EN ORDEN, la lista de secciones fijas tras las áreas ---
    secciones_fijas = []
    secciones_fijas.append({
        "crumb": "Soluciones · <b>Cómo funciona</b>", "cat": "oportunidad", "nav": ("Cómo funciona", "seq"),
    })
    if tiene_fase1:
        f1 = c["fase1_en_marcha"]
        secciones_fijas.append({
            "crumb": "Soluciones · <b>Fase 1 en marcha</b>", "cat": "critica", "nav": ("Fase 1 en marcha", "seq"),
        })
    secciones_fijas.append({
        "crumb": "Soluciones · <b>Modelo de colaboración</b>", "cat": "oportunidad", "nav": ("Modelo de colaboración", "seq"),
    })
    secciones_fijas.append({
        "crumb": "Roadmap · <b>De transformación</b>", "cat": "oportunidad", "nav": ("Roadmap de transformación", "seq"),
    })
    secciones_fijas.append({
        "crumb": "Impacto · <b>Impacto esperado</b>", "cat": "impacto", "nav": ("Impacto esperado", "seq"),
    })
    secciones_fijas.append({
        "crumb": "Presupuesto · <b>Cierre</b>", "cat": "ok", "nav": ("Presupuesto", "€"),
    })

    idx_como_funciona = 1 + n
    idx_fase1 = 1 + n + 1 if tiene_fase1 else None
    idx_modelo = idx_fase1 + 1 if tiene_fase1 else idx_como_funciona + 1
    idx_roadmap = idx_modelo + 1
    idx_impacto = idx_roadmap + 1
    idx_presupuesto = idx_impacto + 1
    total_vistas = idx_presupuesto + 1

    # --- crumbs / cats ---
    crumbs = ["Recorrido · <b>Visión general</b>"]
    cats = ["info"]
    for a in areas:
        crumbs.append("Necesidades · <b>%s</b>" % esc(a.get("nombre")))
        cats.append(a.get("prioridad", "oportunidad"))
    for s in secciones_fijas:
        crumbs.append(s["crumb"])
        cats.append(s["cat"])

    # --- nav sidebar ---
    nav_parts = ['<div class="grp">Recorrido</div>',
                 '<button data-v="0"><span class="n">●</span> Visión general</button>']
    nav_parts.append('<div class="grp">1 · Necesidades detectadas</div>')
    for i, a in enumerate(areas, start=1):
        nav_parts.append('<button data-v="%d"><span class="n">%d</span> %s</button>' % (i, i, esc(a.get("nombre"))))
    nav_parts.append('<div class="grp">2 · Posibles soluciones</div>')
    seq = n + 1
    nav_parts.append('<button data-v="%d"><span class="n">%d</span> Cómo funciona</button>' % (idx_como_funciona, seq)); seq += 1
    if tiene_fase1:
        nav_parts.append('<button data-v="%d"><span class="n">%d</span> Fase 1 en marcha</button>' % (idx_fase1, seq)); seq += 1
    nav_parts.append('<button data-v="%d"><span class="n">%d</span> Modelo de colaboración</button>' % (idx_modelo, seq)); seq += 1
    nav_parts.append('<div class="grp">3 · Roadmap</div>')
    nav_parts.append('<button data-v="%d"><span class="n">%d</span> Roadmap de transformación</button>' % (idx_roadmap, seq)); seq += 1
    nav_parts.append('<div class="grp">4 · Impacto esperado</div>')
    nav_parts.append('<button data-v="%d"><span class="n">%d</span> Impacto esperado</button>' % (idx_impacto, seq)); seq += 1
    nav_parts.append('<div class="grp">5 · Presupuesto</div>')
    nav_parts.append('<button data-v="%d"><span class="n">€</span> Presupuesto</button>' % idx_presupuesto)
    nav_html = "\n      ".join(nav_parts)

    # --- vistas ---
    vistas = []
    vistas.append(
        '<section class="vista activa" data-v="0">\n'
        '  <h2 class="titulo">%s</h2>\n  <p class="sub">%s</p>\n'
        '  <div class="card"><h3>Mapa de áreas</h3><div class="mapa" id="mapa">%s</div>'
        '  <div class="legend"><span><i class="swatch" style="background:var(--bad)"></i> Prioridad crítica</span>'
        '  <span><i class="swatch" style="background:var(--navy)"></i> Oportunidad</span></div></div>\n'
        '  <div class="card muted-card"><h3>Objetivo</h3>'
        '  <p style="margin:0;font-size:13.5px;color:var(--ink)">%s</p></div>\n'
        '</section>\n' % (esc(c.get("vision_titulo")), esc(c.get("vision_sub")), render_mapa_visiongeneral(areas), esc(c.get("vision_objetivo")))
    )
    for i, a in enumerate(areas, start=1):
        vistas.append(render_area_vista(a, i))

    sim_tabs = "".join(
        '<button class="sim-tab%s" data-phase="%s" type="button">%s</button>'
        % (" active" if i == 0 else "", esc(a["id"]), esc(a.get("nombre")))
        for i, a in enumerate(areas)
    )
    vistas.append(
        '<section class="vista" data-v="%d">\n'
        '  <div class="step-kicker k-oportunidad">POSIBLES SOLUCIONES</div>\n'
        '  <h2 class="titulo">Cómo funciona, área a área.</h2>\n'
        '  <p class="sub">Elige un área. Reproduce la secuencia completa o avanza paso a paso para ver el detalle de cada automatización, de principio a fin.</p>\n'
        '  <div class="sim-tabs">%s</div>\n'
        '  <div class="card"><div class="demo-wrap"><ol class="demo-checklist" id="demoChecklist"></ol>'
        '  <div class="demo-stage" id="demoStage"></div></div>'
        '  <div class="demo-controls"><button class="navbtn" id="simPrev" type="button">‹ Paso anterior</button>'
        '  <button class="navbtn primario" id="simPlay" type="button">Reproducir</button>'
        '  <button class="navbtn" id="simNext" type="button">Paso siguiente ›</button>'
        '  <span class="status-chip" id="simChipStatus"><span class="dot"></span>'
        '  <span class="chip-text">Listo para reproducir</span></span></div></div>\n'
        '</section>\n' % (idx_como_funciona, sim_tabs)
    )

    if tiene_fase1:
        f1 = c["fase1_en_marcha"]
        antes = "".join('<div class="log-item"><time>%s</time><span>%s</span></div>' % (esc(x.get("time")), esc(x.get("texto"))) for x in f1.get("antes", []))
        despues = "".join('<div class="log-item"><time>%s</time><span>%s</span></div>' % (esc(x.get("time")), esc(x.get("texto"))) for x in f1.get("despues", []))
        vistas.append(
            '<section class="vista" data-v="%d">\n'
            '  <div class="step-kicker k-critica">FASE 1 · %s</div>\n'
            '  <h2 class="titulo">%s</h2>\n'
            '  <div class="card"><div class="logs">'
            '  <div class="log-col antes"><h3>Antes</h3>%s</div>'
            '  <div class="log-col despues"><h3>Con %s</h3>%s</div></div>'
            '  <div style="margin-top:18px;display:flex;align-items:center;gap:16px;flex-wrap:wrap">'
            '  <span class="status-chip" id="emChip"><span class="dot"></span><span class="chip-text">En curso…</span></span>'
            '  <button class="navbtn" id="emReplay" type="button">Reproducir de nuevo</button></div></div>\n'
            '  <div class="note">%s</div>\n'
            '</section>\n' % (idx_fase1, esc(f1.get("area_nombre", "")).upper(), esc(f1.get("titulo")), antes, esc(BRANDING["empresa"]), despues, esc(f1.get("nota", "Ejemplo ilustrativo, con tiempos representativos.")))
        )

    modelo = c.get("modelo_colaboracion") or DEFAULT_MODELO_COLABORACION
    vistas.append(
        '<section class="vista" data-v="%d">\n'
        '  <div class="step-kicker k-oportunidad">POSIBLES SOLUCIONES</div>\n'
        '  <h2 class="titulo">Acompañamiento continuo, no un proyecto cerrado.</h2>\n'
        '  <p class="sub">%s</p>\n'
        '  <div class="card"><div class="icongrid">%s</div></div>\n'
        '</section>\n' % (idx_modelo, esc(c.get("modelo_colaboracion_sub",
            "Una colaboración a largo plazo — no un proyecto puntual. Así se estructura ese acompañamiento.")),
            render_icongrid(modelo))
    )

    vistas.append(
        '<section class="vista" data-v="%d">\n'
        '  <div class="step-kicker k-oportunidad">ROADMAP</div>\n'
        '  <h2 class="titulo">%s</h2>\n'
        '  <div class="card"><div class="mapa static">%s</div>'
        '  <div class="legend"><span><i class="swatch" style="background:var(--bad)"></i> Prioridad crítica</span>'
        '  <span><i class="swatch" style="background:var(--navy)"></i> Prioridad media</span></div></div>\n'
        '  <div class="note">%s</div>\n'
        '</section>\n' % (idx_roadmap, esc(c.get("roadmap_titulo", "Fases, por orden de prioridad.")),
            render_mapa_roadmap(c["roadmap"], areas_by_id),
            esc(c.get("roadmap_nota", "Cada fase se incorpora a vuestro ritmo, sin esperar a que estén todas cerradas.")))
    )

    imp = c["impacto_esperado"]
    vistas.append(
        '<section class="vista" data-v="%d">\n'
        '  <div class="step-kicker k-ok">IMPACTO ESPERADO</div>\n'
        '  <h2 class="titulo">%s</h2>\n'
        '  <p class="sub">%s</p>\n'
        '  %s\n'
        '</section>\n' % (idx_impacto, esc(imp.get("titulo", "Lo que esto libera cada mes.")), esc(imp.get("sub")), render_impacto_esperado(imp))
    )

    pres = c["presupuesto"]
    vistas.append(
        '<section class="vista" data-v="%d">\n'
        '  <div class="step-kicker k-oportunidad">PRESUPUESTO</div>\n'
        '  <h2 class="titulo">%s</h2>\n'
        '  <p class="sub">%s</p>\n'
        '  %s\n'
        '</section>\n' % (idx_presupuesto, esc(pres.get("titulo")), esc(pres.get("sub", "")), render_presupuesto(pres))
    )

    # --- FASES (motor de simulación) ---
    fases_js = {a["id"]: {"steps": a.get("simulacion", [])} for a in areas}

    empresa = esc(BRANDING["empresa"])
    head_title = "Propuesta · %s · %s" % (esc(c.get("cliente")), empresa)
    sidebar_sub = "%s — Propuesta de automatización<br>Reunión de descubrimiento · %s" % (
        esc(c.get("cliente")), esc(c.get("fecha_reunion")))
    pie = "Datos de ejemplo ilustrativos · basados en la reunión de descubrimiento del %s." % esc(c.get("fecha_reunion"))
    if BRANDING["email"]:
        pie += "<br>%s" % esc(BRANDING["email"])

    fase1_check_js = ("if (actual === %d) playEnMarcha();" % idx_fase1) if tiene_fase1 else "// sin sección de fase 1 en marcha"

    # Logo del negocio (CONTEXT/branding/logo.<ext>). Sin logo → sin <img> (R6).
    logo_uri = logo_data_uri(logo_path)
    favicon_tag = ('<link rel="icon" href="%s">' % logo_uri) if logo_uri else ""
    logo_img = ('<img src="%s" alt=""> ' % logo_uri) if logo_uri else ""

    html = """<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex,nofollow">
<title>%(title)s</title>
%(favicon_tag)s
<style>%(css)s</style>
</head>
<body>
<div class="app">
  <aside class="sidebar">
    <div class="brand">
      <div class="logo">%(logo_img)s%(empresa)s</div>
      <p>%(sidebar_sub)s</p>
    </div>
    <nav class="nav" id="nav">
      %(nav)s
    </nav>
    <div class="pie">%(pie)s</div>
  </aside>
  <div class="main">
    <div class="topbar">
      <div class="crumb" id="crumb">Recorrido · <b>Visión general</b></div>
      <span class="pill info" id="pill">Recorrido completo</span>
      <div class="right">
        <button class="navbtn" id="prev">‹ Anterior</button>
        <button class="navbtn primario" id="next">Siguiente ›</button>
      </div>
    </div>
    <div class="scroll">
      <div class="content">
        <div class="flow-progress"><div class="fill" id="fill" style="width:0%%"></div></div>
        %(vistas)s
      </div>
    </div>
  </div>
</div>
<script>
"use strict";
(function(){
  var vistas = Array.prototype.slice.call(document.querySelectorAll('.vista'));
  var botones = Array.prototype.slice.call(document.querySelectorAll('#nav button'));
  var crumbs = %(crumbs_json)s;
  var cats = %(cats_json)s;
  var pills = {
    info:        {cls:"pill info",        txt:"Recorrido completo"},
    critica:     {cls:"pill critica",     txt:"Prioridad crítica"},
    oportunidad: {cls:"pill oportunidad", txt:"Oportunidad de mejora"},
    bloqueada:   {cls:"pill bloqueada",   txt:"Bloqueada — a resolver"},
    impacto:     {cls:"pill ok",          txt:"Impacto esperado"},
    ok:          {cls:"pill ok",          txt:"Presupuesto"}
  };
  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var actual = 0;

  function after(ms, fn){ if (reduceMotion) fn(); else setTimeout(fn, ms); }

  function ir(i){
    actual = Math.max(0, Math.min(vistas.length - 1, i));
    vistas.forEach(function(v, k){ v.classList.toggle('activa', k === actual); });
    botones.forEach(function(b){ b.classList.toggle('activo', +b.dataset.v === actual); });
    document.getElementById('crumb').innerHTML = crumbs[actual];
    var pill = document.getElementById('pill');
    var p = pills[cats[actual]];
    pill.className = p.cls;
    pill.textContent = p.txt;
    document.getElementById('fill').style.width = (actual / (vistas.length - 1) * 100) + '%%';
    document.getElementById('prev').disabled = actual === 0;
    document.getElementById('next').disabled = actual === vistas.length - 1;
    document.querySelector('.scroll').scrollTop = 0;
    %(fase1_check)s
  }
  botones.forEach(function(b){ b.addEventListener('click', function(){ ir(+b.dataset.v); }); });
  document.getElementById('prev').addEventListener('click', function(){ ir(actual - 1); });
  document.getElementById('next').addEventListener('click', function(){ ir(actual + 1); });
  document.querySelectorAll('#mapa .paso[data-go]').forEach(function(p){
    p.addEventListener('click', function(){ ir(+p.dataset.go); });
  });

  // ---- Simulación: demo interactiva paso a paso ----
  var FASES = %(fases_json)s;

  var simTabs = Array.prototype.slice.call(document.querySelectorAll(".sim-tab"));
  var demoChecklist = document.getElementById("demoChecklist");
  var demoStage = document.getElementById("demoStage");
  var simChip = document.getElementById("simChipStatus");
  var simPlayBtn = document.getElementById("simPlay");
  var simPrevBtn = document.getElementById("simPrev");
  var simNextBtn = document.getElementById("simNext");

  var simPhaseKey = %(primera_area_id_json)s;
  var simIndex = 0;
  var simTimers = [];

  function simClearTimers(){ simTimers.forEach(clearTimeout); simTimers = []; }
  function simAfter(ms, fn){ if (reduceMotion){ fn(); } else { simTimers.push(setTimeout(fn, ms)); } }

  function stepHTML(step){
    if (step.kind === "doc"){
      var lines = step.lines.map(function(l){ return '<div class="line in">' + l[0] + ': <b>' + l[1] + '</b></div>'; }).join("");
      return '<div class="mock mock-doc"><div class="mock-titlebar">' + step.bar + '</div><div class="mock-body">' + lines + '</div></div><span class="slot-label">' + (step.label || "Documento") + '</span>';
    }
    if (step.kind === "zoho"){
      var rows = step.rows.map(function(r){ return '<div class="zrow' + (r.neu ? ' new in' : '') + '">' + r.txt + '</div>'; }).join("");
      return '<div class="mock mock-zoho"><div class="mock-titlebar">' + step.bar + '</div><div class="mock-body">' + rows + '</div></div><span class="slot-label">' + (step.label || "Se guarda en Zoho") + '</span>';
    }
    if (step.kind === "aviso"){
      return '<div class="mock-aviso in"><span class="aicon">✓</span><div><div class="atitle">' + step.title + '</div><div class="abody">' + step.desc + '</div></div></div><span class="slot-label">Aviso</span>';
    }
    return '<div class="demo-proc thinking"><div class="dicon">⚙</div><div><h4>' + step.title + '</h4><p>' + step.desc + '</p></div></div>';
  }

  function renderChecklist(){
    var steps = FASES[simPhaseKey].steps;
    demoChecklist.innerHTML = steps.map(function(s, i){
      return '<li data-i="' + i + '"><span class="dchk">' + (i + 1) + '</span><span>' + s.title + '</span></li>';
    }).join("");
    Array.prototype.slice.call(demoChecklist.querySelectorAll("li")).forEach(function(li){
      li.addEventListener("click", function(){ simGoTo(+li.dataset.i); });
    });
  }

  function updateChecklistState(){
    Array.prototype.slice.call(demoChecklist.querySelectorAll("li")).forEach(function(li, i){
      li.classList.toggle("active", i === simIndex);
      li.classList.toggle("done", i < simIndex);
    });
  }

  function updateNav(){
    var len = FASES[simPhaseKey].steps.length;
    simPrevBtn.disabled = simIndex === 0;
    simNextBtn.disabled = simIndex === len - 1;
  }

  function updateChip(){
    var len = FASES[simPhaseKey].steps.length;
    if (!simChip) return;
    simChip.classList.toggle("done", simIndex === len - 1);
    var txt = simIndex === 0 ? "Listo para reproducir" : (simIndex === len - 1 ? "Completado sin intervención manual" : "En curso…");
    simChip.querySelector(".chip-text").textContent = txt;
  }

  function showStep(i){
    var steps = FASES[simPhaseKey].steps;
    simIndex = Math.max(0, Math.min(steps.length - 1, i));
    updateChecklistState();
    updateNav();
    updateChip();
    demoStage.innerHTML = '<div class="demo-stage-in">' + stepHTML(steps[simIndex]) + '</div>';
    var wrap = demoStage.querySelector(".demo-stage-in");
    requestAnimationFrame(function(){ requestAnimationFrame(function(){ wrap.classList.add("in"); }); });
  }

  function simGoTo(i){ simClearTimers(); showStep(i); }

  function playSim(){
    simClearTimers();
    var steps = FASES[simPhaseKey].steps;
    showStep(0);
    for (var i = 1; i < steps.length; i++){
      (function(idx){ simAfter(idx * 1300, function(){ showStep(idx); }); })(i);
    }
  }

  function selectPhase(key){
    simClearTimers();
    simPhaseKey = key;
    simTabs.forEach(function(t){ t.classList.toggle("active", t.dataset.phase === key); });
    renderChecklist();
    showStep(0);
  }

  simTabs.forEach(function(tab){ tab.addEventListener("click", function(){ selectPhase(tab.dataset.phase); }); });
  if (simPlayBtn) simPlayBtn.addEventListener("click", playSim);
  if (simPrevBtn) simPrevBtn.addEventListener("click", function(){ simGoTo(simIndex - 1); });
  if (simNextBtn) simNextBtn.addEventListener("click", function(){ simGoTo(simIndex + 1); });

  renderChecklist();
  showStep(0);

  // ---- Antes/después (si existe) ----
  var emColItems = Array.prototype.slice.call(document.querySelectorAll(".log-col.despues .log-item"));
  var emChip = document.getElementById("emChip");
  var emReplayBtn = document.getElementById("emReplay");

  function playEnMarcha(){
    emColItems.forEach(function(it){ it.classList.remove("in"); });
    if (emChip){ emChip.classList.remove("done"); emChip.querySelector(".chip-text").textContent = "En curso…"; }
    emColItems.forEach(function(it, i){ after(300 + i * 450, function(){ it.classList.add("in"); }); });
    after(300 + emColItems.length * 450 + 350, function(){
      if (emChip){ emChip.classList.add("done"); emChip.querySelector(".chip-text").textContent = "Completado sin intervención manual"; }
    });
  }
  if (emReplayBtn) emReplayBtn.addEventListener("click", playEnMarcha);

  ir(0);
})();
</script>
</body>
</html>
""" % {
        "title": head_title,
        "favicon_tag": favicon_tag,
        "css": build_css(BRANDING),
        "logo_img": logo_img,
        "empresa": empresa,
        "sidebar_sub": sidebar_sub,
        "nav": nav_html,
        "pie": pie,
        "vistas": "\n".join(vistas),
        "crumbs_json": json.dumps(crumbs, ensure_ascii=False),
        "cats_json": json.dumps(cats, ensure_ascii=False),
        "fase1_check": fase1_check_js,
        "fases_json": json.dumps(fases_js, ensure_ascii=False, indent=2),
        "primera_area_id_json": json.dumps(areas[0]["id"]),
    }
    return html


def main():
    if len(sys.argv) not in (3, 4):
        print("Uso: py -X utf8 ensamblar_html.py contenido.json salida.html [logo.<ext>]")
        sys.exit(1)
    with open(sys.argv[1], "r", encoding="utf-8") as f:
        contenido = json.load(f)
    logo_path = sys.argv[3] if len(sys.argv) == 4 else None
    html = ensamblar(contenido, logo_path=logo_path)
    with open(sys.argv[2], "w", encoding="utf-8") as f:
        f.write(html)
    print("Generado:", sys.argv[2])


if __name__ == "__main__":
    main()
