---
name: automatizar
description: Convierte una tarea repetida en una skill o automatización reutilizable. Úsala cuando el usuario diga "automatiza esto", "conviértelo en skill", "haz un comando para esto", o acepte una propuesta del radar de automatización. Primero presenta una propuesta clara (qué hace el código sin IA y qué hace la IA, con modelo recomendado) y espera aprobación antes de construir.
---

# Skill: automatizar una tarea

Convierte una tarea manual repetida en un paquete reutilizable (skill global o
automatización de proyecto), siguiendo el patrón de la skill `informe`: paquete
autocontenido, motor determinista sin IA, y la IA solo donde aporta.

**Regla de oro: no se construye nada hasta que el usuario aprueba la propuesta del paso 1.**

## Paso 1 — Propuesta (SIEMPRE primero, antes de tocar archivos)

Captura la tarea (qué hace, qué recibe, qué produce). Si se lanza justo después de
hacerla, usa ese contexto; si falta algo esencial, pregunta una vez de forma agrupada.

Luego **enséñale a el usuario la propuesta** en este formato, claro y sin jerga:

```
Propuesta: <nombre> — <qué hace en una frase>

Entrada: <archivos/datos que recibe>
Salida:  <qué produce y dónde>

Qué hace el CÓDIGO (sin IA, determinista, no gasta tokens):
- <paso 1>
- <paso 2>

Qué hace la IA:
- <parte que necesita IA y por qué>
- Modelo recomendado: <haiku | sonnet | opus> — <motivo>

Ubicación propuesta: <global ~/.claude/skills/<n>/  |  proyecto <ruta>>  (porque <criterio>)
```

Guía para recomendar modelo (parte de IA):
- **haiku** — tareas simples y acotadas: clasificar, extraer campos, formato ligero, respuestas cortas.
- **sonnet** (por defecto) — redacción y síntesis con calidad y buen equilibrio coste/resultado.
- **opus** — razonamiento complejo, documentos delicados o máxima calidad.
- Si una tarea puede resolverse **entera por código sin IA**, dilo: es lo ideal (coste cero, determinista).

Termina el paso 1 preguntando: "¿Lo construyo así o ajusto algo?". **Espera respuesta.**

## Paso 2 — Ubicación (tras aprobación)

Confirma dónde va, según el criterio:
- **General / transversal** (sirve en varios proyectos/clientes sin cambios) → skill global
  en `~/.claude/skills/<nombre>/`, autocontenido.
- **Específico de un proyecto/cliente** (depende de sus datos, contexto o reglas) → dentro
  del proyecto: `AUTOMATION/` (scripts) y, si es invocable, `.claude/skills/<nombre>/`.
- Si parte es general y parte específica: motor general en global, configuración/plantilla
  específica en el proyecto.

## Paso 3 — Separar motor de IA

Implementa como código determinista todo lo que no requiera juicio (formato, parseo,
transformación, empaquetado). Reserva la IA solo para la parte aprobada en el paso 1,
y llámala con el modelo recomendado (vía CLI de Claude, sin API key, como hace
`~/.claude/skills/informe/scripts/generar-informe.py`).

## Paso 4 — Construir el paquete autocontenido

Crea la carpeta con `SKILL.md` + `scripts/` + recursos/`plantillas/` dentro, de modo
que funcione desde cualquier carpeta de trabajo. Las rutas a recursos se resuelven
relativas al propio skill; las de salida, relativas al proyecto donde se ejecuta.

## Paso 5 — Probar con un caso real

Haz una prueba de humo (preferiblemente solo el motor sin IA, para no gastar tokens)
que confirme que genera la salida esperada. Si falla, corrige antes de darla por buena.

## Paso 6 — Guardar y registrar

Deja el paquete en su sitio y anota en la memoria del proyecto qué automatización
existe ya (nombre, qué hace, ubicación), para no duplicarla y reconocer tareas parecidas.

## Paso 7 — Confirmar

Reporta en una o dos líneas: nombre, qué hace y cómo invocarla.
