# HISTÓRICO — {{NOMBRE_PROYECTO}}

> Registro cronológico de hitos y decisiones del proyecto (más reciente primero).

---

- **{{FECHA}}** — Proyecto creado a partir de la plantilla del AIOS.
