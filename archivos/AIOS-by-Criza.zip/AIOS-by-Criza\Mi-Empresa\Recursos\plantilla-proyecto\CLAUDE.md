# AIOS — Proyecto: {{NOMBRE_PROYECTO}}

Esta es la carpeta de un **proyecto** del AIOS: un cliente o iniciativa concreta de
**{{NOMBRE_NEGOCIO}}**. Es hermana de `Mi-Empresa/` (vive en `Proyectos/{{NOMBRE_PROYECTO}}/`),
con su propio contexto, su propio trabajo y su propio repositorio Git.

> Esto es un **proyecto**, no la raíz del negocio. Lo declara el marcador `.aios-proyecto`
> de esta carpeta. Quién es el negocio (**{{NOMBRE_NEGOCIO}}**) ya está definido en
> `Mi-Empresa/CONTEXT/`; aquí solo vive lo específico de **{{NOMBRE_PROYECTO}}**.

Las herramientas (comandos, skills, agentes) y las conexiones se **heredan** de la
configuración del ordenador (`~/.claude`), instaladas una sola vez para todo el negocio.
No se reinstala ni se reconecta nada dentro de este proyecto.

## Cómo empezar

Si esta carpeta aún no conoce el proyecto (no hay `CONTEXT/proyecto.md`), ejecuta
**`/onboarding`**. Al detectar el marcador `.aios-proyecto`, te ofrecerá **solo la Fase 1
(Contexto de proyecto)**: una entrevista corta sobre este cliente/iniciativa (o importa un
archivo que ya tengas) y escribe él mismo `CONTEXT/proyecto.md`. No repetirá la
Infraestructura (Git/GitHub) ni los Datos: ya están resueltos a nivel de tu ordenador.

## Dos modos de trabajo

- **Operación** (por defecto): preguntas, consultas, registro del día a día del proyecto →
  responde directo. Lee lo necesario de `CONTEXT/proyecto.md` (y del negocio en
  `../../Mi-Empresa/CONTEXT/` cuando haga falta contexto de empresa).
- **Construcción**: crear/automatizar algo para este proyecto → flujo del harness
  (`~/.claude/harness/AGENTS.md`). **Nada se construye sin aprobación.**

## Reglas duras

1. **Empieza por el contexto**: antes de actuar, lee lo relevante de `CONTEXT/proyecto.md`.
   No lo abras entero por defecto.
2. **No repites lo del negocio**: lo que ya describe `Mi-Empresa/CONTEXT/` no se vuelve a
   preguntar ni a copiar aquí; se hereda.
3. **Construir = aprobación previa**: presenta el plan y espera el visto bueno antes de
   tocar nada.
4. **Nunca commitees credenciales**: van en `.env` (variables de entorno), fuera del repo.

## Pointers

- Identidad de este proyecto → `CONTEXT/proyecto.md`
- Identidad del negocio (heredada) → `../../Mi-Empresa/CONTEXT/`
- Onboarding del proyecto → comando `/onboarding` (Fase 1)
- Guardar el trabajo → comando `/commit`
- Construcción (harness) → `~/.claude/harness/AGENTS.md`
- Comandos y skills → `~/.claude/` (heredados, sin reinstalar)

Idioma de trabajo: **español**.
