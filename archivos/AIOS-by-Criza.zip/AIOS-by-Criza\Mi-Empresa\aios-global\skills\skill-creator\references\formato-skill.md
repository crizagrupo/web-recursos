# Formato de una skill — reglas (no inventar formato)

Referencia para la skill `skill-creator`. Define **cómo debe estar hecha** una skill para
que Claude Code la reconozca y la lance en el momento adecuado. **Regla base: no se inventa
formato.** Se usa exactamente el mismo esquema que ya usan las skills de este proyecto
(`informe`, `automatizar`, y las de AIOS-by-Criza v2 como `onboarding-contexto`,
`task-audit`, `mcp-integration`): frontmatter `---` con `name` y `description`, y cuerpo
Markdown debajo.

---

## 1. Estructura de carpeta

Una skill es **una carpeta** en `kebab-case` que contiene, como mínimo, un archivo
`SKILL.md`:

```
<nombre-skill>/
├── SKILL.md          ← obligatorio
├── scripts/          ← opcional: solo si la skill ejecuta código determinista
└── references/       ← opcional: solo si la skill carga material de consulta bajo demanda
```

- El **nombre de la carpeta** debe coincidir **exactamente** con el campo `name` del
  frontmatter de `SKILL.md`.
- `scripts/` y `references/` **solo se crean si la skill las necesita**. Nunca se crean
  vacías "por si acaso" (una skill que solo es un protocolo de conversación no lleva
  ninguna de las dos).

## 2. Frontmatter de `SKILL.md` (obligatorio)

Al principio del archivo, un bloque YAML delimitado por `---` … `---` con **dos campos
obligatorios**, ambos con valor no vacío:

```markdown
---
name: nombre-de-la-skill
description: Qué hace la skill y cuándo debe usarse (los disparadores que la activan).
---
```

- **`name`** — en `kebab-case` (minúsculas, palabras separadas por guiones: `a-z`, `0-9`
  y `-`). Coincide con el nombre de la carpeta. **Máximo 64 caracteres.**
- **`description`** — describe **qué hace** la skill **y cuándo usarse**. Es lo que Claude
  Code lee para decidir si activarla, así que debe nombrar los disparadores (situaciones,
  comandos o frases que la lanzan). **Máximo 1024 caracteres.**

No se añaden otros campos (`version`, `tags`, `autor`, `dependencies`…): Claude Code no los
usa y romperían la compatibilidad con las skills existentes. Si más adelante hiciera falta
metadata, se decide aparte; por defecto, solo `name` y `description`.

### Cómo escribir una buena `description`
Patrón de las skills existentes: **una frase que empieza por el qué y encadena el cuándo.**
Ejemplos reales de este proyecto:

- `onboarding-contexto`: "Conduce la Fase 1 (Contexto) del onboarding del AIOS. Entrevista
  al dueño del negocio… La invoca el comando /onboarding cuando no existe CONTEXT/negocio.md."
- `task-audit`: "Conduce la auditoría de tareas del AIOS… La invoca el comando /task-audit."

Es decir: primero qué resuelve, luego **el disparador explícito** (qué comando o situación
la lanza). Sin disparador, Claude Code no sabrá cuándo usarla.

## 3. Cuerpo de `SKILL.md` (debajo del frontmatter)

Markdown normal. Como mínimo, tres bloques (mismo patrón que las skills existentes):

- **Qué hace** — una o dos frases: la capacidad que empaqueta.
- **Cuándo se usa** — los disparadores, coherentes con la `description`.
- **Protocolo** — los pasos que la IA sigue al ejecutarla.

Opcional pero recomendado: un bloque **"Qué NO hacer"** con los límites y errores comunes,
como hacen `onboarding-contexto` y `task-audit`.

## 4. Cuándo añadir `scripts/` y `references/`

| Subcarpeta | Cuándo se añade | Qué contiene |
|------------|-----------------|--------------|
| `scripts/` | La skill necesita **ejecutar código determinista** (parsear, validar, transformar, llamar a algo) | Scripts (`.py`, `.ps1`…). Lo determinista va en código, no en el prompt. |
| `references/` | La skill necesita **material de consulta cargable bajo demanda** (guías, plantillas, catálogos) que no conviene meter entero en `SKILL.md` | `.md` de referencia que el cuerpo del `SKILL.md` manda leer cuando toca. |

Regla de oro (misma que aplican las skills de este proyecto): el `SKILL.md` es el motor de
conversación y lo remite; lo pesado o determinista se saca a `scripts/` o `references/`.
**Ninguna de las dos se crea vacía**: si la skill no necesita una, no existe esa carpeta.

## 5. Dónde se instala una skill (alcance)

Sigue la regla de ubicación del negocio: **"¿lo usaría igual en otro cliente? → global;
¿depende de este cliente? → proyecto"**.

- **Transversal** (sirve en varios proyectos/clientes sin cambios) → nivel de usuario:
  `~/.claude/skills/<nombre>/`. Es el **valor por defecto**.
- **Específica de un proyecto/cliente** (depende de sus datos o reglas) →
  `.claude/skills/<nombre>/` de la carpeta actual.

## 6. Límites que aplica Claude Code (los valida `quick_validate.py`)

- `name`: `kebab-case`, coincide con la carpeta, **≤ 64 caracteres**.
- `description`: no vacía, **≤ 1024 caracteres**.
- `SKILL.md` empieza con un bloque de frontmatter `---` … `---` parseable, con `name` y
  `description` presentes y no vacíos.

Si algo de esto no se cumple, la skill **no está terminada**: se corrige y se vuelve a
validar.
