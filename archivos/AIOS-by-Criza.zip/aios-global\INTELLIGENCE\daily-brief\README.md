# Daily brief

Briefing diario generado a partir del estado del negocio y los proyectos.
Formato: `YYYY-MM-DD-brief.md`.
