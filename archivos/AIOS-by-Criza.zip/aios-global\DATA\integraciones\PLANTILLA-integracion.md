# Integración — [PLATAFORMA]

> Plantilla para documentar una conexión externa. Copia este archivo, renómbralo
> (p. ej. `gohighlevel.md`) y rellena las secciones. Las credenciales van en `.env`.

[Descripción en una línea: qué es y para qué la usa el negocio.]

## Para qué se usa
- TODO — caso de uso 1
- TODO — caso de uso 2

## Configuración
- Identificadores (IDs, URLs, endpoints): TODO
- Credenciales: en `.env` (nunca aquí). Variable: `TODO`
- Headers / autenticación: TODO

## Recursos disponibles
- TODO — pipelines / modelos / tablas / endpoints relevantes

## Estado
- Pendiente de conectar. (Al conectar: anota la fecha y qué se verificó.)
