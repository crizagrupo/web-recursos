# DATA — Datos e integraciones del negocio

Capa 2. Conexiones externas (CRM, base de datos, etc.), datos locales y sincronización.

- `integraciones/` — una ficha por plataforma (usa `PLANTILLA-integracion.md`).
- `db/` — base de datos local del negocio.
- `sync/` — scripts que sincronizan datos externos con la `db/` local.
