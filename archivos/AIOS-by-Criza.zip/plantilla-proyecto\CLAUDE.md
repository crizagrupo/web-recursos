# {{NOMBRE_PROYECTO}} — Proyecto AIOS

Proyecto de {{NOMBRE_NEGOCIO}}. **Hereda todo el nivel negocio** (identidad, skills, agentes, reglas y comandos del cerebro global). Aquí solo vive lo propio de este proyecto.

## Dos modos de trabajo

- **Operación** (por defecto): preguntas, consultas, registro → abre `MAPA.md` y lee solo lo necesario.
- **Construcción**: crear/automatizar algo para este proyecto → flujo del harness (`harness/AGENTS.md`). **Nada se construye sin aprobación.**

## Reglas

1. Empieza por el contexto del proyecto (`CONTEXT/`) y, si hace falta, el del negocio (heredado).
2. Construir = presentar el plan y esperar aprobación antes de tocar nada.
3. Credenciales en `.env`, nunca en archivos versionados.

## Pointers

- Navegación → `MAPA.md`
- Estado del proyecto → `ESTADO.md` · Histórico → `HISTORICO.md`
- Construcción → `harness/AGENTS.md`
- Comportamiento → heredado del negocio (`rules/` global)

Idioma de trabajo: **español**.
