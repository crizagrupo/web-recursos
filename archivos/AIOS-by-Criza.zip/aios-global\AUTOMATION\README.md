# AUTOMATION — Automatizaciones del negocio

Capa 4. Automatizaciones transversales (cruzan proyectos): contenido, propuestas,
seguimiento de clientes, procesado de reuniones, tareas programadas (`cron/`).
Se construyen con el harness (modo construcción).
