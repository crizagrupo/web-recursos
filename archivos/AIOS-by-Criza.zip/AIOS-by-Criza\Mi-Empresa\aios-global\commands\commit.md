---
description: Guarda el trabajo de la sesión (commit) de la carpeta actual de forma segura. Detecta los cambios, nunca sube .env ni credenciales, documenta solo lo construido en BUILD/, actualiza el HISTORICO, crea un único commit y pregunta antes de subir a la nube (push). Funciona igual en Mi-Empresa/ y en cualquier Proyectos/<cliente>/.
---

# Comando: /commit

Eres el guardián del trabajo del AIOS. Tu trabajo es **guardar la sesión**: crear un
"punto de guardado" (commit) bien hecho de la carpeta actual, documentar de forma
automática lo que se ha construido y dejar el historial al día, sin que el usuario tenga
que pensar en Git. El usuario probablemente **no es programador**: tú haces el trabajo
técnico; él solo aprueba el mensaje y decide si subir a la nube.

> Este comando vive a nivel de usuario del ordenador (`~/.claude/commands/commit.md`) y
> está disponible en **cualquier** carpeta sin reinstalarse. Siempre opera sobre el
> repositorio Git de la **carpeta actual** (donde se ejecuta), sin asumir rutas ni nombres:
> por eso se comporta **igual** dentro de `Mi-Empresa/` y dentro de cualquier
> `Proyectos/<cliente>/`. (R1, R2, R3)
>
> La Fase 2 del onboarding (`onboarding-infraestructura`) ya dejó la infraestructura Git
> lista (repositorio, identidad y remoto). Aquí **no** se reconfigura nada de eso: se usa.

## Principios (reglas duras, no los rompas)

- **Nunca guardes secretos.** Bajo ninguna circunstancia y sin excepciones se prepara
  (stage) ni se commitea un `.env` ni ningún archivo de credenciales, claves o tokens.
  Aunque el `.gitignore` ya deba cubrirlos, lo compruebas igualmente. (R8)
- **Un solo commit autodocumentado.** El trabajo, la actualización de `HISTORICO.md` y (si
  toca) la de `BUILD/docs/_index.md` entran en **el mismo** commit. Por eso analizas el
  diff y actualizas la documentación **antes** de commitear, no después.
- **Nunca subas a la nube sin permiso.** El `push` solo se hace si el usuario lo confirma
  de forma explícita. (R14, R15)
- **Carpeta actual, sin suposiciones.** No busques `Mi-Empresa/` ni ninguna ruta fija:
  trabaja sobre el repositorio de la carpeta donde te ejecutan, tal cual. (R2)
- **Tono cercano y llano.** Nada de jerga sin traducir. "Guardar", "punto de guardado",
  "subir a la nube" — no "stage", "HEAD", "upstream".

---

## Paso 1 — Situarte en la carpeta actual (R2, R3)

Trabaja sobre el repositorio Git de la **carpeta actual**, la que el usuario tiene abierta.
No subas por el árbol buscando otra carpeta ni asumas que estás en `Mi-Empresa/`: el flujo
es idéntico si te ejecutan dentro del negocio o dentro de un `Proyectos/<cliente>/`.

Comprueba que la carpeta actual es un repositorio Git (`git rev-parse --is-inside-work-tree`).
Si **no** lo fuera, avisa en lenguaje llano de que esta carpeta aún no está preparada para
guardar (falta la infraestructura de la Fase 2) y sugiere ejecutar antes `/onboarding`
(Fase 2 · Infraestructura) en `Mi-Empresa/`. No hagas `git init` tú aquí.

## Paso 2 — Detectar los cambios de la sesión (R4)

Mira el estado del repositorio para saber qué ha cambiado, tanto lo ya preparado (staged)
como lo sin preparar (unstaged):

- `git status --porcelain` — lista compacta de archivos cambiados/añadidos/borrados.
- `git status` — vista legible para explicárselo al usuario.

Quédate con la lista de rutas afectadas: la necesitarás para el análisis de `BUILD/`
(Paso 5), para el mensaje (Paso 8) y para preparar el commit (Paso 9).

## Paso 3 — Si no hay nada que guardar, termina (R5)

Si el árbol está limpio (no hay cambios staged **ni** unstaged), **no** crees un commit
vacío. Informa en una frase: *"No hay cambios que guardar: tu trabajo ya está al día."* y
termina aquí. No toques `HISTORICO.md` ni `BUILD/docs/_index.md` en este caso.

## Paso 4 — Apartar lo sensible (regla dura) (R8)

Antes de preparar nada, identifica en la lista de cambios cualquier archivo sensible y
déjalo **fuera**. Cuenta como sensible cualquier archivo con aspecto de secreto:

- `.env`, `.env.*`, `*.env`, `.envrc`
- `secrets.*`, `credentials.*`, cualquier nombre que contenga `secret` o `credential`
- claves y certificados: `*.key`, `*.pem`, `*.pfx`, `*.p12`, `id_rsa*`
- `service-account*.json`, `*token*.json`, y cualquier archivo que a ojo contenga claves,
  tokens o contraseñas.

Qué hacer con ellos:

1. **No los prepares.** Cuando llegues al Paso 9, no los incluyas en el stage.
2. **Si alguno ya estuviera preparado** (staged de una sesión anterior), quítalo:
   `git rm --cached <archivo>` (esto no borra tu archivo local, solo lo saca del guardado).
3. **Asegura el `.gitignore`.** Si el archivo sensible no está cubierto por `.gitignore`,
   añádelo para que no vuelva a colarse.
4. **Avisa al usuario** en una frase de que has dejado ese archivo fuera y por qué
   ("Tu `.env` con las claves no se sube nunca; lo he dejado fuera del guardado").

Es una regla **sin excepciones**: aunque el usuario insista, un secreto no entra en un
commit.

## Paso 5 — Analizar el impacto en `BUILD/` (R10)

Revisa la lista de archivos cambiados (Paso 2) y decide si hay un cambio **sustancial** en
`BUILD/` de la carpeta actual. Definición, para que sea verificable:

- **Sí es sustancial:** el diff **crea una carpeta de herramienta nueva** bajo `BUILD/`
  (p. ej. `BUILD/mini-crm/`), o cambia una existente de forma que altera **qué es** o
  **dónde vive** (nuevos archivos de la herramienta, renombrado, movimiento de carpeta).
- **No es sustancial:** retoques menores dentro de un archivo ya existente (una errata, un
  comentario, un ajuste puntual) que no cambian qué es la herramienta ni dónde vive. Ni
  cambios que no tocan `BUILD/` en absoluto.

Anota el resultado: `¿hay herramienta nueva o cambio relevante en BUILD/? sí / no` y, si
sí, **qué herramienta(s)** (nombre de la carpeta bajo `BUILD/`).

## Paso 6 — Documentar `BUILD/` si procede (R11, R12)

- **Si el Paso 5 dio "no"** (o no se tocó `BUILD/`): **no toques** `BUILD/docs/_index.md`.
  Sáltate este paso. (R12)
- **Si dio "sí"**: crea o actualiza `BUILD/docs/_index.md` de la carpeta actual con una
  entrada para esa herramienta. Es un índice legible, **una entrada por herramienta**, e
  **idempotente**: si la herramienta ya tiene su entrada, la **actualizas** (por ejemplo, la
  fecha); **no** creas una segunda. Crea el archivo (y la carpeta `BUILD/docs/`) si no
  existen. Formato de cada entrada:

  ```markdown
  # Índice de sistemas construidos (BUILD/)

  ## <nombre-herramienta>
  - Qué es: <una frase en lenguaje sencillo>
  - Dónde vive: BUILD/<nombre-herramienta>/
  - Última actualización: <fecha de hoy AAAA-MM-DD>
  ```

  El "qué es" en lenguaje llano, derivado de lo que hace la herramienta (mira su
  `README.md` si lo tiene). Esta actualización entrará en el mismo commit (Paso 9).

## Paso 7 — Anotar el hito en `HISTORICO.md` (R13)

Añade **tú** —sin que el usuario lo escriba— una entrada breve al `HISTORICO.md` de la
carpeta actual, la más reciente primero, con lo que se hizo y la fecha de hoy. Respeta la
marca del archivo (`<!-- Las entradas se añaden encima de esta línea... -->`) y, si el
título aún tuviera un marcador `{{NOMBRE_NEGOCIO}}` o `{{NOMBRE_PROYECTO}}`, sustitúyelo por
el nombre real (lo tienes en `CONTEXT/` o en `CLAUDE.md`). Formato:

```markdown
- **<fecha de hoy AAAA-MM-DD>** — <resumen breve de lo guardado en esta sesión>.
```

Esta línea entra en el mismo commit (Paso 9).

## Paso 8 — Determinar el mensaje del commit (R6, R7)

- **Si el usuario aportó un mensaje** (p. ej. `/commit "arreglo del formulario"` o lo dijo
  en la conversación): úsalo **tal cual**. (R6)
- **Si no aportó ninguno:** redacta uno **claro y descriptivo** en lenguaje natural, que
  resuma qué cambió (a partir de la lista de archivos y del trabajo de la sesión). Frase
  llana, sin convención interna de versiones (`vN — ...`) ni ramas: el destinatario es el
  dueño de su propio repositorio. Ejemplos: *"Actualizo el contexto del negocio"*, *"Añado
  la herramienta mini-crm"*. (R7)

En ambos casos, **muestra el mensaje propuesto** antes de commitear, para que el usuario lo
vea (y pueda cambiarlo si quiere).

## Paso 9 — Preparar y crear un único commit (R9)

1. **Prepara** los cambios de la sesión, **incluidas** las actualizaciones de
   `HISTORICO.md` (Paso 7) y, si la hubo, de `BUILD/docs/_index.md` (Paso 6):
   normalmente `git add -A`.
2. **Verifica el stage antes de commitear** (red de seguridad para R8): `git status` y
   `git ls-files --cached`. Si aparece **cualquier** archivo sensible del Paso 4,
   quítalo (`git rm --cached <archivo>`) y no continúes hasta que el stage esté limpio de
   secretos.
3. Crea **un único commit** con el mensaje del Paso 8:
   `git commit -m "<mensaje>"`. No hagas dos commits (uno del trabajo y otro de la
   documentación): todo va junto, autodocumentado.
4. Confírmale al usuario, en lenguaje llano, que su punto de guardado está creado.

## Paso 10 — Preguntar por la subida a la nube (push) (R14, R15)

Con el commit ya hecho en local, **pregunta** si quiere subir los cambios a la nube
(GitHub): *"¿Subo este guardado a la nube para que quede respaldado?"*

- **Si confirma explícitamente** (sí): `git push`. Si el repositorio aún no tiene rama de
  seguimiento configurada, usa `git push -u origin <rama-actual>`. Confirma que la subida
  fue correcta. (R14)
- **Si no confirma** (dice que no, duda, o no responde que sí): **no** hagas `git push`.
  Deja el commit hecho en local y explícale que su trabajo ya está guardado en el ordenador
  y que puede subirlo cuando quiera volviendo a usar `/commit`. (R15)

Nunca subas por iniciativa propia.

## Qué NO hacer

- No incluyas **jamás** `.env`, tokens, claves ni credenciales en el commit ni en el push,
  bajo ninguna circunstancia. (R8)
- No crees un commit vacío cuando no hay cambios. (R5)
- No hagas `git push` sin confirmación explícita del usuario. (R15)
- No toques `BUILD/docs/_index.md` si el cambio no es sustancial en `BUILD/`; no dupliques
  entradas si ya existen. (R12)
- No busques `Mi-Empresa/` ni asumas rutas fijas: opera sobre la carpeta actual. (R2)
- No reconfigures la identidad Git ni la cuenta de GitHub (eso es de la Fase 2): aquí solo
  guardas y, si el usuario quiere, subes.
- No dividas el guardado en varios commits: el trabajo y su documentación van en uno solo.
