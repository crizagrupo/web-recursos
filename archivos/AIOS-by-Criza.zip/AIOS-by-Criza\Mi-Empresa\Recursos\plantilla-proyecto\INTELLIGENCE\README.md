# INTELLIGENCE — Conocimiento vivo del proyecto

Capa 3 del AIOS a nivel de proyecto. Aquí vive el conocimiento que se va acumulando de este
cliente/iniciativa: notas de reuniones, briefs, seguimientos y decisiones a lo largo del
proyecto.

Arranca vacía. Se irá rellenando a medida que trabajes el proyecto (por ejemplo, al procesar
reuniones o generar briefs con los comandos y skills heredados de `~/.claude`).

> Para el contexto **estable** del proyecto (qué es, alcance, objetivos) usa
> `CONTEXT/proyecto.md`. Este `INTELLIGENCE/` es para lo que **cambia** con el tiempo.
