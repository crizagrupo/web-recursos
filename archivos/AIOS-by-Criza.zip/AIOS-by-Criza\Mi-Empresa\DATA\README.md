# DATA — Datos y conexiones del negocio

Capa 2 del AIOS: las **conexiones** del negocio con sus herramientas externas (reuniones,
CRM, almacenamiento tipo Drive / Microsoft 365…) y lo que la IA sabe gracias a ellas.

La **Fase 3 del onboarding** (`/onboarding`, skill `onboarding-datos`) rellena esta carpeta
por ti: te entrevista sobre qué herramientas usas y las conecta a la IA por MCP. No hace
falta editar nada a mano.

| Elemento | Qué contiene |
| --- | --- |
| `integraciones/` | Una ficha por herramienta conectada (para qué se usa, tipo de conexión y estado). Usa `PLANTILLA-integracion.md`. |
| `key-metrics.md` | Resumen legible de **qué sabe la IA** gracias a las conexiones. Lo genera y regenera la Fase 3; **no** existe hasta que conectas algo. |

> Las conexiones se resuelven **una vez por ordenador** (con alcance de usuario), así que
> sirven para esta carpeta y para cualquier otra que crees luego con `/crear-proyecto`, sin
> reconectar.

**Nunca** se guardan aquí claves ni contraseñas: la autenticación la gestiona el cliente MCP
o el gestor de credenciales del sistema. En las fichas solo se anota, como mucho, el
**nombre** de una variable de entorno, nunca su valor.
