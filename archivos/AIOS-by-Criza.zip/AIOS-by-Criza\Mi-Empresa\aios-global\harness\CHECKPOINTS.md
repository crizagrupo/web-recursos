﻿# CHECKPOINTS — Estado final correcto de una construcción

> Criterios objetivos para auto-evaluarte. El `reviewer` los usa para aprobar
> o rechazar un módulo. Si alguno falla, el módulo NO está `done`.

## Spec
- [ ] Existe `specs/<modulo>/` con `requirements.md`, `design.md` y `tasks.md`.
- [ ] `requirements.md` está en EARS-lite: cada `R<n>` es una frase verificable con un solo `DEBE`.
- [ ] **Cuenta** las referencias de `design.md` a archivos/patrones ya existentes en el
      proyecto: cuántas citan **ruta + línea exacta** (`archivo.ext:123`) y cuántas solo
      nombran el archivo. Escribe el recuento tal cual en `progress/review_<modulo>.md`
      (p. ej. `citas archivo:línea: 2/2`). **Rechaza si el recuento no es 1:1.**
- [ ] El spec fue **aprobado por {{DUENO}}** antes de pasar a `in_progress` (no se saltó la puerta).
- [ ] `build_backlog.json` tiene `"model"` registrado para este módulo (`sonnet`/`opus`,
      decidido por la tabla de `leader.md` "Modelo por tipo de módulo" — ese campo rige
      builder/reviewer, no spec_author).

## Construcción
- [ ] El módulo vive en la capa correcta: `AUTOMATION/<modulo>/` o `BUILD/<modulo>/`.
- [ ] Todas las tasks de `tasks.md` están marcadas `[x]` (o las pendientes tienen justificación documentada).
- [ ] El módulo tiene `README.md` en lenguaje sencillo: qué hace, entradas, salida, cómo se ejecuta.

## Verificación
- [ ] `verify.ps1` termina en verde.
- [ ] El módulo se ejecutó **al menos una vez** con datos de prueba (resultado en `progress/impl_<modulo>.md`).
- [ ] Cada `R<n>` tiene su comprobación en el mapa de trazabilidad.

## Higiene
- [ ] No hay credenciales ni API keys en archivos commiteados (van en variables de entorno, documentadas en `DATA/integraciones/`).
- [ ] No quedan archivos temporales ni notas de debug.

## Estado
- [ ] Solo este módulo estuvo en `in_progress` durante la sesión.
- [ ] `build_backlog.json` refleja el estado real (`done`).
- [ ] El resumen de la sesión está en `progress/history.md` y `progress/current.md` quedó limpio.
