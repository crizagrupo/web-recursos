﻿# Spec Driven Development en el AIOS (versión de negocio)

> Antes de construir un módulo se escribe su spec y **{{DUENO}} lo aprueba**.
> El código/los archivos del módulo no se tocan hasta entonces.

## Los 3 archivos de un spec
Cada módulo con `"sdd": true` tiene una carpeta `specs/<modulo>/`:

```
specs/<modulo>/
├── requirements.md   # QUÉ debe hacer (en lenguaje sencillo, EARS-lite)
├── design.md         # CÓMO se construirá (decisiones, integraciones, archivos)
└── tasks.md          # PASOS concretos a ejecutar
```

## Estados
| Estado | Significado |
|--------|-------------|
| `pending` | Sin spec. El `spec_author` actúa primero. |
| `spec_ready` | Spec redactado. **Esperando que {{DUENO}} apruebe.** No se construye nada. |
| `in_progress` | Aprobado. El `builder` está trabajando. |
| `done` | Verificado, el `reviewer` aprobó, sesión cerrada. |
| `blocked` | Atascado. Razón en `progress/current.md`. |

## La puerta de aprobación humana
El flujo se detiene **una vez**: cuando el `spec_author` termina los 3 archivos, marca el módulo `spec_ready` y para. {{DUENO}} lee `specs/<modulo>/` y dice "aprobado" (o pide cambios). Solo entonces el `leader` pasa a `in_progress` y lanza el `builder`.

```
pending → [spec_author] → spec_ready → ⏸ {{DUENO}} APRUEBA → in_progress → [builder → reviewer] → done
```

## requirements.md — EARS-lite en lenguaje de negocio
Cada requisito es una frase numerada (`R1`, `R2`, …) con uno de estos patrones, redactada para que {{DUENO}} la entienda:

| Patrón | Plantilla |
|--------|-----------|
| **Siempre** | `El sistema DEBE <acción>.` |
| **Cuando pasa algo** | `CUANDO <disparador>, el sistema DEBE <acción>.` |
| **Mientras un estado** | `MIENTRAS <estado>, el sistema DEBE <acción>.` |
| **Si algo va mal** | `SI <evento no deseado> ENTONCES el sistema DEBE <acción>.` |

Reglas:
- Cada requisito tiene un id estable y DEBE ser **verificable** (se puede comprobar si se cumple o no).
- Un solo `DEBE` por requisito. Si hay dos, pártelo.
- Sin verbos blandos ("podría", "intentará"). Solo `DEBE` / `NO DEBE`.

Ejemplo (daily brief):
```markdown
## R1
CUANDO son las 08:00 de un día laborable, el sistema DEBE generar un brief
en INTELLIGENCE/daily-brief/YYYY-MM-DD-brief.md con el estado de las últimas 24h.

## R2
SI no hay datos del pipeline disponibles ENTONCES el sistema DEBE generar el
brief igualmente e indicar "pipeline no disponible" en la sección correspondiente.
```

## design.md — decisiones antes de construir
- Qué archivos se crean/modifican y en qué capa.
- Qué integraciones usa (GHL, Supabase, M365) y qué variables de entorno necesita.
- Qué datos de prueba se usarán para verificar.
- Una alternativa descartada y por qué.

## tasks.md — checklist ejecutable
Pasos discretos en orden, cada uno con checkbox y los `R<n>` que cubre. El `builder` marca `[x]` al completar. El `reviewer` rechaza si queda alguna `[ ]` sin justificar.

```markdown
- [ ] T1 — Crear AUTOMATION/daily-brief/generar.ps1. Cubre: R1.
- [ ] T2 — Conectar lectura de pipeline desde DATA/. Cubre: R1, R2.
- [ ] T3 — Documentar el cron en AUTOMATION/cron/daily-brief.cron. Cubre: R1.
```

## Trazabilidad
Cada `R<n>` debe poder comprobarse con una verificación concreta descrita en `progress/impl_<modulo>.md`. El `reviewer` comprueba la correspondencia y rechaza si falta.
