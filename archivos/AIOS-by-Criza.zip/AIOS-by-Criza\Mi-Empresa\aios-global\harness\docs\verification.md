﻿# Verificación — Cómo demostrar que un módulo funciona

> En el AIOS no hay un suite de tests de código como en un proyecto de software.
> La verificación combina invariantes estructurales (automáticas) + una prueba
> funcional real del módulo.

## 1. Invariantes estructurales — `verify.ps1`
Se ejecutan con `harness/verify.ps1` (o al cerrar la sesión vía hook). Comprueban:
- `build_backlog.json` es JSON válido.
- Hay **como máximo un** módulo en `in_progress`.
- Todo módulo `sdd: true` en estado `in_progress` o `done` tiene `harness/specs/<modulo>/` con los 3 archivos.
- No hay carpetas en `harness/specs/` sin su entrada correspondiente en el backlog (sin specs huérfanos).
- No hay credenciales evidentes commiteadas (búsqueda de patrones tipo `api_key`, `sk-`, tokens).

Si `verify.ps1` falla, **no se cierra** la sesión ni se marca nada `done` hasta resolverlo.

## 2. Prueba funcional del módulo
Definida en el `design.md` del módulo. El `builder` la ejecuta **al menos una vez** con datos de prueba y guarda el resultado en `harness/progress/impl_<modulo>.md`. Ejemplos según tipo:

| Tipo de módulo | Prueba funcional mínima |
|----------------|--------------------------|
| Genera un documento (propuestas, brief) | Ejecutarlo con un caso de ejemplo y comprobar que el archivo de salida cumple cada `R<n>`. |
| Sincroniza datos (sync GHL/Supabase) | Ejecutar la sincronización y comprobar que los datos esperados aparecen en `DATA/`. |
| Procesa una entrada (reuniones) | Pasarle una transcripción de ejemplo y comprobar que el resumen y los action items son correctos. |
| Herramienta interactiva (dashboard, audit-tool) | Abrirla/ejecutarla y comprobar el flujo principal de uso. |

## 2.1 Cuánto vuelve a probar el reviewer
Por defecto, el `reviewer` re-ejecuta la prueba funcional del builder — es lo que da la
independencia del veredicto. Excepción: si el módulo **no** toca código nuevo, credenciales,
ni una acción irreversible (borrado, envío, pago, sobrescritura de datos reales), y es
solo documentación, texto o sincronizar configuración ya existente, basta con leer la
evidencia de `harness/progress/impl_<modulo>.md` y hacer **una** comprobación puntual en
vez de repetir toda la prueba. Ante la duda de si un módulo califica, re-ejecuta completo.

## 3. Trazabilidad
En `harness/progress/impl_<modulo>.md`, el `builder` deja el mapa `R<n> → cómo se comprobó`:
```markdown
## Trazabilidad
- R1 → Ejecutado `generar.ps1`; se creó el brief con las 24h. ✓
- R2 → Probado sin pipeline; el brief indica "pipeline no disponible". ✓
```

## 4. Checklist de cierre (lo valida el reviewer)
- [ ] `harness/verify.ps1` verde.
- [ ] Cada `R<n>` del spec tiene su comprobación en `harness/progress/impl_<modulo>.md`.
- [ ] Todas las tasks de `tasks.md` están `[x]`.
- [ ] El módulo tiene `README.md` en lenguaje sencillo.
- [ ] Sin credenciales en archivos.
- [ ] `build_backlog.json` actualizado y resumen movido a `harness/progress/history.md`.
