# CONTEXT/ — Quién es este proyecto

Capa 1 del AIOS **a nivel de proyecto**: la identidad de este cliente o iniciativa concreta.
De aquí lee la IA para saber de qué va el proyecto, con quién se trabaja y qué particularidades
tiene.

**Esta carpeta arranca vacía a propósito.** No la rellenes a mano. Ejecuta el comando
**`/onboarding`**: al ver el marcador `.aios-proyecto`, te ofrecerá **solo la Fase 1
(Contexto de proyecto)**, te hará una entrevista corta (o leerá un archivo que le pases) y
escribirá él mismo el archivo siguiente con el contenido real del proyecto.

| Archivo | Qué contiene |
| --- | --- |
| `proyecto.md` | Qué es este proyecto, alcance, objetivos, interlocutores y particularidades del cliente. |

> Nota: la identidad del **negocio** (qué hace {{NOMBRE_NEGOCIO}}, su equipo, sus servicios)
> **no** se copia aquí: vive en `Mi-Empresa/CONTEXT/` y se hereda. En este `CONTEXT/` solo va
> lo específico de este proyecto.

Mientras no exista `proyecto.md`, el AIOS sabe que la Fase 1 de proyecto está pendiente y
`/onboarding` la arranca. Si cortas la entrevista a medias, al volver a ejecutarla retoma por
donde ibas sin repetir lo ya respondido.
