# Harness AIOS — Plantilla replicable

Andamiaje de gobierno para convertir cualquier AIOS en un sistema auto-dirigido:
los módulos nuevos (automatizaciones y herramientas) se construyen solos por el
flujo *investigar → especificar → (el dueño aprueba) → construir → revisar*, con
todo el estado en archivos en disco.

Basado en los principios de Harness Engineering. Pensado para instalarse encima
de un AIOS que ya tiene la estructura de 5 capas (CONTEXT, DATA, INTELLIGENCE,
AUTOMATION, BUILD).

## Qué incluye
```
harness-aios/
├── AGENTS.md                 # Mapa de navegación para los agentes
├── CHECKPOINTS.md            # Criterios de "estado final correcto"
├── build_backlog.json        # Cola de módulos a construir (vacía)
├── verify.ps1                # Verificación de invariantes (PowerShell/Windows)
├── docs/harness/             # architecture, conventions, specs (SDD), verification
├── progress/                 # current.md + history.md (estado en disco)
└── .claude/
    ├── agents/               # leader, explorer, spec_author, builder, reviewer
    └── settings.json         # Hook Stop que ejecuta verify.ps1
```

## Cómo instalarlo en el AIOS de un cliente
1. Copia el contenido de esta carpeta a la **raíz** del AIOS del cliente
   (fusiona `.claude/` con el existente).
2. Sustituye los marcadores `{{NOMBRE_NEGOCIO}}` y `{{DUENO}}` por el nombre real del
   negocio y del dueño en los archivos `.md` y en `build_backlog.json`.
3. Añade al `CLAUDE.md` raíz del cliente una sección "Flujo de construcción"
   que active el rol `leader` solo para tareas de construir, enlazando `AGENTS.md`.
4. Ejecuta `verify.ps1` — debe terminar en verde con el backlog vacío.
5. Siembra `build_backlog.json` con los primeros módulos a construir
   (uno por automatización/herramienta, con `"sdd": true` y `status: "pending"`).

## Cómo se usa (día a día)
Pide al sistema **"construye el siguiente módulo pendiente"**. El `leader`
genera el spec y para pidiendo aprobación. El dueño lee `specs/<modulo>/` y dice
"aprobado". Entonces el sistema construye, verifica y revisa, dejando la traza en
`progress/`.

> Nota: `verify.ps1` está en ASCII a propósito (PowerShell 5.1 puede romper el
> parseo con caracteres acentuados según la codificación del archivo).
