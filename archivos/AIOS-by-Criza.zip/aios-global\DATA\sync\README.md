# sync — Sincronización

Scripts que traen datos de las integraciones externas a la `db/` local.
Estado: vacío — se construyen con el harness según las plataformas que conectes.
