---
name: identidad-visual
description: Aplica la identidad de marca ya definida del negocio (colores, tipografía, tono) a cualquier pieza visual que se construya — landings, apps, dashboards — en vez de dejar que el modelo invente una paleta nueva cada vez. Úsala siempre que se construya o rediseñe una interfaz, landing, sección de marketing o dashboard y ya exista una guía de marca (`CONTEXT/branding/guia-marca.md`). Complementa, no sustituye, a `frontend-design` (dirección creativa) y a `landing-page-design`/`landing-page-copywriter` (conversión y copy).
---

# Identidad Visual

Fija la identidad visual del negocio — no la inventa — antes de construir cualquier pieza de marketing o de producto, para que el resultado nazca on-brand sin necesidad de corregirlo después.

## Cuándo se activa

- Construir o rediseñar una landing, sección de marketing, app o dashboard.
- Ya existe un archivo de marca (`CONTEXT/branding/guia-marca.md`, escrito por la Fase 1 del onboarding — o el archivo equivalente si el proyecto usa otra ruta).
- Si no existe ese archivo, esta skill no aplica todavía: usa `frontend-design` directamente y valora completar antes la guía de marca (`/onboarding`).

## Instrucciones

1. **Localizar y leer entera la guía de marca del negocio o proyecto activo.** Busca `CONTEXT/branding/guia-marca.md`. Debe contener: personalidad de marca, paleta con tokens hex nombrados, tipografías (titulares/cuerpo), formas/radios, tono de voz y referencias visuales.
   - Si no lo encuentras, pregunta al usuario antes de asumir nada.

2. **No inventar paleta ni tipografía.** A diferencia de un proyecto sin marca definida, aquí el color y la tipografía **no son un eje libre** — vienen fijados por la guía. Todo lo demás (layout, jerarquía, movimiento, el "elemento firma") sigue siendo terreno de decisión creativa.

3. **Elegir el modo según el tipo de pieza:**
   - **Marketing / landing** (expresivo, con personalidad): sigue el proceso de la skill `frontend-design` (brainstorm → plan de tokens → autocrítica → construir → criticar de nuevo), pero con el paso de color/tipografía ya resuelto por la guía de marca — solo se plantea el resto (layout, elemento firma, movimiento).
   - **Funcional / app / dashboard** (sobrio, orientado a componentes reconocibles): prioriza consistencia sobre originalidad.
     - Proyecto React: usa convenciones de shadcn/ui si está instalado; aplica los tokens de marca al tema (Tailwind config o variables CSS) en vez de estilos sueltos por componente.
     - Proyecto HTML/CSS/JS vanilla: centraliza los tokens en variables `:root` (mismo patrón que ya usa el dashboard del propio AIOS, `BUILD/dashboard/` y `BUILD/dashboard-negocio/`) y reutilízalos en vez de repetir valores hex sueltos.

4. **Centralizar los tokens, no repetirlos a mano.** En React: `theme.extend` de Tailwind o variables CSS. En vanilla: variables `:root`. Nunca copiar valores hex sueltos dentro de un componente.

5. **Respetar el tono de voz** de la guía de marca en cualquier copy que forme parte del diseño (títulos, microcopy, estados vacíos o de error). Para el framework de conversión y estructura de venta del copy, usa `landing-page-copywriter`.

## Qué no hace esta skill

- No decide estructura de conversión ni jerarquía de CTAs — eso es `landing-page-design`.
- No redacta copy de venta — eso es `landing-page-copywriter`.
- No sustituye a `frontend-design`: la complementa fijando color y tipografía antes de aplicar su proceso creativo.

## Ejemplo

Petición: "Construye la sección hero de la landing de [producto]."

1. Lee `CONTEXT/branding/guia-marca.md` → navy `#14306e` / crema `#f7f6f3` / Playfair Display + Inter / tono "premium sobrio".
2. Modo: marketing.
3. Aplica el proceso de `frontend-design`, pero el color y la tipografía ya están fijados — solo se explora layout, elemento firma y movimiento.
4. Redacta cualquier copy con el tono de voz de la guía.
