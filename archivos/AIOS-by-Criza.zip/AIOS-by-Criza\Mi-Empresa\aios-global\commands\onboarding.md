---
description: Instalador conversacional del AIOS. Router que detecta si estás en la raíz del negocio (Mi-Empresa/) o en una carpeta de proyecto, y ofrece las fases que correspondan. En Mi-Empresa/, pone en marcha el negocio por fases (Contexto, Infraestructura, Datos). En un proyecto, ofrece solo la Fase 1 (Contexto de proyecto) y no repite Infraestructura ni Datos, ya resueltas a nivel de usuario.
---

Eres el instalador del AIOS. Este comando es un **router**: primero mira **qué tipo de
carpeta** es esta (el negocio o un proyecto) y luego, dentro de ese modo, en qué punto de la
instalación está y arranca (o retoma) la fase que toque. No hace preguntas técnicas de golpe;
conduce al usuario paso a paso.

## 0. Autoinstalación (antes de nada) (R1-R11)

**Antes de cualquier otra cosa** —incluida la decisión Empresa/Proyecto de la sección 1—,
comprueba si esta carpeta trae todavía la copia de fábrica de la herramienta y, si es así,
instálala **una sola vez** en `~/.claude` del ordenador. Esto sustituye a cualquier copia
manual: el propio `/onboarding` se deja instalado a sí mismo en su primera ejecución.

> Si has llegado aquí porque `.claude/commands/onboarding.md` (el arrancador temporal) te
> redirigió a este archivo, estás en el sitio correcto: sigue leyendo desde 0.1. Ese
> arrancador solo existe para que Claude Code reconociera `/onboarding` antes de que nada
> estuviera instalado; se borra solo al final de este mismo Paso 0 (ver 0.5).

### 0.1 Detectar si aplica (R1, R2)

Mira si existe `./aios-global/` en la carpeta actual **con contenido**: al menos un archivo
bajo `agents/`, `commands/`, `harness/`, `rules/` o `skills/`.

- **No existe (o está vacía)** → el Paso 0 **no aplica** (ya se migró en una ejecución
  anterior, o esta carpeta nunca trajo copia local). **No instales ni borres nada**: continúa
  directamente con la sección 1 (¿Empresa o proyecto?).
- **Existe con contenido** → sigue con 0.2.

### 0.2 Explicar en una frase (R3)

Antes de mover o borrar nada, di al usuario, en **una sola frase**, qué es `aios-global/` y
por qué la instalas. Por ejemplo: *"Esta carpeta trae los comandos, skills, agentes y el motor
de construcción del AIOS (`aios-global/`); los voy a instalar una sola vez en la configuración
de tu ordenador (`~/.claude`) para que funcionen aquí y en cualquier otra carpeta que abras
después, incluidos los proyectos que crees con `/crear-proyecto`."*

### 0.3 Migrar sin pisar nada (R4, R5, R6)

Recorre las cinco carpetas de `aios-global/`: `agents/`, `commands/`, `harness/`, `rules/`,
`skills/`. Para cada **elemento de primer nivel** dentro de ellas:

- La **unidad de copia** es **1 archivo suelto** (un comando/regla/agente `.md`) **o 1 carpeta
  completa** (una skill o un agente con subcarpetas, p. ej. `skills/onboarding-contexto/`).
- Copia ese elemento al mismo sitio bajo `~/.claude/` **solo si NO existe ya** allí uno con
  ese mismo nombre.
- Si **ya existe** en el destino → **no lo toques**: no lo sobrescribas ni lo mezcles. Nunca
  combines un archivo/carpeta nuevo con partes viejas de una carpeta ya existente en destino:
  o entra la carpeta completa, o no entra nada de ella.
- Si alguna de las carpetas destino `~/.claude/{agents,commands,harness,rules,skills}/` **no
  existe**, créala antes de copiar.

### 0.4 Verificar antes de borrar (R7, R8)

Cuando termines de copiar, **verifica** que **todo** el contenido de `aios-global/` está ahora
presente en `~/.claude` (ya sea porque lo copiaste ahora o porque ya existía con ese mismo
nombre).

- Si **algo falta** → **NO borres** `aios-global/` ni ningún archivo local. Avisa al usuario
  del fallo indicando la **causa** (p. ej. sin permiso de escritura en `~/.claude`, o una copia
  incompleta) y **detén** el Paso 0 aquí, dejando la copia local intacta para no perder nada.

### 0.5 Borrar solo si la verificación es correcta (R9)

Con la verificación correcta (todo presente en `~/.claude`), borra la carpeta `aios-global/`
**completa** de la carpeta actual.

Borra también, si existe, el arrancador temporal `.claude/commands/onboarding.md` de esta
misma carpeta: ya cumplió su función (hacer que Claude Code reconociera `/onboarding` antes de
la instalación) y, a partir de ahora, el comando sigue funcionando aquí porque ya vive en
`~/.claude/commands/onboarding.md`. Si la verificación de 0.4 **no** fue correcta, no borres
nada de esto (ni `aios-global/` ni el arrancador): déjalo todo intacto para no perder nada.

### 0.6 Continuar en el mismo turno (R10, R11)

- Sigue en **esta misma conversación** con la sección 1 (¿Empresa o proyecto?) y la fase que
  toque. **No** pidas al usuario que cierre ni reabra Claude Code.
- Cuando necesites usar la **primera skill** (típicamente `onboarding-contexto`, para arrancar
  la Fase 1), **léela directamente con la herramienta de lectura de archivos** por su nueva
  ruta `~/.claude/skills/onboarding-contexto/SKILL.md` y síguela como guion. **No** asumas que
  invocarla por su nombre la reconoce ya en esta sesión: una skill recién copiada puede no
  estar en el registro de esta sesión (el listado de skills se fija al abrir la carpeta), pero
  la lectura del archivo siempre refleja el disco. Aplica lo mismo a cualquier otra skill que
  necesites usar por primera vez en este mismo turno.

---

## 1. ¿Empresa o proyecto? (decisión inicial)

Mira en la **carpeta actual** si existe el marcador **`.aios-proyecto`** (lo escribe
`/crear-proyecto` en cada carpeta de proyecto):

- **Existe `.aios-proyecto` → estás en un PROYECTO** (una carpeta `Proyectos/<cliente>/`,
  hermana de `Mi-Empresa/`). Ve a la sección **A. Modo proyecto**. En este modo **NUNCA**
  ofreces la Fase 2 (Infraestructura) ni la Fase 3 (Datos): solo la Fase 1 de proyecto.
- **No existe `.aios-proyecto` → estás en la raíz del NEGOCIO** (`Mi-Empresa/`). Ve a la
  sección **B. Modo empresa** (comportamiento de siempre: Fases 1, 2 y 3).

> Señal de refuerzo coherente con el esquema: un proyecto usa `CONTEXT/proyecto.md`; la empresa
> usa `CONTEXT/negocio.md`. El **marcador manda** (fuente principal); esta distinción solo
> confirma.

---

## A. Modo proyecto (carpeta con `.aios-proyecto`)

Estás en la carpeta de un cliente/iniciativa. La infraestructura (Git/GitHub) y los datos
(conexiones MCP) ya se resolvieron **una vez** a nivel de tu ordenador y este proyecto los
**hereda**: aquí solo se define el **contexto del proyecto** (Fase 1).

### A.1 Situarte (mira el disco, no preguntes lo que puedes ver)

- ¿Existe `CONTEXT/proyecto.md` con contenido real (sin `TODO`)? → la **Fase 1 de proyecto** ya
  está hecha o a medias.
- ¿Existe `harness/progress/onboarding.md`? → hay una Fase 1 empezada; léelo para saber qué
  temas quedaron pendientes y **retomar sin repetir** (R20).
- Lee **`~/.claude/aios/estado-usuario.md`** para saber si la infraestructura y los datos del
  ordenador constan resueltos (siguiente punto).

### A.2 Comprobar herencia de Infraestructura y Datos (no las repitas nunca) (R17)

Lee `~/.claude/aios/estado-usuario.md`:

- **Si la Fase 2 y la Fase 3 constan resueltas** → informa al usuario, en una frase amable, de
  que **Git/GitHub y las fuentes de datos ya están conectadas a nivel de tu ordenador** y de
  **por qué no hace falta repetirlas aquí** (son una propiedad del ordenador, no de la carpeta;
  este proyecto ya las hereda). Luego continúa con la Fase 1 de proyecto. (R18)
- **Si la Fase 2 y/o la Fase 3 NO constan resueltas** → **avisa** de que la infraestructura o
  las conexiones aún no están montadas a nivel de ordenador y **sugiere completar primero
  `/onboarding` en `Mi-Empresa/`** (Fase 2 y/o Fase 3). **No** intentes configurar aquí la
  infraestructura Git/GitHub ni las conexiones de datos: eso se hace una sola vez en el negocio,
  no dentro del proyecto. (R19) Puedes, si el usuario quiere, capturar igualmente el contexto
  del proyecto (Fase 1), pero deja claro el aviso.

En **ningún** caso ofreces ni arrancas la Fase 2 o la Fase 3 dentro de un proyecto. (R17)

### A.3 Fase 1 · Contexto de proyecto (R13)

- Si **no** existe `CONTEXT/proyecto.md`, o existe `harness/progress/onboarding.md` con la
  Fase 1 de proyecto marcada incompleta → **invoca la skill `onboarding-proyecto`** y déjala
  conducir la entrevista corta (o la importación de un archivo). Ella lee el negocio heredado
  (`../../Mi-Empresa/CONTEXT/`) para **no** repetir lo ya definido a nivel de empresa, detecta
  lo ya respondido y retoma sin repetir.
- Si `CONTEXT/proyecto.md` ya está completo → la Fase 1 de proyecto está hecha; dilo y no
  repitas la entrevista.

---

## B. Modo empresa (raíz del negocio, sin `.aios-proyecto`)

Comportamiento de siempre: pon en marcha el negocio por fases.

### 1. Situarte

Comprueba dónde estás y qué hay hecho, mirando el disco (no preguntes lo que puedes ver):

- ¿Existe `CONTEXT/negocio.md` en la carpeta actual? → señal de que la **Fase 1
  (Contexto)** ya está hecha o a medias.
- ¿Existe `harness/progress/onboarding.md`? → hay una instalación empezada; léelo para
  saber qué fase y qué temas quedaron pendientes.
- ¿Existe `~/.claude/aios/estado-usuario.md` con la **Fase 2 marcada resuelta**? → la
  infraestructura Git/GitHub de este ordenador ya está montada; **no** hay que repetirla.
  (Es una propiedad del ordenador, no de la carpeta: por eso vive en `~/.claude`, no aquí.)
- ¿Ese mismo `~/.claude/aios/estado-usuario.md` marca la **Fase 3 resuelta**? → las
  conexiones de datos (MCP) de este ordenador ya están registradas; **no** repitas su
  registro. Léelo también para saber qué herramientas quedaron **pendientes** de conectar,
  por si el usuario quiere retomarlas.

### 2. Elegir fase

**Fase 1 · Contexto**:
- Si **no** existe `CONTEXT/negocio.md`, o existe `harness/progress/onboarding.md` con la
  Fase 1 marcada como incompleta → **invoca la skill `onboarding-contexto`** y déjala
  conducir la entrevista. Ella detecta lo ya respondido y retoma sin repetir. (Si vienes de
  una autoinstalación en este mismo turno, no la invoques por nombre: léela por su ruta
  `~/.claude/skills/onboarding-contexto/SKILL.md` como indica 0.6.)
- Mientras la Fase 1 no esté completa, **no ofrezcas ni arranques la Fase 2**: primero el
  negocio tiene que conocerse a sí mismo.

**Fase 2 · Infraestructura** (Git/GitHub):
- **Solo** si la Fase 1 está completa (existe `CONTEXT/negocio.md`) **y** la Fase 2 **no**
  consta resuelta a nivel de usuario (no hay `~/.claude/aios/estado-usuario.md` con la
  Fase 2 marcada) → ofrécela y, si el usuario acepta, **invoca la skill
  `onboarding-infraestructura`**. Ella explica Git/GitHub desde cero, conecta el
  repositorio, hace el primer commit y deja `/commit` listo.
- Si `~/.claude/aios/estado-usuario.md` ya marca la Fase 2 como resuelta → **no repitas**
  la configuración de Git/GitHub ni el alta de cuenta. Informa de que la infraestructura
  ya está lista y continúa hacia lo siguiente (Fase 3). La conexión concreta de *esta*
  carpeta se refleja por la existencia real de su repositorio Git (`.git/`).

**Fase 3 · Datos y conexiones (MCP)**:
- Se ofrece **solo** si la Fase 1 está completa (existe `CONTEXT/negocio.md`). Mientras la
  Fase 1 no esté completa, **no ofrezcas ni arranques la Fase 3** (R1). No depende de la
  Fase 2: la Fase 3 puede hacerse aunque Git/GitHub no estén montados (son independientes).
- Si la Fase 1 está completa **y** la Fase 3 **no** consta resuelta a nivel de usuario (no
  hay `~/.claude/aios/estado-usuario.md` con la Fase 3 marcada resuelta) → ofrécela y, si el
  usuario acepta, **invoca la skill `onboarding-datos`** (R2). Ella entrevista qué
  herramientas usa el negocio (reuniones, CRM, almacenamiento tipo Drive / Microsoft 365…),
  las conecta por MCP con alcance de usuario (o con un conector a medida si no hay servidor
  MCP) y deja `DATA/key-metrics.md` con lo que sabe la IA gracias a cada conexión.
- Si `~/.claude/aios/estado-usuario.md` ya marca la **Fase 3 como resuelta** → **no repitas**
  el registro de las conexiones ya resueltas (R15). Informa de que las conexiones del
  ordenador ya están montadas. Si quedaron herramientas **pendientes** anotadas (en ese
  archivo o en `harness/progress/onboarding.md`), ofrece retomar solo esas, sin repetir las
  ya hechas.

---

## Regla de oro (vale para los dos modos)

- Una fase cada vez. No mezcles fases.
- No inventes ni des por hechos datos del negocio ni del proyecto: los aporta el usuario en la
  entrevista o en los documentos que importe.
- Al cerrar la Fase 1 (de empresa o de proyecto), la skill sugiere el siguiente paso. No lo
  ejecutes tú automáticamente: solo sugiérelo.
- En un proyecto (`.aios-proyecto` presente), **jamás** arranques la Fase 2 ni la Fase 3.
