---
description: Genera una propuesta interactiva (HTML) para un cliente a partir del contexto de descubrimiento.
---

Usa la skill `propuestas` para generar la propuesta interactiva HTML que el negocio
presenta a su cliente, con la marca del negocio (colores, tipografías, nombre y logo).

1. Reúne, si no se han dado: el cliente destinatario, la fecha de la reunión de
   descubrimiento y las fuentes (normalmente `CONTEXT/proyecto.md` y las notas de
   `INTELLIGENCE/reuniones/`). Pregunta una sola vez, de forma agrupada; no inventes áreas
   ni cifras.
2. Invoca la skill `propuestas` con esos datos.
3. Devuelve la ruta del HTML generado (por defecto en `INTELLIGENCE/propuestas/`).
