﻿# Arquitectura del Harness — Qué significa "buen trabajo" en el AIOS

> Léelo antes de construir cualquier módulo. Define el listón de calidad.

## Qué es este sistema
El AIOS de {{NOMBRE_NEGOCIO}} es un sistema operativo de negocio sobre Claude Code, organizado en 5 capas (ver `CLAUDE.md`). El **harness** es la capa de gobierno que permite construir módulos nuevos (automatizaciones y herramientas) de forma autónoma, verificable y sin perder estado entre sesiones.

## Principios

1. **El sistema vive en disco, no en el chat.** Todo resultado relevante (specs, progreso, revisiones) se escribe en archivos versionados. El chat es efímero; los archivos sobreviven a reinicios y a ventanas de contexto agotadas.
2. **Un módulo a la vez.** Nunca hay más de una construcción en `in_progress` en `build_backlog.json`. No se mezclan cambios de varios módulos en una sesión.
3. **Nada se construye sin spec aprobado.** Toda construcción pasa por la puerta de aprobación humana ({{DUENO}}) antes de tocar archivos del módulo.
4. **Cada agente tiene un único trabajo.** El leader coordina pero no construye; el spec_author especifica pero no construye; el builder construye pero no se autoaprueba; el reviewer verifica pero no edita.
5. **Verificable o no está hecho.** Un módulo no se marca `done` hasta que `verify.ps1` está verde y la verificación funcional de `verification.md` se cumple.

## Qué es un "módulo" en el AIOS
Una pieza con valor de negocio que se construye sobre las capas base:
- **Automatización** (Capa 4): vive en `AUTOMATION/<modulo>/` (ej. generador de propuestas, procesado de reuniones, daily brief).
- **Herramienta** (Capa 5): vive en `BUILD/<modulo>/` (ej. audit-tool, dashboard).

## Cómo encaja con las capas
- El `explorer` lee `CONTEXT/` y `DATA/` para entender el negocio antes de especificar.
- El `builder` escribe en `AUTOMATION/` o `BUILD/` y conecta con `DATA/integraciones/` e `INTELLIGENCE/`.
- El aprendizaje de cada build se documenta y, si es reutilizable, se generaliza hacia `PLANTILLAS/`.

## Qué NO es buen trabajo
- Dejar resultados solo en el chat.
- Construir sin spec o sin aprobación.
- Marcar `done` sin verificación.
- Commitear API keys o credenciales (van en variables de entorno).
- Dejar el backlog o `progress/current.md` desactualizados al cerrar.
