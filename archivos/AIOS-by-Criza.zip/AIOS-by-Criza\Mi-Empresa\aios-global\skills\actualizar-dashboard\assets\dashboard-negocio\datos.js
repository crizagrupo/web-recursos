// ============================================================================
// DATOS DEL DASHBOARD DE NEGOCIO — Cartera de proyectos de {{NOMBRE_NEGOCIO}}
// ----------------------------------------------------------------------------
// Este panel es de SOLO LECTURA. No lo edites a mano: se regenera solo.
//
// CÓMO RELLENAR / ACTUALIZAR:
//   Ejecuta  /dashboard  a nivel negocio (dentro de Mi-Empresa/). La skill
//   `actualizar-dashboard` (rama de negocio) recorre cada Proyectos/<cliente>/,
//   lee su ESTADO.md y reescribe la lista `proyectos` de abajo, refrescando la
//   fecha `actualizado`. No inventa datos: lo que no consta queda vacío o null.
//
// Esquema (cartera de proyectos):
//   - version       número de esquema (no tocar).
//   - actualizado   fecha de la última regeneración, formato AAAA-MM-DD.
//   - negocio       nombre del negocio (se fija al materializar el dashboard).
//   - proyectos[]   una entrada por proyecto detectado, con:
//       id            slug de la carpeta del proyecto (p. ej. "bar-manolo").
//       nombre        nombre legible del proyecto.
//       estado        "pendiente" | "en_curso" | "completada".
//       avance        0-100, o null si no consta en el ESTADO.md.
//       proximaAccion frase corta con la próxima acción (o "" si no consta).
//       bloqueos      lista de textos; [] si no hay bloqueos.
//       actualizado   última actualización del ESTADO.md del proyecto (o null).
//
// Con la lista vacía (proyectos: []), el panel muestra "Aún no hay proyectos".
// ============================================================================
window.DATOS = {
  "version": 1,
  "actualizado": "",
  "negocio": "{{NOMBRE_NEGOCIO}}",
  "proyectos": []
  // Ejemplo de una entrada (así queda cada proyecto tras ejecutar /dashboard):
  // {
  //   "id": "bar-manolo",
  //   "nombre": "Bar Manolo",
  //   "estado": "en_curso",
  //   "avance": 20,
  //   "proximaAccion": "Completar la Fase 1 (Contexto) con /onboarding.",
  //   "bloqueos": [],
  //   "actualizado": "2026-07-30"
  // }
};
