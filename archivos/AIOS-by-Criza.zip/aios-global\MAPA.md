# MAPA — {{NOMBRE_NEGOCIO}} (nivel negocio)

> Índice para la IA en **modo operación**. Cada fila: intención → archivo a abrir.
> Abre solo lo necesario. Para **construir algo nuevo** → `harness/AGENTS.md`.

## Cliente y negocio (CONTEXT)

| Necesito… | Archivo |
| --- | --- |
| Qué es el negocio, propuesta de valor, diferencial | `CONTEXT/negocio.md` |
| Qué vende y a qué precio | `CONTEXT/servicios-pricing.md` |
| Equipo y responsabilidades | `CONTEXT/equipo.md` |
| Cliente ideal (ICP), sectores | `CONTEXT/clientes-objetivo.md` |
| Objetivos, canales, prioridades | `CONTEXT/estrategia.md` |
| Flujo lead → cierre → entrega | `CONTEXT/procesos.md` |

## Datos e integraciones (DATA)

| Necesito… | Archivo |
| --- | --- |
| Base de datos local | `DATA/db/` |
| Conexiones externas (CRM, BBDD, etc.) | `DATA/integraciones/` |
| Cómo documentar una integración nueva | `DATA/integraciones/PLANTILLA-integracion.md` |
| Scripts de sincronización | `DATA/sync/` |

## Conocimiento vivo (INTELLIGENCE)

| Necesito… | Archivo |
| --- | --- |
| Reuniones (actas, resúmenes) | `INTELLIGENCE/reuniones/` |
| Briefing diario | `INTELLIGENCE/daily-brief/` |
| Estado del pipeline | `INTELLIGENCE/pipeline-status/` |
| Seguimientos pendientes | `INTELLIGENCE/seguimientos-pendientes/` |

## Automatizaciones y herramientas

| Necesito… | Archivo |
| --- | --- |
| Automatizaciones del negocio | `AUTOMATION/` |
| Tareas programadas | `AUTOMATION/cron/` |
| Herramientas comunes | `BUILD/` |
| Dashboard de negocio (todos los proyectos) | `BUILD/dashboard-negocio/` |

## Estado y construcción

| Necesito… | Archivo |
| --- | --- |
| Estado del negocio, pendientes | `ESTADO.md` |
| Registro cronológico | `HISTORICO.md` |
| **Construir/automatizar algo nuevo** | `harness/AGENTS.md` |
