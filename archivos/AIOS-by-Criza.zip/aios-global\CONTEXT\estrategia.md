# Estrategia — {{NOMBRE_NEGOCIO}}

> Capa 1 (Context). Objetivos, canales y prioridades.
> Estado: scaffold — responde las secciones `TODO`.

## Objetivos
TODO — objetivos del periodo (trimestre / año).

## Canales
TODO — por dónde llegan los clientes (referidos, ads, LinkedIn…).

## Prioridades actuales
TODO — en qué se está poniendo el foco ahora.
