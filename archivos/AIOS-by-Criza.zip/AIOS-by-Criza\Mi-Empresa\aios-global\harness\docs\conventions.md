﻿# Convenciones del Harness

> Reglas de estilo y estructura para los módulos del AIOS.

## Nombres
- Módulos en `kebab-case`: `generador-propuestas`, `procesado-reuniones`.
- El `name` en `build_backlog.json`, la carpeta del módulo, la carpeta `harness/specs/<name>/` y los archivos `harness/progress/*_<name>.md` usan **el mismo** nombre.

## Dónde va cada cosa
| Tipo | Ubicación |
|------|-----------|
| Automatización | `AUTOMATION/<modulo>/` |
| Herramienta interna | `BUILD/<modulo>/` |
| Spec de un módulo | `harness/specs/<modulo>/{requirements,design,tasks}.md` |
| Informe de exploración | `harness/progress/explore_<modulo>.md` |
| Informe de construcción | `harness/progress/impl_<modulo>.md` |
| Informe de revisión | `harness/progress/review_<modulo>.md` |

## Documentos de módulo
Cada `AUTOMATION/<modulo>/` o `BUILD/<modulo>/` debe tener un `README.md` que explique, en lenguaje sencillo: qué hace, qué entradas necesita, qué produce, y cómo se ejecuta o programa.

## Scripts
- PowerShell (`.ps1`) por defecto (entorno Windows). Bash solo si el módulo corre en un entorno Linux conocido.
- Toda credencial se lee de variable de entorno. Nunca en texto plano ni commiteada. Documentar el nombre de la variable en `DATA/integraciones/`.

## Avisos operativos (léelos una vez, aplican siempre)
- **JSON sin BOM:** al editar `build_backlog.json` o cualquier otro JSON del repo, no uses
  PowerShell `Set-Content`/`Out-File` sin `-Encoding utf8` — introduce un BOM UTF-8 al
  inicio del archivo que rompe `JSON.parse()`/`require()` en Node. Usa las herramientas de
  edición normales (Edit) o, si tiene que ser PowerShell, `-Encoding utf8` explícito.

## Crons
Las tareas programadas se documentan en `AUTOMATION/cron/*.cron` (qué, frecuencia, schedule cron, estado). La programación real se configura con el Programador de tareas de Windows o `/schedule`.

## Estado en `build_backlog.json`
`pending` → `spec_ready` → `in_progress` → `done`. `blocked` si se atasca (razón en `harness/progress/current.md`).
