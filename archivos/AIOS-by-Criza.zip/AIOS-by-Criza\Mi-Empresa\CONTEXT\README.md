# CONTEXT/ — Quién es el negocio

Capa 1 del AIOS: la identidad del negocio. De aquí lee la IA para saber qué haces, a
quién sirves y cómo trabajas.

**Esta carpeta arranca vacía a propósito.** No la rellenes a mano. Ejecuta el comando
**`/onboarding`**: te entrevistará (o leerá los documentos que le pases) y escribirá él
mismo los seis archivos siguientes con el contenido real de tu negocio.

| Archivo | Qué contiene |
| --- | --- |
| `negocio.md` | Qué hace el negocio, propuesta de valor, diferencial |
| `servicios-pricing.md` | Qué vendes y a qué precio |
| `equipo.md` | Quién es quién y quién decide |
| `clientes-objetivo.md` | A quién te diriges |
| `estrategia.md` | Objetivos y prioridades actuales |
| `procesos.md` | Cómo entra un cliente y cómo se le entrega |

Mientras no exista `negocio.md`, el AIOS sabe que la Fase 1 (Contexto) está pendiente y
`/onboarding` la arranca. Si cortas la entrevista a medias, al volver a ejecutarla retoma
por donde ibas sin repetir lo ya respondido.
