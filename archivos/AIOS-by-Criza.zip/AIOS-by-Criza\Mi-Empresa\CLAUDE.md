# AIOS — {{NOMBRE_NEGOCIO}}

Esta es la carpeta raíz del negocio en el AIOS. Aquí vive **quién es el negocio** (su
`CONTEXT/`) y su trabajo del día a día. Las herramientas (comandos, skills, agentes) se
heredan de la configuración del ordenador (`~/.claude`), así que están disponibles en
cualquier carpeta que abras.

> **Cuándo se hace efectiva esa herencia:** de fábrica, esta carpeta trae una copia de la
> herramienta en `aios-global/`. La **primera vez** que ejecutas `/onboarding`, su Paso 0
> instala esa copia en `~/.claude` (una sola vez) y luego borra `aios-global/` de aquí. A
> partir de ese momento la herramienta vive en `~/.claude` y esta carpeta ya no lleva copia
> propia.

> Herramienta = comandos, skills y agentes, en `~/.claude` (se instalan una vez, desde el
> `aios-global/` que trae esta carpeta).
> Contenido = este `Mi-Empresa/` y, más adelante, cada `Proyectos/<cliente>/`.

## Cómo empezar

Si esta carpeta aún no conoce el negocio (no hay `CONTEXT/negocio.md`), ejecuta
**`/onboarding`**: te entrevistará y escribirá él mismo los archivos de `CONTEXT/`. No
necesitas editar nada a mano.

## Dos modos de trabajo

- **Operación** (por defecto): preguntas, consultas, registro del día a día → responde
  directo. Lee solo lo necesario de `CONTEXT/`.
- **Construcción**: crear/automatizar algo nuevo → flujo del harness
  (`~/.claude/harness/AGENTS.md`). **Nada se construye sin aprobación.**

## Reglas duras

1. **Empieza por el contexto**: antes de actuar sobre el negocio, lee lo relevante de
   `CONTEXT/`. No lo abras entero por defecto.
2. **Construir = aprobación previa**: presenta el plan y espera el visto bueno antes de
   tocar nada.
3. **Nunca commitees credenciales**: van en `.env` (variables de entorno).

## Pointers

- Identidad del negocio → `CONTEXT/`
- Instalación / onboarding → comando `/onboarding`
- Construcción (harness) → `~/.claude/harness/AGENTS.md`
- Comandos y skills → `~/.claude/` (heredados)

Idioma de trabajo: **español**.
