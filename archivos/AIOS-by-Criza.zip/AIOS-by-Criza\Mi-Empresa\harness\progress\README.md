# harness/progress/

Estado vivo de las construcciones y del onboarding de esta carpeta.

Durante el onboarding, el comando `/onboarding` crea y mantiene aquí un archivo
**`onboarding.md`** con el progreso reanudable de sus fases: la **Fase 1 (Contexto)** (qué
temas están cerrados, cuál está en curso y notas de las respuestas ya dadas) y la **Fase 3
(Datos y conexiones)** (qué herramientas quedaron conectadas y cuáles pendientes). Gracias a
él, si cortas a medias y vuelves a ejecutar `/onboarding`, retoma por lo pendiente sin
repetir. (La Fase 2, Infraestructura, deja su constancia a nivel de usuario, en
`~/.claude/aios/estado-usuario.md`.)

Este archivo `onboarding.md` **no existe en la plantilla**: aparece la primera vez que
ejecutas `/onboarding` y desaparece de tu atención cuando la fase queda `completa` (queda
como registro de que se hizo).
