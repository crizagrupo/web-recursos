# {{NOMBRE_PROYECTO}} — Guía rápida

> Carpeta de proyecto del AIOS. Hereda el negocio; aquí va el trabajo de este cliente/iniciativa.

## Cómo está organizado

| Carpeta / archivo | Qué hay dentro |
| --- | --- |
| `ESTADO.md` | Cómo va el proyecto ahora. **El que más vas a abrir.** |
| `HISTORICO.md` | Lo que se ha hecho. |
| `CONTEXT/` | Lo específico de este proyecto/cliente. |
| `DATA/` | Datos e integraciones del proyecto. |
| `INTELLIGENCE/` | Reuniones, seguimientos. |
| `AUTOMATION/` | Automatizaciones del proyecto. |
| `BUILD/` | Herramientas del proyecto + dashboard. |
| `harness/` | Para construir cosas nuevas (se activa cuando hace falta). |
| `CLAUDE.md` · `MAPA.md` | Para la IA. No los necesitas tú. |

## Cómo pedirle cosas a la IA

- *"¿Cómo va el proyecto?"*
- *"Guarda esta reunión: [notas]"*
- *"Construye una automatización para X"* → te pedirá aprobar el plan antes de hacerla.
