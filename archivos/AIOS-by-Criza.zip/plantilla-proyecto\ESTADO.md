# ESTADO — {{NOMBRE_PROYECTO}}

> Última actualización: {{FECHA}}
> Lo actualiza la IA tras cualquier tarea relevante. Lo lee el dashboard de negocio.

## Fase activa

{{FASE_ACTUAL}}

## Próxima acción

- {{PROXIMA_ACCION}}

## Pendientes

- TODO

## Bloqueos

- Ninguno.
