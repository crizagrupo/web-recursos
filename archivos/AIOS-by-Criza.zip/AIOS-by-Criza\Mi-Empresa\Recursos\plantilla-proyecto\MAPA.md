# MAPA — Proyecto: {{NOMBRE_PROYECTO}}

> Índice de navegación de este proyecto. Abre solo lo que necesites; no leas todo por
> defecto.

## Por intención

| Quiero… | Voy a… |
| --- | --- |
| Saber qué es este proyecto | `CONTEXT/proyecto.md` |
| Saber quién es el negocio (heredado) | `../../Mi-Empresa/CONTEXT/` |
| Ver el estado del proyecto | `ESTADO.md` |
| Ver los hitos del proyecto | `HISTORICO.md` |
| Ver las conexiones de datos disponibles | `DATA/` (heredadas del negocio) |
| Consultar conocimiento vivo (reuniones, briefs) | `INTELLIGENCE/` |
| Ver/lanzar automatizaciones del proyecto | `AUTOMATION/` |
| Ver/lanzar herramientas del proyecto | `BUILD/` |
| Construir algo nuevo (harness) | `~/.claude/harness/AGENTS.md` |

## Las 5 capas (esquema ligero de proyecto)

| Capa | Carpeta | Para qué |
| --- | --- | --- |
| 1 Context | `CONTEXT/` | Quién es este cliente/proyecto (`proyecto.md`). |
| 2 Data | `DATA/` | Conexiones de datos (heredadas del negocio). |
| 3 Intelligence | `INTELLIGENCE/` | Reuniones, briefs y seguimientos del proyecto. |
| 4 Automation | `AUTOMATION/` | Automatizaciones específicas del proyecto. |
| 5 Build | `BUILD/` | Herramientas específicas del proyecto. |

Los comandos y skills se heredan de `~/.claude` (instalados una vez para todo el negocio).
