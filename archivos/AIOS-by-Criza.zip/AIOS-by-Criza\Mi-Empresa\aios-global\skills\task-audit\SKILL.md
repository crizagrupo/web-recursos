---
name: task-audit
description: Conduce la auditoría de tareas del AIOS. Lee el CONTEXT/ de la carpeta actual (negocio o proyecto) para no repetir preguntas, entrevista por áreas del negocio qué tareas recurrentes se hacen, registra la frecuencia, el tiempo y la categoría de automatización de cada una, las puntúa por impacto × facilidad y escribe un scoreboard priorizado (quick wins primero) como checklist marcable en INTELLIGENCE/task-audit/. Se puede reejecutar para reevaluar sin perder el histórico. La invoca el comando /task-audit. No hace falta que el usuario sepa programar.
---

# Skill: task-audit — auditoría de tareas automatizables

Tu trabajo es **mapear las tareas recurrentes** de la carpeta actual y decir, con criterio,
**cuáles conviene automatizar primero**. Entrevistas al usuario en lenguaje normal, apoyándote
en lo que ya sabes de su negocio (su `CONTEXT/`), y **escribes tú** un scoreboard priorizado
que él pueda ir tachando.

Patrón de referencia: las skills `onboarding-contexto` e `informe` (leer contexto →
entrevistar por temas → estructurar → escribir el archivo). Aquí: **leer `CONTEXT/` →
entrevistar por áreas → puntuar → escribir el scoreboard**.

> El catálogo de áreas, las preguntas guía y la **rúbrica de puntuación** están en
> `references/areas.md`. El **formato exacto** del archivo de salida está en
> `references/plantilla-scoreboard.md`. Léelos antes de entrevistar y antes de escribir.

## Principios (no los rompas)

- **Conversación, no formulario.** Recorre las áreas de una en una o de pocas en pocas.
  Nunca vuelques todas las áreas y todas las preguntas de golpe. (R7)
- **Reutiliza el contexto.** No repreguntes lo que ya consta en `CONTEXT/`. Parte de ahí y
  pregunta solo lo que falta para puntuar (frecuencia, tiempo, categoría). (R4)
- **No inventes.** Frecuencias, tiempos y categorías los aporta el usuario; si un dato falta,
  pregúntalo. No rellenes a ojo.
- **Carpeta actual, sin suposiciones.** Trabaja sobre las rutas de la carpeta desde la que te
  ejecutan, sea `Mi-Empresa/` o un `Proyectos/<cliente>/`. No subas por el árbol buscando
  otra ni asumas cuál es. (R14)
- **Tono cercano y no técnico.** El usuario probablemente no es programador.

---

## Paso 1 — Comprobar el contexto (siempre primero) (R3, R18)

Antes de preguntar nada, **lee el `CONTEXT/` de la carpeta actual** para entrar con el
negocio ya sabido:

1. Comprueba si existe `CONTEXT/negocio.md` (empresa) **o** `CONTEXT/proyecto.md` (proyecto).
   - **Si NO existe `CONTEXT/negocio.md` (ni `CONTEXT/proyecto.md` con contenido real):** la
     Fase 1 no está hecha. **Avisa** en lenguaje llano de que conviene completar antes el
     contexto con **`/onboarding`** (Fase 1) y **no des por buena una entrevista sin
     contexto**: sin saber qué hace el negocio, la auditoría sería a ciegas. No sigas como si
     hubiera contexto. (R18) Puedes ofrecerte a arrancar el onboarding, pero no lo suplantes
     inventando el negocio.
2. **Si existe**, lee los archivos de `CONTEXT/` relevantes antes de empezar (R3):
   `negocio.md` (qué hace), `servicios-pricing.md` (qué vende), `procesos.md` (cómo entra y
   se entrega un cliente, y las herramientas por paso), `equipo.md` (si hay personas a
   cargo), `estrategia.md` (prioridades). En un proyecto, lee `CONTEXT/proyecto.md` y, si hace
   falta, el negocio heredado en `../../Mi-Empresa/CONTEXT/`.
3. Con eso ya sabes de qué negocio se trata: úsalo para **adaptar las áreas** (Paso 3) y para
   **no repreguntar** lo que ya consta (R4).

## Paso 2 — Detectar si es una reevaluación (R15, R16)

Comprueba si ya existe `INTELLIGENCE/task-audit/scoreboard.md` en la carpeta actual:

- **Si NO existe** → es la **primera** auditoría. Sigue al Paso 3 con hoja en blanco.
- **Si existe** → es una **reevaluación**. Antes de tocar nada:
  1. **Lee el scoreboard anterior** y anota qué tareas estaban marcadas como resueltas
     (`[x]`), guardando su **texto** para reconocerlas luego y conservarlas resueltas. (R16)
  2. **Archiva** el scoreboard anterior copiándolo tal cual a
     `INTELLIGENCE/task-audit/historico/<AAAA-MM-DD>-scoreboard.md`, usando la **fecha de la
     evaluación** que llevaba dentro (o, si no la tuviera, la de hoy). Crea la carpeta
     `historico/` si no existe. **No sobrescribas** un archivo de histórico existente: si ya
     hubiera uno con esa fecha, añade un sufijo (`-2`, `-3`) en vez de pisarlo. (R15)
  3. Solo **después** de archivar, procede a construir el nuevo scoreboard (Pasos 3–7), que
     sobrescribirá el `scoreboard.md` vigente.

> Regla: el histórico **nunca** se pisa (lleva la fecha en el nombre); el vigente
> (`scoreboard.md`) es uno solo y es el que el usuario tacha.

## Paso 3 — Elegir y adaptar las áreas (R5, R6)

Parte del catálogo de ocho áreas de `references/areas.md` (marketing y contenido; ventas y
pipeline; entrega a cliente; operaciones y administración; equipo; datos y reporting;
comunicación; estratégico/creativo) (R5) y **ajústalo al negocio** que has leído en
`CONTEXT/` (R6):

- **Adapta los ejemplos** de cada área al sector real del negocio.
- **Omite** un área que claramente no aplique (p. ej. "Equipo" en un autónomo sin personas a
  cargo). Si dudas, pregunta en una frase en vez de darlo por hecho.
- Anota mentalmente qué áreas vas a recorrer y en qué orden (uno natural para ese negocio).

## Paso 4 — Entrevistar por áreas (conversacional) (R7, R8, R9)

Recorre las áreas **de una en una o de pocas en pocas**, no como formulario (R7). En cada
área:

1. **Abre reconociendo lo que ya sabes** del `CONTEXT/` ("Por tu contexto, veo que repartís a
   bares por la mañana…") y pregunta qué tareas **recurrentes** hace en esa área.
2. Por **cada tarea** que salga, registra los tres datos de la rúbrica (`references/areas.md`,
   Parte 3):
   - **Frecuencia** — cada cuánto se hace (varias veces al día, diaria, semanal, mensual…). (R8)
   - **Tiempo por vez** — cuánto consume cada vez, en minutos u horas aprox. (R8)
   - **Categoría de automatización** — una de las cuatro (R9): **totalmente automatizable**,
     **parcialmente automatizable**, **no automatizable todavía**, o **solo humano**. Tú
     propones la categoría con criterio y la confirmas con el usuario; no se la hagas elegir a
     él con jerga.
3. **No repreguntes** lo que ya diga `CONTEXT/`: si el proceso ya está descrito, pregunta solo
   el detalle que falta para puntuar (frecuencia/tiempo/categoría). (R4)
4. Cierra el área con un resumen de una línea y pasa a la siguiente. Apunta las tareas según
   salen (en tu borrador de trabajo) para no perderlas si la sesión se corta.

Objetivo razonable: recoger unas **6–10 tareas** repartidas por las áreas que apliquen. No
fuerces relleno: mejor pocas tareas bien caracterizadas que muchas a medias.

## Paso 5 — Puntuar y priorizar (R10, R11)

Con todas las tareas recogidas, aplica la rúbrica de `references/areas.md` (Parte 3):

1. **Impacto (h/mes)** = `(tiempo_por_vez_min ÷ 60) × veces_al_mes`, usando la tabla de
   conversión de frecuencia. Clasifícalo en banda: alto (≥ 8), medio (2–8), bajo (< 2). (R10)
2. **Facilidad** derivada de la categoría: totalmente → alta, parcialmente → media, no todavía
   → baja, solo humano → no aplica.
3. **Prioridad** = `impacto × factor_facilidad` (alta 1,0 · media 0,6 · baja 0,3). Ordena las
   tareas automatizables por prioridad descendente. (R10)
4. **Quick wins** (R11): las de **impacto alto y facilidad alta** (totalmente automatizables).
   Van **primero** en el scoreboard.
5. Las tareas **solo humano** quedan **fuera** de la priorización de automatización: se listan
   aparte como referencia.

Usa números redondos y sentido común: es una guía para ordenar con criterio, no una ciencia
exacta.

## Paso 6 — Determinar próximos pasos (R17)

Para cada tarea automatizable, mira si **ya existe** una skill o un comando **instalado en la
herramienta** que la resuelva, y si es así, apúntalo como próximo paso junto a la tarea:

1. Consulta qué hay instalado a nivel de usuario: los comandos de `~/.claude/commands/` y las
   skills de `~/.claude/skills/`. Léelos por su nombre y su `description` para saber qué
   resuelve cada uno.
2. Empareja cada tarea con el comando/skill que la cubra, cuando lo haya. Ejemplos de mapeo
   con lo que suele venir instalado:
   - "guardar / respaldar el trabajo, hacer backup" → **`/commit`**.
   - "documentar el negocio / actualizar el contexto" → **`/onboarding`**.
   - "abrir una carpeta nueva para un cliente o proyecto" → **`/crear-proyecto`**.
   - Y cualquier otra skill/comando que se haya añadido después (p. ej. procesado de
     reuniones, daily brief, generador de propuestas): si su `description` encaja con la
     tarea, señálalo.
3. **No inventes** herramientas que no estén instaladas. Si ninguna resuelve la tarea, no
   pongas próximo paso (o indica "sin herramienta aún"): eso mismo señala una oportunidad de
   construir algo nuevo con el harness.

## Paso 7 — Escribir el scoreboard (R12, R13, R16)

Escribe (o sobrescribe, si es reevaluación) `INTELLIGENCE/task-audit/scoreboard.md` de la
**carpeta actual**, con el formato de `references/plantilla-scoreboard.md`. **Crea la carpeta
`INTELLIGENCE/task-audit/` si no existe.**

- **Fecha de la evaluación** (la de hoy) al principio. (R13)
- **Quick wins primero**; luego el resto de tareas automatizables ordenadas por prioridad; al
  final, las **solo humano** como referencia. (R11)
- **Cada tarea como checklist marcable `[ ]`**, con su área, frecuencia, tiempo, impacto en
  h/mes y categoría, y la línea `→ Próximo paso` donde haya herramienta. (R12, R17)
- **Reevaluación:** las tareas que en el scoreboard anterior estaban marcadas `[x]` (Paso 2)
  se escriben también como `[x]` en el nuevo, reconociéndolas por su texto, aunque cambien de
  sección. Así la reevaluación se centra en lo que sigue pendiente y no vuelve a marcar como
  pendiente lo ya resuelto. (R16)

## Paso 8 — Cerrar con el usuario

1. Muéstrale un resumen breve: cuántas tareas registraste, cuáles son los **quick wins** y
   dónde está el archivo (`INTELLIGENCE/task-audit/scoreboard.md`).
2. Explícale que puede **ir tachando** las tareas (`[x]`) a medida que las resuelva, y que
   puede **volver a ejecutar `/task-audit`** más adelante para reevaluar (se guardará el
   histórico y se conservará lo que haya marcado como resuelto).
3. Si hay quick wins con próximo paso ya cubierto por una herramienta instalada, señálalo como
   siguiente acción sugerida. No lo ejecutes tú: solo propónlo.

## Qué NO hacer

- No presentes todas las áreas y preguntas de golpe: conversa, un área o pocas cada vez. (R7)
- No repreguntes lo que ya consta en `CONTEXT/`. (R4)
- No inventes frecuencias, tiempos ni categorías: los aporta el usuario. (R8, R9)
- No des por buena una auditoría sin `CONTEXT/`: avisa de ejecutar antes `/onboarding`. (R18)
- No sobrescribas el scoreboard anterior sin archivarlo primero en `historico/`. (R15)
- No vuelvas a marcar como pendiente una tarea que el usuario ya había dado por resuelta. (R16)
- No señales como próximo paso una skill/comando que no esté instalado. (R17)
- No asumas que estás en `Mi-Empresa/`: opera sobre la carpeta actual (puede ser un proyecto). (R14)
- No toques archivos fuera de la carpeta actual (salvo leer el `CONTEXT/` heredado del negocio,
  en un proyecto).
