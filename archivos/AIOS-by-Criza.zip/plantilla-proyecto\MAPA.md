# MAPA — {{NOMBRE_PROYECTO}}

> Índice para la IA en **modo operación**. Abre solo lo necesario.
> Para **construir algo nuevo** → `harness/AGENTS.md`.
> El contexto general del negocio se hereda del nivel global; aquí solo lo del proyecto.

## Contexto del proyecto

| Necesito… | Archivo |
| --- | --- |
| Qué es este proyecto/cliente, alcance | `CONTEXT/proyecto.md` |
| Lo específico del cliente | `CONTEXT/` |

## Datos e integraciones del proyecto

| Necesito… | Archivo |
| --- | --- |
| Datos locales | `DATA/db/` |
| Integraciones propias del proyecto | `DATA/integraciones/` |

## Conocimiento vivo

| Necesito… | Archivo |
| --- | --- |
| Reuniones | `INTELLIGENCE/reuniones/` |
| Seguimientos | `INTELLIGENCE/seguimientos-pendientes/` |

## Trabajo

| Necesito… | Archivo |
| --- | --- |
| Automatizaciones del proyecto | `AUTOMATION/` |
| Herramientas del proyecto | `BUILD/` |
| Dashboard del proyecto | `BUILD/dashboard/` |

## Estado y construcción

| Necesito… | Archivo |
| --- | --- |
| Estado, pendientes, bloqueos | `ESTADO.md` |
| Registro cronológico | `HISTORICO.md` |
| **Construir algo** | `harness/AGENTS.md` |
