---
name: informe
description: Genera un informe .docx con el estilo corporativo del negocio (auditoría, tareas o genérico) a partir de fuentes (transcripciones, notas, resúmenes). Úsala cuando el usuario pida "hacer/generar un informe", "informe de auditoría", "pasar la reunión a informe", o similar. Funciona en cualquier proyecto. Optimizada para mínimo consumo de tokens.
---

# Skill: generar informe (.docx)

> La identidad visual (nombre de empresa, email, colores) se configura una vez en
> `branding.json`, en la raíz de este skill. Edítalo al instalar el AIOS.

Skill global y reutilizable en **cualquier proyecto**. El motor (scripts y plantillas)
vive dentro de este skill, en `scripts/` y `plantillas/`; no depende del proyecto.

Dispara el pipeline `scripts/generar-informe.py`. **La IA pesada (redacción) corre
dentro del script con el modelo Sonnet vía CLI de Claude; la maquetación es sin IA.**
Tu trabajo aquí es solo orquestar con el mínimo gasto posible.

## Reglas de eficiencia (IMPORTANTE)

- **No** leas las plantillas `.docx`, ni `docx_estilo.py`, ni inspecciones estilos/XML: ya está resuelto.
- **No** redactes tú el informe ni resumas las fuentes: de eso se encarga el script.
- **No** vuelvas a leer fuentes completas para "entenderlas"; basta con conocer sus rutas.
- Limítate a: reunir parámetros → lanzar el comando → reportar y entregar el archivo.

## Parámetros que necesitas

1. `--tipo`: `auditoria` | `tareas` | `generico` (deduce del contexto; si dudas, pregunta).
2. `--cliente`: nombre del cliente (p. ej. "Cid Abogados").
3. `--proyecto`: texto de la línea "Proyecto:" de la cabecera.
4. `--fecha`: texto de la línea "Fecha:" (p. ej. "Mayo 2026").
5. `--salida`: ruta del `.docx` (relativa a la carpeta del proyecto actual).
6. `fuentes`: una o más rutas (txt/md/docx) con la transcripción/notas/resumen.
7. `--reglas` (opcional): archivo de líneas rojas del proyecto. Para clientes legales,
   si el proyecto lo tiene, usa `.claude/rules/sector-legal.md`.
8. `--modelo` (opcional): `sonnet` (defecto) | `haiku` (más barato) | `opus`.

Si falta algún dato esencial (cliente, proyecto, fecha, salida o fuentes), **pregunta una vez**
de forma agrupada; no asumas nombres ni fechas.

## Comando

Ejecútalo **desde la raíz del proyecto** sobre el que trabajas (así `--salida` y las
fuentes se resuelven en ese proyecto). El script es global:

```
py -X utf8 "$HOME/.claude/skills/informe/scripts/generar-informe.py" \
  --tipo <tipo> --cliente "<cliente>" --proyecto "<proyecto>" --fecha "<fecha>" \
  [--reglas ".claude/rules/sector-legal.md"] [--modelo sonnet] \
  --salida "<ruta.docx>" \
  "<fuente1>" "<fuente2>"
```

En PowerShell, usa `$env:USERPROFILE\.claude\skills\informe\scripts\generar-informe.py`
si `$HOME` no resuelve la ruta del ejecutable nativo.

## Tras ejecutar

- Si el comando termina bien, entrega el `.docx` generado al usuario y dilo en una frase.
- Si falla por el CLI de Claude (no encontrado/sin sesión) o por una fuente inexistente,
  reporta la causa concreta en una línea y la solución; no reintentes a ciegas.
- Ofrece `--guardar-md` solo si el usuario quiere revisar/editar el texto antes de maquetar.
