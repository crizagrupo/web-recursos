# -*- coding: utf-8 -*-
"""
Maquetación DOCX con estilo corporativo — SIN IA.

Clona la plantilla `plantillas/Plantilla_Informe_TAREAS.docx` (hereda styles,
theme, numbering y rels) y sustituye word/document.xml. Expone helpers de
formato y un conversor `markdown_a_docx()` para transformar un Markdown sencillo
en un .docx con la identidad del negocio.

La identidad (nombre de empresa, email de contacto y colores) se lee de
`branding.json` en la raíz del skill. Esta capa no consume tokens: solo da formato.
"""
import json
import os
import re
import zipfile

# Plantilla base de estilo (fuente de styles/theme/numbering/rels).
# Vive dentro del propio skill para funcionar desde cualquier carpeta de trabajo.
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PLANTILLA_ESTILO = os.path.join(SKILL_DIR, "plantillas", "Plantilla_Informe_TAREAS.docx")
BRANDING_PATH = os.path.join(SKILL_DIR, "branding.json")

FONT = '<w:rFonts w:ascii="Segoe UI" w:hAnsi="Segoe UI" w:eastAsia="Segoe UI" w:cs="Segoe UI" />'
SPACING = '<w:spacing w:before="%d" w:beforeAutospacing="off" w:after="%d" w:afterAutospacing="off" />'


def _load_branding():
    data = {}
    try:
        with open(BRANDING_PATH, encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        pass

    def clean(value, fallback):
        if not value or "{{" in str(value):
            return fallback
        return str(value)

    return {
        "empresa": clean(data.get("empresa"), "Empresa"),
        "email": clean(data.get("email"), ""),
        "color_primario": clean(data.get("color_primario"), "1A56DB"),
        "color_tabla": clean(data.get("color_tabla_cabecera"), "1A35E8"),
    }


BRANDING = _load_branding()


def esc(t):
    return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def run(text, b=0, i=0, caps=0, color="1A1A1A", sz=21):
    rpr = FONT
    rpr += '<w:b w:val="%d" /><w:bCs w:val="%d" />' % (b, b)
    rpr += '<w:i w:val="%d" /><w:iCs w:val="%d" />' % (i, i)
    if caps:
        rpr += '<w:caps w:val="1" />'
    rpr += '<w:color w:val="%s" />' % color
    rpr += '<w:sz w:val="%d" /><w:szCs w:val="%d" />' % (sz, sz)
    rpr += '<w:lang w:val="es-ES" />'
    return '<w:r><w:rPr>%s</w:rPr><w:t xml:space="preserve">%s</w:t></w:r>' % (rpr, esc(text))


def inline_runs(text, color="1A1A1A", sz=21):
    """Convierte **negrita** inline en runs; el resto en runs normales."""
    out = ""
    for part in re.split(r"(\*\*.+?\*\*)", text):
        if not part:
            continue
        if part.startswith("**") and part.endswith("**") and len(part) > 4:
            out += run(part[2:-2], b=1, color=color, sz=sz)
        else:
            out += run(part, b=0, color=color, sz=sz)
    return out


def para(inner, pstyle=None, before=0, after=150, jc="both", num_id=None):
    ppr = ""
    if pstyle:
        ppr += '<w:pStyle w:val="%s" />' % pstyle
    if num_id is not None:
        ppr += '<w:numPr><w:ilvl w:val="0" /><w:numId w:val="%d" /></w:numPr>' % num_id
    ppr += SPACING % (before, after)
    if jc:
        ppr += '<w:jc w:val="%s" />' % jc
    return '<w:p><w:pPr>%s</w:pPr>%s</w:p>' % (ppr, inner)


def empty():
    return '<w:p><w:pPr><w:pStyle w:val="Normal" /></w:pPr></w:p>'


def h1(text):
    return para(run(text, b=1, color="111111", sz=28), pstyle="Heading1",
                before=0, after=120, jc=None)


def h2(text):
    return para(run(text, b=1, i=1, caps=1, color=BRANDING["color_primario"], sz=21), pstyle="Heading2",
                before=480, after=150, jc=None)


def h3(text):
    return para(run(text, b=1, color="222222", sz=20), pstyle="Heading3",
                before=270, after=120, jc=None)


def parrafo(text):
    return para(inline_runs(text), after=150, jc="both")


def bullet(text):
    return para(inline_runs(text), pstyle="ListParagraph", after=0, jc=None, num_id=2)


def bullet_kv(lead, rest):
    return para(run(lead, b=1) + run(" " + rest), pstyle="ListParagraph",
                after=0, jc=None, num_id=2)


def header_table(proyecto, fecha):
    left = ('<w:tc><w:tcPr><w:tcW w:w="4875" w:type="dxa" /><w:tcMar /></w:tcPr>'
            '<w:p><w:pPr>' + (SPACING % (0, 0)) + '</w:pPr>'
            + run(BRANDING["empresa"], b=1, i=1, color=BRANDING["color_primario"], sz=26) + '</w:p></w:tc>')
    rp = ('<w:p><w:pPr><w:pStyle w:val="Normal" />' + (SPACING % (0, 0)) + '</w:pPr>'
          + run("Proyecto: ", b=1, color="555555", sz=17)
          + run(proyecto, b=0, color="555555", sz=17) + '</w:p>')
    rp += ('<w:p><w:pPr><w:pStyle w:val="Normal" />' + (SPACING % (0, 0)) + '</w:pPr>'
           + run("Fecha: ", b=1, color="555555", sz=17)
           + run(fecha, b=0, color="555555", sz=17) + '</w:p>')
    right = '<w:tc><w:tcPr><w:tcW w:w="4140" w:type="dxa" /><w:tcMar /></w:tcPr>' + rp + '</w:tc>'
    borders = ''.join('<w:%s w:val="none" w:color="E8E8E8" w:sz="2" />' % s
                      for s in ("top", "left", "bottom", "right", "insideH", "insideV"))
    tblpr = ('<w:tblPr><w:tblStyle w:val="TableGrid" /><w:tblW w:w="0" w:type="auto" />'
             '<w:tblBorders>' + borders + '</w:tblBorders>'
             '<w:tblLook w:val="06A0" w:firstRow="1" w:lastRow="0" w:firstColumn="1" '
             'w:lastColumn="0" w:noHBand="1" w:noVBand="1" /></w:tblPr>')
    grid = '<w:tblGrid><w:gridCol w:w="4875" /><w:gridCol w:w="4140" /></w:tblGrid>'
    row = '<w:tr><w:trPr><w:trHeight w:val="360" /></w:trPr>' + left + right + '</w:tr>'
    return '<w:tbl>' + tblpr + grid + row + '</w:tbl>'


def _widths(headers):
    total = 9015
    n = len(headers)
    if n == 4 and headers[0].strip() in ("#", "Nº", "N°"):
        return [900, 4100, 2100, 1915]
    if n > 1 and headers[0].strip() in ("#", "Nº", "N°"):
        rest = (total - 900) // (n - 1)
        return [900] + [rest] * (n - 1)
    return [total // n] * n


def tabla(headers, rows):
    """Tabla genérica: primera fila cabecera de color (texto blanco), filas con
    borde inferior gris. La 1ª y últimas columnas centradas; resto a la izquierda."""
    widths = _widths(headers)
    n = len(headers)

    def hcell(w, text):
        return ('<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa" />'
                '<w:shd w:val="clear" w:color="auto" w:fill="%s" /><w:tcMar />'
                '<w:vAlign w:val="center" /></w:tcPr>'
                '<w:p><w:pPr>' + (SPACING % (0, 0)) + '<w:jc w:val="center" /></w:pPr>'
                '<w:r><w:rPr><w:b w:val="1" /><w:bCs w:val="1" /><w:color w:val="FFFFFF" />'
                '<w:sz w:val="19" /><w:szCs w:val="19" /></w:rPr>'
                '<w:t xml:space="preserve">%s</w:t></w:r></w:p></w:tc>') % (w, BRANDING["color_tabla"], esc(text))

    def dcell(w, text, center):
        jc = '<w:jc w:val="center" />' if center else ''
        return ('<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa" />'
                '<w:tcBorders><w:bottom w:val="single" w:color="E8E8E8" w:sz="2" /></w:tcBorders>'
                '<w:tcMar /><w:vAlign w:val="center" /></w:tcPr>'
                '<w:p><w:pPr>' + (SPACING % (0, 0)) + '%s</w:pPr>'
                '<w:r><w:rPr><w:sz w:val="19" /><w:szCs w:val="19" /></w:rPr>'
                '<w:t xml:space="preserve">%s</w:t></w:r></w:p></w:tc>') % (w, jc, esc(text))

    hrow = ('<w:tr><w:trPr><w:trHeight w:val="570" /></w:trPr>'
            + ''.join(hcell(widths[i], headers[i]) for i in range(n)) + '</w:tr>')
    body = ''
    for r in rows:
        cells = ''
        for i in range(n):
            val = r[i] if i < len(r) else ''
            center = (i == 0) or (i == n - 1) or (n > 3 and i >= 2)
            cells += dcell(widths[i], val, center)
        body += '<w:tr><w:trPr><w:trHeight w:val="432" /></w:trPr>' + cells + '</w:tr>'
    borders = ''.join('<w:%s w:val="none" w:color="000000" w:sz="12" />' % s
                      for s in ("top", "left", "bottom", "right", "insideH", "insideV"))
    tblpr = ('<w:tblPr><w:tblStyle w:val="TableGrid" /><w:tblW w:w="0" w:type="auto" />'
             '<w:jc w:val="center" /><w:tblBorders>' + borders + '</w:tblBorders>'
             '<w:tblLook w:val="06A0" w:firstRow="1" w:lastRow="0" w:firstColumn="1" '
             'w:lastColumn="0" w:noHBand="1" w:noVBand="1" /></w:tblPr>')
    grid = '<w:tblGrid>' + ''.join('<w:gridCol w:w="%d" />' % w for w in widths) + '</w:tblGrid>'
    return '<w:tbl>' + tblpr + grid + hrow + body + '</w:tbl>'


# Alias de compatibilidad
steps_table = tabla


def footer():
    divider = ('<w:p><w:pPr><w:bidi w:val="0" />' + (SPACING % (0, 0)) + '</w:pPr>'
               + run("_" * 108, b=1, i=1, color=BRANDING["color_primario"], sz=20) + '</w:p>')
    tabs = '<w:r><w:tab /></w:r>' * 8
    linea = run(BRANDING["empresa"], b=1, i=1, color=BRANDING["color_primario"], sz=20)
    if BRANDING["email"]:
        linea += tabs + run(BRANDING["email"], b=0, color="BFBFBF", sz=22)
    contact = '<w:p><w:pPr>' + (SPACING % (0, 0)) + '</w:pPr>' + linea + '</w:p>'
    return empty() + divider + contact


def _build_document(template_xml, body):
    prefix = template_xml.split("<w:body>", 1)[0] + "<w:body>"
    tail = template_xml[template_xml.rfind("<w:sectPr"):]
    return prefix + body + tail


def write_docx(out_path, body, plantilla=PLANTILLA_ESTILO):
    """Empaqueta el .docx clonando la plantilla de estilo y sustituyendo el body."""
    with zipfile.ZipFile(plantilla) as zin:
        names = [n for n in zin.namelist() if not n.startswith("[trash]/")]
        data = {n: zin.read(n) for n in names}
        template_xml = zin.read("word/document.xml").decode("utf-8")
    data["word/document.xml"] = _build_document(template_xml, body).encode("utf-8")
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zout:
        for name, content in data.items():
            zout.writestr(name, content)
    return out_path


# ---------------------------------------------------------------------------
# Conversor Markdown -> DOCX
# ---------------------------------------------------------------------------
def _es_separador(celdas):
    return all(set(c.strip()) <= set("-: ") and c.strip() for c in celdas)


def markdown_a_docx(md, proyecto, fecha, out_path, plantilla=PLANTILLA_ESTILO):
    """
    Markdown soportado:
      # H1 (título)        ## H2 (sección)        ### H3 (subsección)
      - viñeta             **negrita** inline     tabla GFM (| a | b |)
      párrafo normal
    El bloque de cabecera (Empresa / Proyecto / Fecha) y el pie se añaden solos.
    """
    body = header_table(proyecto, fecha) + empty()
    tabla_buf = []

    def flush():
        nonlocal tabla_buf, body
        if not tabla_buf:
            return
        filas = [[c.strip() for c in row.strip().strip("|").split("|")] for row in tabla_buf]
        headers = filas[0]
        datos = [f for f in filas[1:] if not _es_separador(f)]
        body += tabla(headers, datos)
        tabla_buf = []

    for raw in md.split("\n"):
        s = raw.strip()
        if s.startswith("|") and s.endswith("|") and "|" in s[1:-1] + "|":
            tabla_buf.append(s)
            continue
        flush()
        if not s:
            continue
        if s.startswith("### "):
            body += h3(s[4:].strip())
        elif s.startswith("## "):
            body += h2(s[3:].strip())
        elif s.startswith("# "):
            body += h1(s[2:].strip())
        elif s.startswith("- ") or s.startswith("* "):
            body += bullet(s[2:].strip())
        else:
            body += parrafo(s)
    flush()
    body += footer()
    return write_docx(out_path, body, plantilla)
