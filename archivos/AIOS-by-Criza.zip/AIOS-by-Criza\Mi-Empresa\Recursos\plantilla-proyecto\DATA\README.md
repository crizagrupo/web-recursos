# DATA — Datos y conexiones (heredadas del negocio)

Capa 2 del AIOS a nivel de proyecto. Las **conexiones** con herramientas externas (reuniones,
CRM, almacenamiento tipo Drive / Microsoft 365…) **no se configuran aquí**: se resolvieron
**una vez por ordenador** en la Fase 3 del onboarding del negocio (`Mi-Empresa/`) y este
proyecto las **hereda** sin reconectar nada.

- Las conexiones a nivel de usuario (registradas con alcance de usuario) están disponibles en
  cualquier carpeta que abras, incluida esta.
- La constancia de qué está conectado a nivel de ordenador vive en
  `~/.claude/aios/estado-usuario.md`. Lo que sabe la IA gracias a esas conexiones está resumido
  en `Mi-Empresa/DATA/key-metrics.md`.

Si este proyecto necesitara una conexión **propia y exclusiva** (poco habitual), se documenta
aquí con una ficha en `integraciones/`, siguiendo el mismo patrón que en `Mi-Empresa/DATA/` y
**sin** guardar nunca claves ni contraseñas (solo, si acaso, el **nombre** de una variable de
entorno).
