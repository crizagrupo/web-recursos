---
name: propuestas
description: Genera la propuesta interactiva de transformación con IA (HTML autocontenido) que el negocio presenta a SUS clientes, a partir del contexto de descubrimiento. Úsala cuando el usuario pida "generar la propuesta de [cliente]", "hacer la propuesta interactiva", "pasar el descubrimiento a propuesta", o similar. Formato con sidebar de navegación, necesidades detectadas, simulación interactiva, roadmap, impacto esperado con KPIs y presupuesto. Funciona en cualquier proyecto de cliente. Optimizada para mínimo consumo de tokens.
---

# Skill: propuesta de transformación IA

> La identidad visual (nombre de empresa, email, colores y tipografías) se configura
> una vez en `branding.json`, en la raíz de este skill; el logo sale de
> `CONTEXT/branding/logo.<ext>`. Ambos los deja el onboarding de marca (7.º tema). No
> se editan a mano ni se vuelve a preguntar por la marca aquí.

Skill global y reutilizable en **cualquier proyecto de cliente**. El motor (scripts y
guía de KPIs) vive dentro de este skill, en `scripts/`; no depende del proyecto sobre el
que se ejecuta.

Dispara el pipeline `scripts/generar_propuesta.py`. **La IA pesada (elegir los KPIs y
redactar el contenido de cada área) corre dentro del script, con el modelo Sonnet vía
CLI de Claude; el HTML/CSS/JS lo genera `ensamblar_html.py` sin IA.** Tu trabajo aquí es
orquestar con el mínimo gasto posible: reunir parámetros, lanzar el script, entregar el
resultado.

## Reglas de eficiencia (IMPORTANTE)

- **No** leas `scripts/ensamblar_html.py` ni inspecciones el CSS/JS del shell: ya está
  resuelto y validado.
- **No** redactes tú el contenido de la propuesta ni elijas tú los KPIs: de eso se
  encarga el script (que usa `referencia-kpis.md` como guía para la IA que invoca). Tu
  rol es orquestar, no redactar.
- Limítate a: (paso 0, si hace falta) aplicar marca → reunir parámetros → lanzar el
  comando → revisar el resultado → entregar.

## Paso 0 — aplicar marca (una sola vez, idempotente)

Antes de generar la primera propuesta, comprueba que `branding.json` de este skill tiene
los siete campos rellenos (no `{{...}}`, no vacíos), en especial los tres de propuestas:
`color_acento`, `tipografia_titulares` y `tipografia_cuerpo`.

- Si ya están rellenos con valores reales del negocio, **salta este paso**.
- Si aún tienen `{{...}}` o los valores por defecto de fábrica, complétalos leyendo
  `CONTEXT/branding/guia-marca.md` (archivo corto que dejó el onboarding de marca) y
  ejecutando el **único** escritor de branding, `aplicar-branding.py`, con los siete
  valores ya confirmados. Tú (la IA) lees la guía y pasas los valores; el script NO
  parsea markdown.

Mapeo desde `guia-marca.md`:
- `color_acento` ← color de acento de la tabla Color (equivalente a `--accent`). Si el
  negocio solo definió un color de marca, reutiliza el `color_primario`.
- `tipografia_titulares` ← familia de la sección Tipografía → titulares.
- `tipografia_cuerpo` ← familia de la sección Tipografía → cuerpo/UI.

Comando (los cuatro base + los tres extra):

```
py -X utf8 "$HOME/.claude/skills/onboarding-contexto/scripts/aplicar-branding.py" \
  --empresa "<nombre>" --email "<email>" \
  --color-primario "<hex>" --color-tabla "<hex>" \
  --color-acento "<hex>" --tipografia-titulares "<familia>" \
  --tipografia-cuerpo "<familia>"
```

No introduzcas un segundo escritor de JSON ni edites `branding.json` a mano.

## Parámetros que necesitas

1. `--cliente`: nombre del cliente destinatario (p. ej. "Bar Manolo").
2. `--fecha-reunion`: fecha de la reunión de descubrimiento (p. ej. "15/07/2026").
3. `fuentes`: una o más rutas con el contexto del proyecto — típicamente
   `CONTEXT/proyecto.md` y las notas de descubrimiento en `INTELLIGENCE/reuniones/`.
   Cuantas más notas reales (áreas, procesos, volúmenes, ambición de crecimiento), mejor
   sale la elección de KPIs.
4. `--salida` (opcional): ruta del `.html`. Por defecto,
   `INTELLIGENCE/propuestas/YYYY-MM-DD-<nombre>.html`. Solo pásalo si quieres otra ruta.
5. `--modelo` (opcional): `sonnet` (defecto) | `haiku` | `opus`. Sube a `opus` para un
   cliente de más peso donde quieras más cuidado en el razonamiento de KPIs.
6. `--guardar-json` (opcional): guarda también el JSON intermedio, útil para revisar el
   contenido antes de dar la propuesta por buena sin regenerarla entera.

Si falta el contexto de descubrimiento (no hay notas de reunión, o el proyecto no tiene
`CONTEXT/proyecto.md`), **pregunta una vez** de forma agrupada antes de lanzar el script;
no inventes áreas ni cifras del cliente.

## Comando

Ejecútalo **desde la raíz del proyecto del cliente** (así `--salida`, las fuentes y el
logo `CONTEXT/branding/logo.<ext>` se resuelven ahí). El script es global:

```
py -X utf8 "$HOME/.claude/skills/propuestas/scripts/generar_propuesta.py" \
  --cliente "<cliente>" --fecha-reunion "<DD/MM/AAAA>" \
  [--salida "INTELLIGENCE/propuestas/<archivo>.html"] \
  [--modelo sonnet] [--guardar-json] \
  "<fuente1>" "<fuente2>"
```

En PowerShell, usa `$env:USERPROFILE\.claude\skills\propuestas\scripts\generar_propuesta.py`
si `$HOME` no resuelve la ruta del ejecutable nativo.

## Tras ejecutar

- Abre el `.html` generado en un navegador (o sírvelo con un servidor local temporal si
  el entorno bloquea `file://`) y revisa al menos: visión general, una vista de área, la
  simulación interactiva, Impacto esperado y Presupuesto — antes de darlo por entregado.
- Si el JSON que devuelve la IA no cumple el esquema (`validar()` lanza error), reporta la
  causa concreta y relanza; no edites el HTML a mano para parchear un JSON mal formado.
- Si falla el CLI de Claude (no encontrado/sin sesión), repórtalo en una línea con la
  solución; no reintentes a ciegas.
- Entrega la ruta del `.html` (en `INTELLIGENCE/propuestas/`) al usuario y dilo en una frase.

## Notas de mantenimiento

- El shell HTML/CSS/JS (sistema de diseño, navegación, motor de simulación) vive
  **hardcodeado dentro de `ensamblar_html.py`**, no en una plantilla aparte — así se evita
  cualquier desincronización. Los colores de marca (`--navy`, `--navy-deep`, `--accent`) y
  las dos familias tipográficas salen de `branding.json`; el resto de tokens neutros son
  fijos.
- **Logo:** se embebe el de `CONTEXT/branding/logo.<ext>` (mismo archivo para favicon y
  sidebar). El sidebar tiene fondo oscuro (degradado del color primario): el logo idóneo
  es **claro o monocromo**, para que se lea sobre ese fondo. Si no hay logo, la propuesta
  sale igualmente con solo el nombre del negocio, sin imagen (no falla).
- El HTML es **autocontenido**: sin enlaces a CDNs de fuentes ni recursos remotos. Las
  tipografías usan las familias de `branding.json` con fallbacks de sistema (serif para
  titulares, sans-serif para cuerpo), de modo que se lee bien offline y aunque la fuente
  no esté instalada en el equipo que la abre.
- `referencia-kpis.md` es un documento vivo: cuando un cliente nuevo enseñe algo que no
  encajaba en las cuatro lentes, añádelo como caso resuelto anónimo (sin nombres reales).
