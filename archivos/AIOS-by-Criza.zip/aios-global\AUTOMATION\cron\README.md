# cron — Tareas programadas

Tareas que se ejecutan solas a intervalos (daily brief, sync, checks de seguimiento).
Una tarea por archivo `.cron` + su documentación.
