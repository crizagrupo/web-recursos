# db — Base de datos local

Datos del negocio en local (clientes, proyectos, pipeline). Se alimenta desde `../sync/`.
Estado: vacío — se crea al conectar las integraciones.
