---
name: onboarding-contexto
description: Conduce la Fase 1 (Contexto) del onboarding del AIOS. Entrevista al dueño del negocio de forma conversacional (o extrae la información de documentos que aporte) y escribe por él los seis archivos de CONTEXT/ más su guía de marca (identidad visual y tono de voz), personaliza CLAUDE.md, deja listo el branding.json de las skills que lo usan y verifica el resultado. La invoca el comando /onboarding cuando no existe CONTEXT/negocio.md. No hace falta que el usuario sepa programar ni editar archivos.
---

# Skill: onboarding — Fase 1 (Contexto)

Tu trabajo es que la carpeta del negocio (`Mi-Empresa/`, o cualquier carpeta de negocio
que el usuario haya abierto) **conozca su negocio**. En vez de pedirle al usuario que
edite archivos con marcadores `TODO`, tú le entrevistas en lenguaje normal y **escribes
tú** los seis archivos de `CONTEXT/` (más un séptimo tema de identidad de marca) con su
contenido real.

Patrón de referencia: la skill `informe` (entrevista → estructura → archivo). Aquí:
**entrevista conversacional → mapear a los archivos → escribirlos → verificar con el
usuario.**

> El mapeo tema→archivo y qué debe contener cada `.md` de los seis primeros temas está en
> `references/guia-context.md`. El esquema del séptimo tema (la guía de marca) está en
> `references/guia-branding.md`. Léelos antes de escribir los archivos.

## Principios (no los rompas)

- **Conversación, no formulario.** Pregunta pocas cosas cada vez (una o dos), y adáptate
  a lo que ya te ha contado. Nunca vuelques los seis bloques de campos de golpe. (R4)
- **Escribe tú los archivos.** El usuario habla; tú redactas y guardas. Él no toca
  archivos ni marcadores.
- **Nada inventado.** Solo escribes lo que el usuario ha dicho o lo que hayas extraído de
  sus documentos. Si un dato falta, lo preguntas; no lo rellenas a ojo.
- **Sin `TODO`.** Cuando cierras la fase, ningún archivo de `CONTEXT/` puede quedar con
  `TODO` ni placeholders sin resolver. (R8)
- **Tono cercano y no técnico.** El usuario probablemente no es programador.

## Paso 0 — Detectar el estado (siempre primero)

Antes de preguntar nada, mira el disco para no repetir trabajo ya hecho (R11):

1. Lee `harness/progress/onboarding.md` si existe: te dice qué temas están cerrados, cuál
   estaba en curso y notas de respuestas ya dadas.
2. Comprueba cuáles de los 6 archivos de `CONTEXT/` ya existen y tienen contenido real
   (sin `TODO`): `negocio.md`, `servicios-pricing.md`, `equipo.md`,
   `clientes-objetivo.md`, `estrategia.md`, `procesos.md`. Y el séptimo tema:
   `CONTEXT/branding/guia-marca.md`.
3. **Fuente de verdad doble:** un tema está hecho si su archivo existe y está completo,
   y así lo confirma el progreso. Continúa por lo pendiente; saluda reconociendo lo ya
   avanzado ("Ya tenemos definido X e Y; seguimos con Z") en vez de empezar de cero.

Si no hay nada hecho, es un arranque limpio: empieza por el Paso 1.

## Paso 1 — Elegir vía

Explica en una frase qué vas a hacer (definir su negocio para que el AIOS lo conozca) y
ofrece **dos vías** (R6):

- **A) Entrevista.** Le vas preguntando y tú lo escribes. (Por defecto.)
- **B) Importar documentos.** Si ya tiene material —dossier, web, deck de ventas, notas,
  un PDF de la empresa—, que te pase las rutas o los pegue. Léelos con tu lectura nativa
  de archivos, extrae lo que puedas de los 6 temas y **solo pregunta lo que falte**.

Puede combinar las dos: importa lo que tenga y completáis el resto hablando.

## Paso 2 — Entrevistar por temas (conversacional)

Cubre los **siete temas** del negocio (R5). Ve tema a tema, con pocas preguntas cada vez.
Al cerrar cada tema, resume en una línea lo entendido y **escribe su archivo** antes de
pasar al siguiente (así el progreso queda guardado aunque se corte la sesión).

| # | Tema | Archivo que escribes |
|---|------|----------------------|
| 1 | Qué hace el negocio, propuesta de valor, diferencial | `CONTEXT/negocio.md` |
| 2 | Qué vende y a qué precio | `CONTEXT/servicios-pricing.md` |
| 3 | Quién forma el equipo y quién decide | `CONTEXT/equipo.md` |
| 4 | A quién se dirige (cliente objetivo) | `CONTEXT/clientes-objetivo.md` |
| 5 | Objetivos y prioridades actuales | `CONTEXT/estrategia.md` |
| 6 | Cómo entra un cliente y cómo se le entrega (procesos) | `CONTEXT/procesos.md` |
| 7 | Identidad visual y tono de voz | `CONTEXT/branding/guia-marca.md` |

Empieza por el tema 1 (qué hace el negocio y cómo se llama): necesitas el **nombre real**
del negocio pronto porque lo usarás en el Paso 4. El orden puede adaptarse a la
conversación, pero al final los 7 deben quedar cubiertos. Deja el **tema 7 (identidad de
marca) para el final**: se apoya en lo que ya has capturado del negocio (sector, público,
tono) para proponer una dirección si el cliente no la tiene definida. Los seis primeros
temas siguen el detalle de `references/guia-context.md`; el séptimo tiene su propio paso
(ver **"Séptimo tema — Identidad de marca"** más abajo).

Consejo de ritmo: no interrogues. Reacciona a lo que dice, pide ejemplos concretos
("¿a qué precio sueles cerrar eso?", "¿quién decide cuando hay que aprobar un gasto?"),
y evita hacerle repetir algo que ya dijo en otro tema.

## Paso 3 — Escribir los 6 archivos de CONTEXT/

Sigue `references/guia-context.md` para saber qué secciones lleva cada archivo. Reglas:

- Contenido **real** del negocio, redactado por ti a partir de lo que te ha contado. (R7)
- Sustituye el título `{{NOMBRE_NEGOCIO}}` de cada archivo por el nombre real.
- **Cero `TODO`** y cero secciones vacías al cerrar. Si de verdad un dato no aplica,
  escríbelo explícito ("No trabajamos con particulares") en vez de dejarlo en blanco. (R8)
- Un archivo por tema, tal como cierras cada tema (no esperes al final para escribir).

## Séptimo tema — Identidad de marca (branding)

Este es el tema 7 de la entrevista. Además de escribir un archivo, deja lista la identidad
visual para las skills que la usan (`informe` y, si está, `propuestas`). Hazlo al final,
cuando ya conoces el negocio.

### a) Entrevistar (conversacional, pocas preguntas cada vez)
Cubre, sin volcar todo de golpe:
- **Personalidad** de marca: 3-5 adjetivos y qué sensación quiere transmitir.
- **Colores**: color de marca principal y, si tiene, uno secundario/oscuro y un acento
  (pide el hex o descríbelos; si te da una imagen o web, extrae los colores de ahí).
- **Tipografías** de titulares y de cuerpo, si las tiene.
- **Formas** (esquinas, sombras), **imágenes/iconografía** (foto sí/no, estilo de iconos).
- **Tono de voz** y un par de **ejemplos de frase** reales (un titular y una frase de apoyo).
- **Logo**: pídele el archivo (ver **d**).

### b) Nada inventado / dirección propuesta (R7, R8)
Cada color, tipografía, adjetivo o ejemplo sale **de lo que el usuario confirma o de un
documento de marca que aporte**. No inventes valores.

Si el negocio **no tiene identidad definida**, propón una dirección razonable a partir de
`CONTEXT/negocio.md` y del resto del CONTEXT ya capturado (sector, público, tono), preséntala
como propuesta y **pide confirmación explícita** antes de darla por buena. Nunca escribas en
el archivo final un valor sin confirmar: si algo queda pendiente, pregúntalo, no lo dejes a
ojo.

### c) Escribir `CONTEXT/branding/guia-marca.md` (R3, R4, R5)
Crea la carpeta `CONTEXT/branding/` si no existe y escribe `guia-marca.md` siguiendo
**`references/guia-branding.md`**: todas sus secciones (Personalidad, Dirección visual,
tabla de Color con tokens `--bg/--surface/--ink/--muted/--line` + colores de marca,
Tipografía de titulares y cuerpo, Formas y profundidad, Imágenes e iconografía, Tono de voz
con ejemplos, Logo), con el **contenido real del cliente**.

- **Nunca copies los valores de Criza** (navy, Playfair, "premium/minimalista", sus ejemplos
  de frase): `guia-branding.md` es esquema de formato, no de valores (R5).
- Cero `TODO`, cero `{{...}}`, cero secciones vacías. Si algo no aplica, dilo explícito.

### d) Logo (R6)
Pídele el archivo del logo (que te dé la ruta o lo pegue). Detecta su **extensión original**
y guárdalo como `CONTEXT/branding/logo.<ext>` (p. ej. `logo.png`, `logo.svg`), conservando
esa extensión. En la sección **Logo** de `guia-marca.md` referencia esa ruta.

### e) Propagar al `branding.json` — resolver email + ejecutar el script (R9, R11, R12)
Cuando `guia-marca.md` está escrito, deja listo el `branding.json` que consume `informe`
(y `propuestas` si ya está instalada). **No edites el JSON a mano**: lo hace un script
determinista que garantiza JSON válido y hex normalizado.

1. **Resuelve el email de contacto.** Búscalo primero en el CONTEXT ya capturado (p. ej.
   `procesos.md`, `equipo.md`, `negocio.md`). Si **no consta**, pregúntalo en este tema.
   **No lo inventes** (R12).
2. **Elige los dos colores** según el mapeo:
   - `color_primario` = **color de marca principal** de la tabla Color (el de botones y
     acentos fuertes, `--primario`).
   - `color_tabla_cabecera` = **color de marca secundario/oscuro** (`--primario-oscuro` o el
     acento). Si solo hay un color de marca, usa una variante más oscura o el mismo color, y
     confírmalo con el usuario.
3. **Ejecuta el script** con los cuatro valores ya confirmados (nombre real del negocio,
   email, y los dos colores tal cual, con o sin `#` — el script normaliza el hex):

   ```
   py -X utf8 "$HOME/.claude/skills/onboarding-contexto/scripts/aplicar-branding.py" \
     --empresa "<nombre real>" --email "<email contacto>" \
     --color-primario "<hex>" --color-tabla "<hex>"
   ```

   El script actualiza `~/.claude/skills/informe/branding.json` (siempre) y
   `~/.claude/skills/propuestas/branding.json` **solo si ya existe** (R10), dejando
   `empresa`, `email`, `color_primario` y `color_tabla_cabecera` sin `{{...}}` ni vacíos y
   con los colores en hex sin `#` (R11). Conserva el resto del archivo (`_comment`).
   Si el script devuelve un error (color no válido, valor vacío o con `{{...}}`), corrige el
   valor con el usuario y vuelve a ejecutarlo; no continúes con un JSON a medias.

> **Nota para el módulo 25 (`aios2-propuestas`):** la skill `propuestas` **no** vuelve a
> entrevistar sobre branding. Reutiliza este `guia-marca.md` + `logo.<ext>` y el
> `branding.json` que deja listo `aplicar-branding.py` (que actualiza el JSON de
> `propuestas` en cuanto exista). Si necesita más campos, se amplían en `aplicar-branding.py`,
> no reintroduciendo preguntas de marca.

## Paso 4 — Personalizar la identidad (CLAUDE.md)

En cuanto tengas el nombre real del negocio, abre `CLAUDE.md` de la carpeta y **sustituye
el marcador `{{NOMBRE_NEGOCIO}}`** por ese nombre en todas sus apariciones. (R9) Después
de hacerlo, `CLAUDE.md` no debe conservar ningún `{{NOMBRE_NEGOCIO}}`.

## Paso 5 — Guardar el progreso (reanudable)

Mantén al día `harness/progress/onboarding.md` (créalo si no existe). Guárdalo **al cerrar
cada tema**, no solo al final, para que una interrupción no pierda trabajo (R10). Formato:

```markdown
# Onboarding — Fase 1 (Contexto)

- Fase: 1 (Contexto)
- Estado: en curso | completa
- Negocio: <nombre real del negocio>
- Actualizado: <fecha>

## Temas
- [x] 1 · negocio (negocio.md)
- [x] 2 · servicios-pricing (servicios-pricing.md)
- [x] 3 · equipo (equipo.md)
- [ ] 4 · clientes-objetivo (clientes-objetivo.md)  ← siguiente
- [ ] 5 · estrategia (estrategia.md)
- [ ] 6 · procesos (procesos.md)
- [ ] 7 · branding (branding/guia-marca.md)

## Notas de respuestas
- <apuntes útiles ya dados por el usuario que aún no hayan ido a un archivo>
```

Al reejecutar `/onboarding`, este archivo + la existencia de los `.md` te dicen por dónde
seguir sin volver a preguntar lo respondido. (R11)

## Paso 6 — Verificar con el usuario (cierre)

Cuando los 7 temas estén escritos (los 6 archivos de `CONTEXT/`, `guia-marca.md` y su
`branding.json` propagado) y `CLAUDE.md` personalizado:

1. Responde a **"¿quién soy y cómo trabajas?"** usando el `CONTEXT/` recién creado: un
   resumen breve del negocio (qué hace, a quién, qué vende, equipo, prioridades) leído de
   los archivos, no de memoria. (R12) **Incluye, antes de pedir confirmación, un resumen de
   la identidad de marca** leído de `CONTEXT/branding/guia-marca.md`: personalidad
   (adjetivos), colores de marca, tipografías y tono de voz. (R14)
2. **Pide confirmación**: "¿Describe bien tu negocio y tu marca? ¿Corrijo algo?". No des la
   fase por cerrada sin su visto bueno. (R13)
3. Si señala un error, **corrige el o los archivos de `CONTEXT/` afectados** (incluido
   `branding/guia-marca.md`) y vuelve a mostrar el resumen corregido y a pedir confirmación.
   Si la corrección cambia el nombre, el email o algún color de marca, **vuelve a ejecutar
   `aplicar-branding.py`** para que el `branding.json` quede al día. Repite hasta que
   confirme. (R14)
4. Marca en `harness/progress/onboarding.md` la Fase 1 como `completa`.

## Paso 7 — Siguiente paso

Cuando el usuario confirma que la Fase 1 es correcta, **sugiere ejecutar `/task-audit`**
como siguiente paso (mapear sus tareas para ver qué se puede automatizar). No lo ejecutes
tú: solo propónselo en una frase. (R15)

## Qué NO hacer

- No presentes un formulario con los 7 bloques de campos a la vez.
- No dejes `TODO` ni marcadores sin resolver al cerrar.
- No inventes cifras, precios, nombres, colores, tipografías ni el email: pregúntalos.
- No copies los valores de marca de Criza en `guia-marca.md`: `guia-branding.md` es esquema
  de formato, no de valores.
- No edites `branding.json` a mano: para eso está `aplicar-branding.py`.
- No arranques las Fases 2 o 3 (no implementadas en esta versión).
- No toques archivos fuera de la carpeta del negocio actual.
