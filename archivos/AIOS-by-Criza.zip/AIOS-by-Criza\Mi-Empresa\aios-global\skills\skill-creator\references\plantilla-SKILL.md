---
name: {{NAME}}
description: {{DESCRIPTION}}
---

# Skill: {{NAME}}

> Andamiada por `skill-creator`. Rellena las secciones marcadas con `<...>` con el
> contenido real de esta skill y borra estas notas. Al terminar, pásala por
> `quick_validate.py`: la skill no está lista hasta que la validación da OK.

## Qué hace

<En una o dos frases: qué capacidad empaqueta esta skill.>

## Cuándo se usa

<Los disparadores que la activan: qué comando, situación o frase debe hacer que Claude Code
la lance. Debe ser coherente con lo que promete el campo `description` del frontmatter.>

## Protocolo

1. <Primer paso concreto que sigue la IA al ejecutar la skill.>
2. <Segundo paso.>
3. <...>

## Qué NO hacer

- <Límite o error común que la skill debe evitar.>
