# Pipeline status

Foto actualizada del pipeline comercial. Se alimenta desde DATA/integraciones (CRM).
