# -*- coding: utf-8 -*-
"""
aplicar-branding.py — propaga la identidad de marca del negocio al branding.json
de las skills que lo consumen (informe hoy, propuestas cuando exista).

Determinista, SIN IA. La skill onboarding-contexto le pasa los cuatro valores ya
confirmados con el usuario (los acaba de capturar en la entrevista del séptimo tema).
El script NO parsea guia-marca.md: solo escribe JSON válido y normaliza el hex.

Qué hace:
  - Normaliza los colores a hex sin '#', en mayúsculas.
  - Reescribe branding.json de la skill `informe` (siempre) actualizando los
    CUATRO campos base: empresa, email, color_primario y color_tabla_cabecera;
    conserva el resto (p. ej. el comentario `_comment`).
  - Hace lo mismo con la skill `propuestas` SOLO si su branding.json ya existe (R10),
    y además escribe ahí los TRES campos extra de propuestas cuando se pasan:
    color_acento, tipografia_titulares y tipografia_cuerpo (nunca en `informe`).
  - No deja nunca marcadores {{...}} ni valores vacíos: si algún argumento
    llega vacío o con {{...}}, aborta con error antes de escribir nada.

Los tres argumentos extra son OPCIONALES: la invocación de cuatro campos (la del
módulo 23) sigue funcionando igual y, cuando no se pasan los extra, `propuestas`
conserva los valores que ya tuviera en esos campos.

Uso (cuatro campos base, retrocompatible):
  py -X utf8 aplicar-branding.py \
     --empresa "Panadería La Espiga" --email "hola@laespiga.es" \
     --color-primario "#7A4A24" --color-tabla "5C3719"

Uso (con los tres campos extra de propuestas):
  py -X utf8 aplicar-branding.py \
     --empresa "Panadería La Espiga" --email "hola@laespiga.es" \
     --color-primario "#7A4A24" --color-tabla "5C3719" \
     --color-acento "C97A3A" --tipografia-titulares "Georgia" \
     --tipografia-cuerpo "Segoe UI"
"""
import argparse
import json
import os
import re
import sys


def normalizar_hex(valor, etiqueta):
    """Quita '#', valida que sea un hex de 3 o 6 dígitos y lo devuelve en mayúsculas."""
    if valor is None:
        raise ValueError("Falta el color %s." % etiqueta)
    v = valor.strip().lstrip("#").strip()
    if not re.fullmatch(r"[0-9A-Fa-f]{6}|[0-9A-Fa-f]{3}", v):
        raise ValueError(
            "El color %s ('%s') no es un hex valido de 3 o 6 digitos." % (etiqueta, valor)
        )
    return v.upper()


def validar_texto(valor, etiqueta):
    """Rechaza vacios y marcadores {{...}} (R11)."""
    if valor is None:
        raise ValueError("Falta %s." % etiqueta)
    v = valor.strip()
    if not v:
        raise ValueError("%s no puede estar vacio." % etiqueta)
    if "{{" in v or "}}" in v:
        raise ValueError("%s aun tiene un marcador {{...}}: se esperaba el valor real." % etiqueta)
    return v


def destino(skill):
    home = os.environ.get("HOME") or os.path.expanduser("~")
    return os.path.join(home, ".claude", "skills", skill, "branding.json")


def escribir(ruta, campos):
    """Reescribe branding.json conservando el resto de claves (p. ej. _comment)."""
    datos = {}
    if os.path.exists(ruta):
        try:
            with open(ruta, "r", encoding="utf-8") as f:
                datos = json.load(f)
        except (ValueError, OSError):
            datos = {}
    if not isinstance(datos, dict):
        datos = {}
    datos.update(campos)
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=2)
        f.write("\n")


def main():
    p = argparse.ArgumentParser(description="Propaga la marca al branding.json de las skills.")
    p.add_argument("--empresa", required=True)
    p.add_argument("--email", required=True)
    p.add_argument("--color-primario", required=True, dest="color_primario")
    p.add_argument("--color-tabla", required=True, dest="color_tabla")
    # Campos extra SOLO de propuestas (opcionales; retrocompatibles).
    p.add_argument("--color-acento", default=None, dest="color_acento")
    p.add_argument("--tipografia-titulares", default=None, dest="tipografia_titulares")
    p.add_argument("--tipografia-cuerpo", default=None, dest="tipografia_cuerpo")
    args = p.parse_args()

    try:
        # Cuatro campos base: van a informe y a propuestas.
        campos = {
            "empresa": validar_texto(args.empresa, "empresa"),
            "email": validar_texto(args.email, "email"),
            "color_primario": normalizar_hex(args.color_primario, "color_primario"),
            "color_tabla_cabecera": normalizar_hex(args.color_tabla, "color_tabla_cabecera"),
        }
        # Tres campos extra: SOLO propuestas, y solo los que se pasen.
        extra = {}
        if args.color_acento is not None:
            extra["color_acento"] = normalizar_hex(args.color_acento, "color_acento")
        if args.tipografia_titulares is not None:
            extra["tipografia_titulares"] = validar_texto(args.tipografia_titulares, "tipografia_titulares")
        if args.tipografia_cuerpo is not None:
            extra["tipografia_cuerpo"] = validar_texto(args.tipografia_cuerpo, "tipografia_cuerpo")
    except ValueError as e:
        print("ERROR: %s" % e, file=sys.stderr)
        return 2

    # informe: siempre. Se crea si no existe. Nunca recibe los campos extra.
    ruta_informe = destino("informe")
    escribir(ruta_informe, campos)
    print("OK  informe   -> %s" % ruta_informe)

    # propuestas: solo si ya existe (R10). No se crea. Recibe base + extra.
    ruta_propuestas = destino("propuestas")
    if os.path.exists(ruta_propuestas):
        campos_propuestas = dict(campos)
        campos_propuestas.update(extra)
        escribir(ruta_propuestas, campos_propuestas)
        print("OK  propuestas-> %s" % ruta_propuestas)
    else:
        print("--  propuestas no instalada: no se toca (%s)" % ruta_propuestas)

    return 0


if __name__ == "__main__":
    sys.exit(main())
