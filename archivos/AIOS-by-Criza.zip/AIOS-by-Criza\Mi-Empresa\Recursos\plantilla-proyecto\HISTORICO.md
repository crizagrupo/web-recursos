# HISTÓRICO — Proyecto: {{NOMBRE_PROYECTO}}

> Registro cronológico de hitos y decisiones de este proyecto (más reciente primero).
> El AIOS añade entradas aquí solo (por ejemplo, al crear el proyecto o cada vez que usas
> `/commit`). No hace falta editarlo a mano.

---

<!-- Las entradas se añaden encima de esta línea, la más reciente primero. -->
