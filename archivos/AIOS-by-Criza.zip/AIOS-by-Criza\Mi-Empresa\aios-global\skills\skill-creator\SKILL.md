---
name: skill-creator
description: Ayuda a crear una skill nueva bien formada para el AIOS. Cuando, trabajando con el harness, hace falta empaquetar una capacidad reutilizable como skill, esta meta-skill guia el proceso: recoge la intencion (name en kebab-case + description con sus disparadores), decide el alcance (transversal a nivel de usuario o especifica de un proyecto), decide la estructura (con scripts/ y/o references/ solo si hacen falta), andamia la carpeta y el SKILL.md con scripts/init_skill.py, y valida el resultado con scripts/quick_validate.py. Usala siempre que haya que crear una skill nueva, en vez de improvisar la estructura a mano.
---

# Skill: skill-creator (crear skills nuevas bien formadas)

Tu trabajo es **crear una skill nueva bien formada** cuando, construyendo algo con el
harness de este negocio, hace falta empaquetar una capacidad como skill reutilizable. No
resuelves una tarea de negocio: produces la **estructura correcta** (carpeta en
`kebab-case` + `SKILL.md` con frontmatter valido, y `scripts/` / `references/` solo si
hacen falta) y **validas** el resultado antes de darlo por bueno.

> **Regla base: no inventes formato.** Se usa exactamente el mismo esquema que ya usan las
> skills de este proyecto (`informe`, `automatizar`, `onboarding-contexto`, `task-audit`,
> `mcp-integration`). Las reglas de formato estan en `references/formato-skill.md`; la
> plantilla que se rellena, en `references/plantilla-SKILL.md`. **Lee `formato-skill.md`
> antes de andamiar y de redactar.**

## Qué hace

Guia la creacion de una skill nueva de principio a fin: intencion → alcance → estructura →
andamiaje → cuerpo → validacion. Deja una carpeta `<nombre>/` con un `SKILL.md` valido y,
si procede, subcarpetas `scripts/` (codigo determinista) y/o `references/` (consulta bajo
demanda).

## Cuándo se usa

Siempre que, trabajando con el harness, haya que **empaquetar una capacidad nueva como
skill** reutilizable (por ejemplo, al construir una automatizacion o herramienta para el
negocio o para un proyecto y querer que quede como skill invocable). En vez de crear la
carpeta y el `SKILL.md` a mano y arriesgarte a un formato que Claude Code no reconozca,
sigue esta skill.

## Protocolo

### Paso 1 — Recoger la intención (R3, R6)
Averigua y fija tres cosas antes de crear nada:

1. **Qué capacidad** se quiere empaquetar (en una o dos frases).
2. **`name`** en `kebab-case` (minusculas, guiones; `a-z`, `0-9`, `-`). Sera tambien el
   nombre de la carpeta.
3. **`description`** que diga **qué hace** y **cuándo se activa** (los disparadores: qué
   comando o situacion la lanza). Sin disparador, Claude Code no sabra cuando usarla.
   Sigue el patron de `references/formato-skill.md` (§2).

Si algo de esto no esta claro, pregúntalo; no lo rellenes a ojo.

### Paso 2 — Decidir el alcance (R8)
Aplica la regla de ubicacion del negocio ("¿lo usaria igual en otro cliente? → global;
¿depende de este cliente? → proyecto"):

- **Transversal** (sirve en varios proyectos/clientes) → nivel de usuario:
  `~/.claude/skills/<nombre>/`. Es el **valor por defecto** (`--scope user`).
- **Especifica de un proyecto/cliente** (depende de sus datos o reglas) →
  `.claude/skills/<nombre>/` de la carpeta actual (`--scope project`).

### Paso 3 — Decidir la estructura (R7)
Decide qué subcarpetas necesita la skill **antes** de andamiar:

- ¿Ejecuta **código determinista** (parsear, validar, transformar, llamar a algo)? → habra
  `scripts/` (`--with-scripts`).
- ¿Necesita **material de consulta cargable bajo demanda** (guias, plantillas, catalogos)?
  → habra `references/` (`--with-references`).
- Si no necesita ninguna, solo `SKILL.md`. **No crees subcarpetas vacias.**

### Paso 4 — Andamiar con `scripts/init_skill.py` (R3, R4, R7, R8)
Ejecuta el script de andamiaje, que crea la carpeta y escribe `SKILL.md` desde la plantilla
rellenando `name` y `description`, y crea `scripts/`/`references/` solo si se piden:

```
py scripts/init_skill.py --name <nombre> --description "<que hace y cuando>" \
    [--scope user|project] [--with-scripts] [--with-references]
```

(En Mac, usa `python3` en vez de `py`.) Comprueba en la salida la ruta creada.

### Paso 5 — Redactar el cuerpo del `SKILL.md` (R4, R5, R6)
Abre el `SKILL.md` recien creado y sustituye los `<...>` de la plantilla por el contenido
real, respetando `references/formato-skill.md`: secciones **"Qué hace" / "Cuándo se usa" /
"Protocolo"** como minimo (y, recomendado, **"Qué NO hacer"**). No toques el esquema del
frontmatter ni anadas campos que Claude Code no reconozca. Si la skill lleva `scripts/` o
`references/`, anade ahi su contenido real (no las dejes con solo el `.gitkeep`).

### Paso 6 — Validar (paso final obligatorio) (R9, R10, R11)
Pasa la carpeta de la skill nueva por la validacion basica:

```
py scripts/quick_validate.py <ruta-de-la-carpeta-de-la-skill-nueva>
```

- Si imprime **`OK`** y sale con codigo 0 → la skill esta bien formada; **puedes darla por
  terminada**.
- Si **falla**, imprime exactamente qué no cumple (falta un campo, frontmatter roto, `name`
  no kebab-case o que no coincide con la carpeta, o excede un limite). **Corrige justo eso
  y vuelve a validar.** No des la skill por terminada hasta que la validacion pase sin
  errores.

## Qué NO hacer

- No improvises la estructura ni el frontmatter a mano: usa `init_skill.py` y
  `references/formato-skill.md`.
- No inventes un formato nuevo ni anadas campos (`version`, `tags`, `autor`…) que Claude
  Code no reconoce. Solo `name` y `description`.
- No crees `scripts/` o `references/` vacias cuando la skill no las necesita.
- No pongas el `name` en algo que no sea `kebab-case` ni distinto del nombre de la carpeta.
- No des la skill por terminada si `quick_validate.py` no ha pasado en verde.
