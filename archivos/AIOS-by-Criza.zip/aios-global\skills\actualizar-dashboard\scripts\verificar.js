#!/usr/bin/env node
// ============================================================================
// verificar.js — paso FINAL de /actualizar-dashboard (determinista, sin IA)
// ----------------------------------------------------------------------------
// Tras editar datos.js comprueba que:
//   - sigue siendo JS válido y define window.DATOS,
//   - no se ha perdido ninguna sección respecto a la "foto antes",
//   - la fecha "actualizado" se ha refrescado y tiene formato AAAA-MM-DD,
//   - los campos de fecha conocidos respetan AAAA-MM-DD.
// Sale con código 1 solo si hay un fallo duro (JS inválido / falta datos.js).
// Los avisos (posible pérdida, fecha sin cambiar) se imprimen como WARN.
// ============================================================================
const fs = require('fs');
const { findDatos, loadDatos, snapshot, snapshotPath } = require('./lib');

const DATE_KEYS = new Set(['actualizado', 'inicio', 'fin', 'fecha', 'entrega']);
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

// Recorre el objeto buscando claves de fecha con valor mal formado.
function badDates(obj, prefix, out) {
  out = out || [];
  if (Array.isArray(obj)) {
    obj.forEach((v, i) => badDates(v, `${prefix}[${i}]`, out));
  } else if (obj && typeof obj === 'object') {
    for (const k of Object.keys(obj)) {
      const p = prefix ? prefix + '.' + k : k;
      const v = obj[k];
      if (DATE_KEYS.has(k) && typeof v === 'string' && v && !DATE_RE.test(v)) {
        out.push(`${p} = "${v}"`);
      }
      badDates(v, p, out);
    }
  }
  return out;
}

function main() {
  const warns = [];

  const datosPath = findDatos();
  if (!datosPath) {
    console.error('FAIL: no encuentro BUILD/dashboard/datos.js.');
    process.exit(1);
  }

  let datos;
  try {
    datos = loadDatos(datosPath);
  } catch (e) {
    console.error('FAIL: datos.js no es válido tras editar: ' + e.message);
    console.error('Restaura la copia de .backups/ y revisa la edición.');
    process.exit(1);
  }

  const after = snapshot(datos);

  // Comparación con la foto antes
  const snapFile = snapshotPath(datosPath);
  if (fs.existsSync(snapFile)) {
    const before = JSON.parse(fs.readFileSync(snapFile, 'utf8'));
    for (const k of Object.keys(before.counts)) {
      const a = after.counts[k];
      const b = before.counts[k];
      if (a === undefined) {
        warns.push(`sección "${k}" desapareció (tenía ${b} elementos)`);
      } else if (a < b) {
        warns.push(`sección "${k}" pasó de ${b} a ${a} elementos (¿pérdida?)`);
      }
    }
    if (after.actualizado && before.actualizado && after.actualizado === before.actualizado) {
      warns.push(`la fecha "actualizado" sigue en ${after.actualizado} (¿olvidaste refrescarla?)`);
    }
  } else {
    warns.push('no hay foto previa (_snapshot-antes.json): ejecuta preparar.js antes de editar.');
  }

  // Formato de la fecha principal
  if (!after.actualizado || !DATE_RE.test(after.actualizado)) {
    warns.push(`"actualizado" no tiene formato AAAA-MM-DD: ${after.actualizado}`);
  }

  // Fechas mal formadas en cualquier sección
  for (const bad of badDates(datos, '', [])) {
    warns.push('fecha mal formada → ' + bad);
  }

  // Resultado
  console.log('Dashboard:   ' + datosPath);
  console.log('actualizado: ' + (after.actualizado || '(sin fecha)'));
  if (warns.length === 0) {
    console.log('\nPASS — datos.js válido, sin pérdidas y fecha refrescada.');
  } else {
    console.log('\nWARN — revisa estos puntos:');
    for (const w of warns) console.log('  - ' + w);
  }
}

main();
