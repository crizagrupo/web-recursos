#!/usr/bin/env node
// ============================================================================
// negocio-preparar.js — paso PREVIO de /dashboard a NIVEL NEGOCIO (sin IA)
// ----------------------------------------------------------------------------
// 1) Localiza Mi-Empresa/ y su hermana Proyectos/ (misma lógica que
//    /crear-proyecto Paso 3).
// 2) Si Mi-Empresa/BUILD/dashboard-negocio/ no existe, la MATERIALIZA copiando
//    los 4 archivos del asset y sustituyendo {{NOMBRE_NEGOCIO}} → cero {{...}}.
// 3) Lista los proyectos (Proyectos/<cliente>/) con la ruta y el texto de su
//    ESTADO.md, para que la IA los mapee a proyectos[]. No falla si Proyectos/
//    no existe o está vacía (lista vacía → dashboard con proyectos: []).
// 4) Hace copia de seguridad del datos.js de negocio anterior (si lo hay) y
//    guarda una "foto antes" (recuento de proyectos) para negocio-verificar.js.
// ============================================================================
const fs = require('fs');
const path = require('path');
const {
  findMiEmpresa, findProyectosDir, findDatosNegocio, listarProyectos,
  loadDatos, backupsDir,
} = require('./lib');

const ASSET_DIR = path.join(__dirname, '..', 'assets', 'dashboard-negocio');
const ARCHIVOS = ['index.html', 'datos.js', 'servir.js', 'LEEME.md'];

function stamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

function primerTitulo(texto) {
  const m = texto.match(/^#\s+(.+)$/m);
  return m ? m[1].trim() : '';
}

// Resuelve el nombre real del negocio para sustituir {{NOMBRE_NEGOCIO}}:
// 1) título de CONTEXT/negocio.md, 2) título de CLAUDE.md (quitando "AIOS — ").
// Devuelve null si sigue conteniendo un marcador o queda vacío.
function resolverNombreNegocio(miEmpresa) {
  const negocioMd = path.join(miEmpresa, 'CONTEXT', 'negocio.md');
  if (fs.existsSync(negocioMd)) {
    const t = primerTitulo(fs.readFileSync(negocioMd, 'utf8'));
    if (t && !/\{\{.*\}\}/.test(t)) return t;
  }
  const claude = path.join(miEmpresa, 'CLAUDE.md');
  if (fs.existsSync(claude)) {
    let t = primerTitulo(fs.readFileSync(claude, 'utf8'));
    t = t.replace(/^AIOS\s*[—-]\s*/i, '').trim();
    if (t && !/\{\{.*\}\}/.test(t)) return t;
  }
  return null;
}

function materializar(miEmpresa, nombreNegocio) {
  const destino = path.join(miEmpresa, 'BUILD', 'dashboard-negocio');
  fs.mkdirSync(destino, { recursive: true });
  for (const nombre of ARCHIVOS) {
    const src = path.join(ASSET_DIR, nombre);
    let contenido = fs.readFileSync(src, 'utf8');
    contenido = contenido.split('{{NOMBRE_NEGOCIO}}').join(nombreNegocio);
    fs.writeFileSync(path.join(destino, nombre), contenido, 'utf8');
  }
  return destino;
}

function main() {
  const miEmpresa = findMiEmpresa();
  if (!miEmpresa) {
    console.error('ERROR: no encuentro la carpeta Mi-Empresa/ desde aquí.');
    console.error('Ejecuta /dashboard a nivel negocio (dentro de Mi-Empresa/).');
    process.exit(1);
  }

  const nombreNegocio = resolverNombreNegocio(miEmpresa);
  if (!nombreNegocio) {
    console.error('ERROR: no puedo resolver el nombre del negocio (no hay CONTEXT/negocio.md');
    console.error('ni un CLAUDE.md con título resuelto). Completa antes /onboarding en Mi-Empresa/.');
    process.exit(1);
  }

  const datosPath = findDatosNegocio(miEmpresa);
  const carpetaDash = path.dirname(datosPath);
  const existiaDash = fs.existsSync(carpetaDash);

  // Foto antes: recuento de proyectos del datos.js anterior (si lo había).
  let proyectosAntes = null;
  if (fs.existsSync(datosPath)) {
    try {
      const prev = loadDatos(datosPath);
      proyectosAntes = Array.isArray(prev.proyectos) ? prev.proyectos.length : 0;
      // Copia de seguridad del datos.js anterior.
      const bdir = backupsDir(datosPath);
      fs.mkdirSync(bdir, { recursive: true });
      fs.copyFileSync(datosPath, path.join(bdir, `datos-${stamp()}.js`));
    } catch (e) {
      console.error('AVISO: el datos.js de negocio anterior no era válido: ' + e.message);
    }
  }

  // Materializar el dashboard si aún no existe.
  if (!existiaDash) {
    materializar(miEmpresa, nombreNegocio);
    console.log('Materializado: ' + carpetaDash + '  (motor copiado del asset)');
  } else {
    console.log('Dashboard de negocio ya existe: ' + carpetaDash);
  }

  // Localizar Proyectos/ y listar.
  const proyectosDir = findProyectosDir(miEmpresa);
  const hayProyectosDir = proyectosDir && fs.existsSync(proyectosDir);
  const proyectos = hayProyectosDir ? listarProyectos(proyectosDir) : [];

  // Guardar foto antes para negocio-verificar.js.
  const bdir = backupsDir(datosPath);
  fs.mkdirSync(bdir, { recursive: true });
  const snap = {
    proyectosAntes: proyectosAntes,          // null si es la primera vez
    proyectosEnDisco: proyectos.length,      // los detectados ahora
  };
  fs.writeFileSync(path.join(bdir, '_snapshot-negocio-antes.json'), JSON.stringify(snap, null, 2), 'utf8');

  // Resumen para la IA.
  console.log('Negocio:     ' + nombreNegocio);
  console.log('datos.js:    ' + datosPath);
  if (!hayProyectosDir) {
    console.log('Proyectos/:  (no existe todavía) → cartera vacía, proyectos: []');
  } else if (proyectos.length === 0) {
    console.log('Proyectos/:  ' + proyectosDir + '  (sin proyectos) → proyectos: []');
  } else {
    console.log('Proyectos/:  ' + proyectosDir);
    console.log('Proyectos detectados (' + proyectos.length + '):');
    for (const p of proyectos) {
      console.log('  - ' + p.id + '  «' + p.nombre + '»  ' + (p.estadoPath ? 'ESTADO.md ✓' : 'sin ESTADO.md'));
    }
  }
  console.log('\nSiguiente: la IA mapea cada ESTADO.md a proyectos[] y reescribe datos.js;');
  console.log('luego: node scripts/negocio-verificar.js');
}

main();
