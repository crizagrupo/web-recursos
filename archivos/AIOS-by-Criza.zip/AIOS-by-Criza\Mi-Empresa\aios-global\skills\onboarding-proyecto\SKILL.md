---
name: onboarding-proyecto
description: Conduce la Fase 1 (Contexto de proyecto) del onboarding del AIOS dentro de una carpeta de proyecto (Proyectos/<cliente>/, con marcador .aios-proyecto). Lee el negocio ya definido en Mi-Empresa/CONTEXT/ para NO repetir preguntas de empresa, entrevista al usuario de forma corta y específica sobre este cliente/iniciativa (o extrae la información de un archivo que aporte) y escribe por él CONTEXT/proyecto.md con contenido real. NO configura Infraestructura (Git/GitHub) ni Datos: esas ya están resueltas a nivel de usuario y el proyecto las hereda. La invoca el comando /onboarding cuando detecta el marcador .aios-proyecto y CONTEXT/proyecto.md no está completo. No hace falta que el usuario sepa programar.
---

# Skill: onboarding — Fase 1 de proyecto (Contexto de proyecto)

Tu trabajo es que **esta carpeta de proyecto** (`Proyectos/<cliente>/`) **conozca al cliente o
iniciativa** que representa. A diferencia de la Fase 1 de empresa (que define todo el negocio),
aquí la entrevista es **corta y específica**: solo lo propio de este proyecto. Lo que ya define
el negocio (`Mi-Empresa/CONTEXT/`) **se hereda y no se vuelve a preguntar**.

En vez de pedirle al usuario que edite archivos con marcadores, tú le entrevistas en lenguaje
normal (o lees un archivo que te pase) y **escribes tú** `CONTEXT/proyecto.md` con su contenido
real.

> Qué preguntar (solo lo del cliente) y qué secciones lleva `proyecto.md` está en
> `references/guia-contexto-proyecto.md`. Léelo antes de escribir el archivo.

## Principios (no los rompas)

- **Solo lo del proyecto.** No repitas nada que ya describa `Mi-Empresa/CONTEXT/` (qué hace el
  negocio, su equipo, sus precios generales…). Eso se hereda. (R14)
- **Conversación, no formulario.** Pregunta pocas cosas cada vez (una o dos) y adáptate a lo que
  ya te ha contado. Es una entrevista **breve**.
- **Escribe tú el archivo.** El usuario habla; tú redactas y guardas `CONTEXT/proyecto.md`.
- **Nada inventado.** Solo escribes lo que el usuario ha dicho o lo extraído de su archivo. Si
  un dato falta, lo preguntas; no lo rellenas a ojo.
- **Sin `TODO`.** Al cerrar, `CONTEXT/proyecto.md` no puede quedar con `TODO` ni placeholders
  sin resolver. (R16)
- **No toques Infraestructura ni Datos.** No configures Git/GitHub ni conexiones MCP: ya están
  resueltas a nivel de usuario y este proyecto las hereda. Si no constaran resueltas, es cosa de
  `/onboarding` en `Mi-Empresa/`, no tuya.
- **Tono cercano y no técnico.** El usuario probablemente no es programador.

## Paso 0 — Detectar el estado (siempre primero) (R20)

Antes de preguntar nada, mira el disco para no repetir trabajo ya hecho:

1. Lee `harness/progress/onboarding.md` si existe: te dice qué apartados de la Fase 1 de
   proyecto están cerrados, cuál estaba en curso y notas de respuestas ya dadas.
2. Comprueba si `CONTEXT/proyecto.md` ya existe y tiene contenido real (sin `TODO`).
3. **Fuente de verdad doble:** un apartado está hecho si su contenido está en `proyecto.md` y
   así lo confirma el progreso. Continúa por lo pendiente; saluda reconociendo lo ya avanzado
   ("Ya tenemos el alcance y los objetivos; nos falta quién decide") en vez de empezar de cero.

Si no hay nada hecho, es un arranque limpio: sigue por el Paso 1.

## Paso 1 — Leer el negocio heredado (para NO repetir) (R14)

Localiza y **lee** el contexto del negocio en `Mi-Empresa/CONTEXT/` (carpeta hermana; desde el
proyecto suele ser `../../Mi-Empresa/CONTEXT/`). Úsalo como base:

- Ya sabes qué hace el negocio, su equipo, sus servicios y su forma de trabajar: **no lo
  preguntes otra vez**.
- Aprovéchalo para hacer preguntas más útiles ("Para {{NOMBRE_NEGOCIO}}, ¿qué te encarga este
  cliente en concreto?") y para situar el proyecto respecto al negocio.

Si no encuentras `Mi-Empresa/CONTEXT/`, sigue igualmente con la entrevista de proyecto, pero
avísalo en una frase (quizá el negocio aún no completó su Fase 1).

## Paso 2 — Elegir vía (R15)

Explica en una frase qué vas a hacer (definir este proyecto para que el AIOS lo conozca) y
ofrece **dos vías**, igual que la Fase 1 de empresa:

- **A) Entrevista.** Le haces unas pocas preguntas y tú lo escribes. (Por defecto.)
- **B) Importar un archivo.** Si ya tiene material del proyecto —un dossier del cliente, una
  propuesta, un contrato, notas de una reunión, un brief—, que te pase la ruta o lo pegue.
  Léelo con tu lectura nativa de archivos, extrae lo que puedas y **solo pregunta lo que falte**.

Puede combinar las dos: importa lo que tenga y completáis el resto hablando.

## Paso 3 — Entrevista corta y específica del proyecto (R14)

Cubre **solo lo propio de este cliente/proyecto**, siguiendo
`references/guia-contexto-proyecto.md`. Ve por temas, con pocas preguntas cada vez, y no hagas
repetir lo del negocio. Los temas (breves) son:

| # | Tema | Qué capturar |
|---|------|--------------|
| 1 | Qué es este proyecto | Cliente/iniciativa y en una frase de qué va. |
| 2 | Alcance | Qué entra y qué NO entra en este proyecto. |
| 3 | Objetivos | Qué se quiere conseguir; cómo se medirá el éxito. |
| 4 | Interlocutores | Con quién se habla en el cliente y quién decide (por su lado y por el nuestro). |
| 5 | Particularidades | Plazos, condiciones, restricciones, tono, cualquier cosa singular. |

Empieza por el tema 1 (qué es y cómo se llama el cliente/proyecto): necesitas el **nombre
reconocible** pronto (encabezará `proyecto.md`). Reacciona a lo que dice, pide ejemplos
concretos y evita interrogar.

## Paso 4 — Escribir CONTEXT/proyecto.md (R16)

Sigue `references/guia-contexto-proyecto.md` para las secciones. Reglas:

- Contenido **real** del proyecto, redactado por ti a partir de lo que te ha contado (o del
  archivo que importó).
- Encabeza con el nombre reconocible del proyecto y menciona a qué negocio pertenece.
- **Cero `TODO`** y cero secciones vacías al cerrar. Si un dato de verdad no aplica, escríbelo
  explícito ("Sin plazo de cierre definido aún") en vez de dejarlo en blanco. (R16)
- Escribe el archivo a medida que cierras temas (no esperes al final): así el progreso queda
  guardado aunque se corte la sesión.

## Paso 5 — Guardar el progreso (reanudable) (R20)

Mantén al día `harness/progress/onboarding.md` (créalo si no existe). Guárdalo **al cerrar cada
tema**, no solo al final, para que una interrupción no pierda trabajo. Formato:

```markdown
# Onboarding — Fase 1 de proyecto (Contexto de proyecto)

- Fase: 1 de proyecto (Contexto)
- Estado: en curso | completa
- Proyecto: <nombre reconocible del proyecto>
- Negocio: <nombre del negocio (heredado)>
- Actualizado: <fecha>

## Temas
- [x] 1 · qué es
- [x] 2 · alcance
- [ ] 3 · objetivos   ← siguiente
- [ ] 4 · interlocutores
- [ ] 5 · particularidades

## Notas de respuestas
- <apuntes útiles ya dados por el usuario que aún no hayan ido a proyecto.md>
```

Al reejecutar `/onboarding`, este archivo + la existencia de `CONTEXT/proyecto.md` te dicen por
dónde seguir sin volver a preguntar lo respondido. (R20)

## Paso 6 — Verificar con el usuario (cierre)

Cuando `CONTEXT/proyecto.md` esté escrito:

1. Responde a **"¿de qué va este proyecto?"** usando el `proyecto.md` recién creado: un resumen
   breve (qué es, alcance, objetivos, con quién) leído del archivo, no de memoria.
2. **Pide confirmación**: "¿Describe bien el proyecto? ¿Corrijo algo?". No des la fase por
   cerrada sin su visto bueno.
3. Si señala un error, **corrige `CONTEXT/proyecto.md`** y vuelve a mostrar el resumen corregido
   y a pedir confirmación. Repite hasta que confirme.
4. Marca en `harness/progress/onboarding.md` la Fase 1 de proyecto como `completa`.

## Paso 7 — Siguiente paso

Cuando el usuario confirma que la Fase 1 de proyecto es correcta, recuérdale que ya puede
trabajar el proyecto con normalidad (los comandos y skills se heredan de `~/.claude`) y, si
procede, **sugiere `/commit`** para guardar este contexto. No lo ejecutes tú: solo propónselo en
una frase.

## Qué NO hacer

- No repitas preguntas cuyo dato ya está en `Mi-Empresa/CONTEXT/` (lo del negocio se hereda).
- No presentes un formulario con todos los temas de golpe: pocas preguntas cada vez.
- No dejes `TODO` ni marcadores sin resolver al cerrar `CONTEXT/proyecto.md`.
- No inventes cifras, nombres ni plazos: pregúntalos.
- No arranques ni configures la Fase 2 (Infraestructura) ni la Fase 3 (Datos): están resueltas
  a nivel de usuario y el proyecto las hereda. Si no lo estuvieran, es cosa de `/onboarding` en
  `Mi-Empresa/`.
- No toques archivos fuera de esta carpeta de proyecto (salvo **leer** `Mi-Empresa/CONTEXT/`).
