# Flujo de trabajo con Git — AIOS {{NOMBRE_NEGOCIO}}

Aplica a todo desarrollo de backend y frontend en este workspace.

## Ramas

| Prefijo | Cuándo usarlo |
| --- | --- |
| `design/nombre` | Trabajo visual o de frontend |
| `feature/nombre` | Lógica nueva o backend |
| `fix/nombre` | Correcciones de bugs |

Una rama por módulo. Nunca se trabaja directamente en `main`.

## Commits = versiones nombradas

Formato: `vN — descripción corta`

Ejemplo: `v1 — prototipo tarjetas horizontal`, `v2 — ajuste colores preview PDF`

El historial queda navegable: `git checkout vN` permite volver a cualquier estado anterior.

## Prototipo antes de producción

- El archivo de prueba (`*-test.html`, `*-draft.js`, etc.) vive en la rama de diseño durante la iteración.
- Los archivos de producción **no se tocan** hasta que {{DUENO}} aprueba una versión.
- Aprobación → se aplica al archivo de producción → merge a `main`.

## PR por módulo en GitHub

Antes de mergear a `main`, se abre una Pull Request. Permite:
- Ver el diff completo de lo que se aprueba
- Dejar registro histórico de qué entró y cuándo

## Flujo resumido

```
main → [nueva rama] → v1 commit → v2 commit → ... → {{DUENO}} aprueba → PR → merge a main
```
