---
name: onboarding-datos
description: Conduce la Fase 3 (Datos y conexiones) del onboarding del AIOS. Entrevista al dueño del negocio sobre qué herramientas usa en su día a día (reuniones, CRM, almacenamiento tipo Drive / Microsoft 365…) y las conecta a la IA por MCP con alcance de usuario, o —si no hay servidor MCP— monta un conector a medida siguiendo la skill mcp-integration. Registra cada conexión en DATA/integraciones/ (sin credenciales), regenera DATA/key-metrics.md con lo que sabe la IA gracias a cada conexión y deja constancia a nivel de usuario. La invoca el comando /onboarding cuando la Fase 1 está completa y la Fase 3 aún no consta resuelta a nivel de usuario. No hace falta que el usuario sepa programar.
---

# Skill: onboarding — Fase 3 (Datos y conexiones · MCP)

Tu trabajo es **conectar las herramientas del negocio a la IA**: preguntar qué usa el
cliente en su día a día (reuniones, CRM, almacenamiento tipo Drive / Microsoft 365, y lo
que añada) y enchufarlas por **MCP** (Model Context Protocol) para que la IA pueda leer y
usar esa información. Cuando una herramienta no tiene servidor MCP, montas un **conector a
medida** siguiendo la skill `mcp-integration`. Al final dejas un `DATA/key-metrics.md`
legible que explica, por cada herramienta, **qué sabe la IA** gracias a esa conexión.

> Esta fase es una configuración **del ordenador/persona**, no de la carpeta: las
> conexiones se resuelven **una sola vez** por ordenador y sirven para `Mi-Empresa/` y para
> cualquier carpeta que se cree luego con `/crear-proyecto`. Por eso el registro MCP se hace
> con **alcance de usuario** y la constancia de "hecho" vive a nivel de usuario
> (`~/.claude/aios/estado-usuario.md`), fuera de `Mi-Empresa/` — igual que la Fase 2.

> Cómo decidir MCP vs. conector a medida y qué debe contener `key-metrics.md` (conectado vs.
> útil) está en `references/guia-datos.md`. Léelo antes de conectar y antes de escribir
> `key-metrics.md`.

## Principios (no los rompas)

- **Conversación, no formulario.** Pregunta pocas cosas cada vez. No des por supuesto qué
  herramientas usa: pregúntalo. (R4)
- **De una en una.** Si no quiere conectarlo todo de golpe, pregunta con cuál empezar,
  respeta ese orden y conecta una herramienta cada vez. (R5)
- **Alcance de usuario, nunca de carpeta.** Los servidores MCP se registran con alcance de
  **usuario** para que sirvan a cualquier carpeta. **Nunca** los registres solo dentro de
  `Mi-Empresa/` (un `.mcp.json` de proyecto), porque una carpeta hermana no lo heredaría.
  (R6, R7)
- **Cero credenciales en el repo.** Claves, tokens y contraseñas viven en el gestor de
  credenciales del cliente MCP / del sistema o en variables de entorno. Nunca en archivos
  versionados. (R10)
- **"Conectado" no basta: di qué aporta.** En `key-metrics.md`, por cada herramienta,
  explica qué información o capacidad gana la IA, no solo que está enchufada. (R12)
- **No repitas lo ya hecho.** Lee el estado antes de conectar y retoma solo lo pendiente.
  (R15, R16)
- **Tono cercano y no técnico.** El usuario probablemente no es programador; tú haces el
  trabajo técnico, él decide y aprueba.

## Paso 0 — Requisito: la Fase 1 tiene que estar completa (R1)

Antes de nada, comprueba que existe `CONTEXT/negocio.md` en la carpeta actual. Si **no**
existe, la Fase 1 (Contexto) aún no está hecha: **no arranques la Fase 3**. Dile al usuario
que primero conviene completar el contexto con `/onboarding` (Fase 1) y para aquí. La Fase 3
**no** exige que la Fase 2 (Infraestructura) esté hecha: son independientes.

## Paso 1 — Detectar el estado (siempre, antes de conectar nada) (R15, R16)

Mira el disco para no repetir trabajo:

1. **Constancia a nivel de usuario.** Lee `~/.claude/aios/estado-usuario.md`. Si existe y
   marca la **Fase 3 como resuelta**, las conexiones de este ordenador ya están registradas;
   fíjate en la lista de conexiones y en las **pendientes** anotadas.
2. **Progreso de esta carpeta.** Lee `harness/progress/onboarding.md` si existe: te dice qué
   herramientas quedaron conectadas y cuáles pendientes.
3. **Fichas ya escritas.** Mira `DATA/integraciones/`: cada `<herramienta>.md` distinta de la
   plantilla es una conexión ya registrada.
4. **Servidores MCP ya presentes.** Puedes listar los servidores registrados con
   `claude mcp list` para ver cuáles ya están montados a nivel de usuario.

Resume mentalmente: qué herramientas ya están conectadas y cuáles quedan pendientes.
Saluda reconociendo lo avanzado ("Ya tienes conectado el Drive; nos queda el CRM") en vez
de empezar de cero. **No vuelvas a registrar** una conexión que ya conste resuelta (R15);
retoma solo por lo pendiente (R16).

## Paso 2 — Entrevistar por herramientas (conversacional) (R4)

Explica en una frase qué vas a hacer: "voy a conectar las herramientas que usas para que la
IA pueda ayudarte con ellas". Luego pregunta, sin dar nada por supuesto, qué usa en su día a
día. Cubre al menos estas familias, preguntando (no asumiendo):

- **Reuniones** — ¿graba/transcribe reuniones? ¿con qué (Google Meet, Zoom, Fireflies…)?
- **CRM / clientes** — ¿dónde lleva sus clientes y ventas? (HubSpot, Pipedrive, un Excel,
  GoHighLevel…)
- **Almacenamiento** — ¿dónde guarda documentos? (Google Drive, Microsoft 365 / OneDrive,
  Dropbox, carpetas locales…)
- **Lo que añada** — deja que mencione cualquier otra (facturación, email, agenda, WhatsApp…).

Pregunta poco cada vez y reacciona a lo que dice. El objetivo de este paso es tener la
**lista de herramientas candidatas** a conectar, con una nota de para qué usa cada una (eso
alimentará su ficha y `key-metrics.md`).

## Paso 3 — Elegir orden (una de una) (R5)

Pregunta si quiere conectarlas todas ahora o empezar por una. Si **no** quiere conectarlo
todo de golpe:

- Pregúntale **con cuál quiere empezar**.
- **Respeta ese orden** y conéctalas **de una en una**: no arranques la siguiente hasta
  cerrar (o aplazar explícitamente) la anterior.
- Las que aplace quedan como **pendientes** (Paso 6 y `key-metrics.md`, R13).

## Paso 4 — Conectar cada herramienta elegida

Para **cada** herramienta, en orden:

### 4a. ¿Hay servidor MCP? (R6, R7)

Consulta `references/guia-datos.md` para saber si la herramienta tiene un servidor MCP
oficial/conocido (p. ej. Google Drive, Microsoft 365).

**Si existe servidor MCP** → regístralo con **alcance de usuario**. En Claude Code:

```
claude mcp add --scope user <nombre> <comando-o-url-del-servidor> [args...]
```

El flag `--scope user` es lo que hace que quede guardado en la configuración del **usuario**
del ordenador y disponible en **cualquier** carpeta que abra después (incluidas las que cree
con `/crear-proyecto`). (R6)

- **Nunca** lo registres solo dentro de `Mi-Empresa/` (alcance de proyecto: un `.mcp.json`
  en la carpeta, o `--scope project` / `--scope local`). Una carpeta hermana creada luego no
  lo heredaría y el cliente tendría que reconectarlo. (R7)
- La **autenticación** (login OAuth, permisos) la gestiona el propio cliente MCP: cuando el
  servidor lo pida, guía al usuario por el login en su navegador. Las credenciales las guarda
  el sistema / el cliente MCP, **no** tú en un archivo. (R10)
- Comprueba que quedó bien con `claude mcp list` (debe aparecer con alcance de usuario).

### 4b. ¿No hay servidor MCP? → conector a medida (R8)

Si la herramienta **no** tiene servidor MCP conocido, sigue el patrón de la skill
**`mcp-integration`** (instalada a nivel de usuario como parte de la herramienta) para
documentar y montar un conector a medida:

- Invoca / consulta la skill `mcp-integration`: ella define los tipos de servidor MCP
  (stdio / HTTP-SSE), cómo autenticar y cómo exponer las capacidades de la herramienta.
- Monta el conector según ese patrón y regístralo también con **alcance de usuario** (misma
  regla que 4a: nunca solo en la carpeta).
- Si el conector necesita una clave de API, documenta el **nombre** de la variable de
  entorno en la ficha de la herramienta (Paso 5), **nunca** su valor. (R10)

> No redefinas aquí el contenido de `mcp-integration`: remítete a ella. Su trabajo es el
> "cómo" técnico del conector; el tuyo es conducir la fase y dejar el registro.

### 4c. Registrar la conexión en DATA/integraciones/ (R9, R10)

Crea/actualiza `DATA/integraciones/<herramienta>.md` partiendo de
`DATA/integraciones/PLANTILLA-integracion.md`. Rellena, sin dejar `TODO`:

- **Para qué se usa** — el/los caso(s) de uso que te contó el usuario.
- **Tipo de conexión** — `MCP (alcance de usuario)` o `Conector a medida (patrón
  mcp-integration)`.
- **Estado** — `Conectada` (con fecha y qué se verificó) o `Pendiente de conectar` si se
  aplazó.
- **Credenciales** — solo el **nombre** de la variable de entorno si aplica; nunca su valor.
  Si la autenticación la gestiona el cliente MCP (OAuth), dilo explícito ("gestionada por el
  cliente MCP, sin clave en el repo").

**Nunca** escribas una clave, token o contraseña en esta ficha ni en ningún archivo
versionado. (R10)

## Paso 5 — Regenerar DATA/key-metrics.md (tras cada conexión o al terminar) (R11, R12, R13)

Reescribe `DATA/key-metrics.md` (créalo si no existe) con un resumen **legible** de lo
conectado. Sigue el formato de `references/guia-datos.md`. Debe incluir:

- Una sección **"Conectado"** con, **por cada herramienta conectada**, qué información o
  capacidad aporta a la IA gracias a esa conexión — no solo "conectada". (R12)
  Ejemplo: "Google Drive (MCP): la IA puede leer y buscar en los documentos del negocio
  guardados en Drive (propuestas, contratos, notas)."
- Una sección **"Pendientes de conectar"** listando las herramientas que el usuario aplazó.
  (R13)

Regenéralo **tras cada conexión** (así el progreso queda reflejado aunque se corte la
sesión) y de nuevo al cerrar la fase.

## Paso 6 — Guardar el progreso reanudable (R16)

Mantén al día `harness/progress/onboarding.md` (créalo si no existe; es el mismo archivo que
usan las Fases 1 y 2). Anota qué herramientas quedaron **conectadas** y cuáles **pendientes**,
para que una interrupción no pierda trabajo y `/onboarding` retome solo lo pendiente. Añade
una sección de Fase 3, por ejemplo:

```markdown
## Fase 3 · Datos y conexiones
- Estado: en curso | completa
- Actualizado: <fecha>
- Conectadas:
  - [x] almacenamiento · Google Drive (MCP, alcance usuario)
- Pendientes:
  - [ ] CRM · <herramienta>  ← siguiente
  - [ ] reuniones · <herramienta>
```

Al reejecutar `/onboarding`, este archivo + la constancia de usuario te dicen por dónde
seguir sin repetir lo hecho. (R16)

## Paso 7 — Dejar constancia a nivel de usuario (R14)

Añade a `~/.claude/aios/estado-usuario.md` (créalo con su carpeta si no existe; es el mismo
archivo/mecanismo que la Fase 2) una sección **"Fase 3 · Datos y conexiones"** con fecha y la
lista de conexiones a nivel de usuario y su tipo. Es lo que `/onboarding` lee al reabrirse
(para no repetir, R15) y lo que `/crear-proyecto` consultará para no volver a pedir estas
conexiones. Formato (añade la sección, no borres la de la Fase 2):

```markdown
## Fase 3 · Datos y conexiones
- Estado: resuelta
- Fecha: <fecha de hoy>
- Conexiones a nivel de usuario:
  - Google Drive — MCP (alcance usuario)
  - <herramienta> — Conector a medida (patrón mcp-integration)
- Pendientes de conectar: <lista, o "ninguna">
```

Marca "Estado: resuelta" cuando el usuario dé por buenas las conexiones hechas (aunque queden
pendientes: esas se retoman luego sin repetir las ya resueltas).

## Paso 8 — Cierre

- Confirma al usuario, en lenguaje llano, qué ha quedado conectado y **qué sabe ahora la IA**
  gracias a ello (léelo de `key-metrics.md`, no de memoria). Menciona lo que quede pendiente.
- Deja el progreso reflejado en `harness/progress/onboarding.md` (Fase 3 = completa si no
  quedan pendientes; en curso si sí) y la constancia de usuario actualizada.

## Qué NO hacer

- No arranques la Fase 3 si la Fase 1 no está completa (no existe `CONTEXT/negocio.md`).
- No des por supuesto qué herramientas usa el cliente: pregúntalo.
- No registres un servidor MCP solo dentro de `Mi-Empresa/` (alcance de carpeta/proyecto):
  siempre alcance de **usuario**.
- No escribas nunca claves, tokens ni contraseñas en fichas ni en ningún archivo versionado:
  van en el gestor de credenciales del cliente MCP / del sistema o en variables de entorno
  (documenta solo el **nombre** de la variable).
- No repitas conexiones que ya consten resueltas: retoma solo lo pendiente.
- No redefinas el contenido de la skill `mcp-integration`: remítete a ella para el conector.
- No toques archivos fuera de la carpeta del negocio actual, salvo el archivo de estado a
  nivel de usuario (`~/.claude/aios/estado-usuario.md`) y el registro MCP de usuario, que son
  su sitio a propósito.
