# Clientes objetivo — {{NOMBRE_NEGOCIO}}

> Capa 1 (Context). Cliente ideal (ICP), sectores y tamaño.
> Estado: scaffold — responde las secciones `TODO`.

## Cliente ideal (ICP)
TODO — a quién se dirige el negocio (perfil, sector, tamaño).

## Segmentos
TODO — segmentos de cliente y prioridad de cada uno.

## A quién NO se dirige
TODO — para evitar esfuerzo en clientes que no encajan.
