# Negocio — {{NOMBRE_NEGOCIO}}

> Capa 1 (Context). Quién es el negocio, su propuesta de valor y su diferencial.
> Estado: scaffold — responde las secciones `TODO`.

## Qué es {{NOMBRE_NEGOCIO}}
TODO — en una frase: qué hace y para quién.

## Propuesta de valor
TODO — qué problema resuelve y por qué el cliente paga.

## Diferencial
TODO — por qué este negocio y no la competencia.

## Cifras clave
- Facturación: TODO
- Clientes activos: TODO
- Año de fundación / hitos: TODO
