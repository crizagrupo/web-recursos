---
description: Actualiza el panel de seguimiento (de negocio o de proyecto).
---

Actualiza el dashboard que corresponda al sitio donde estés.

1. **En un proyecto**: usa la skill `actualizar-dashboard` para sincronizar `BUILD/dashboard/datos.js` con el `ESTADO.md` del proyecto.
2. **A nivel negocio** (en `Mi-Empresa/`): usa la skill `actualizar-dashboard` (rama de negocio), que localiza la carpeta hermana `Proyectos/`, recorre cada `Proyectos/<cliente>/ESTADO.md` y regenera `Mi-Empresa/BUILD/dashboard-negocio/` (la crea la primera vez) con la cartera de proyectos. Si aún no hay ningún proyecto, la deja con la cartera vacía y un aviso claro, sin inventar datos.

Al terminar, indica cómo abrir el panel (ejecutar su `index.html` / `servir.js`).
