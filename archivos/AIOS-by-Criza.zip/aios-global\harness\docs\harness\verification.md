﻿# Verificación — Cómo demostrar que un módulo funciona

> En el AIOS no hay un suite de tests de código como en un proyecto de software.
> La verificación combina invariantes estructurales (automáticas) + una prueba
> funcional real del módulo.

## 1. Invariantes estructurales — `verify.ps1`
Se ejecutan con `./verify.ps1` (o al cerrar la sesión vía hook). Comprueban:
- `build_backlog.json` es JSON válido.
- Hay **como máximo un** módulo en `in_progress`.
- Todo módulo `sdd: true` en estado `in_progress` o `done` tiene `specs/<modulo>/` con los 3 archivos.
- No hay carpetas en `specs/` sin su entrada correspondiente en el backlog (sin specs huérfanos).
- No hay credenciales evidentes commiteadas (búsqueda de patrones tipo `api_key`, `sk-`, tokens).

Si `verify.ps1` falla, **no se cierra** la sesión ni se marca nada `done` hasta resolverlo.

## 2. Prueba funcional del módulo
Definida en el `design.md` del módulo. El `builder` la ejecuta **al menos una vez** con datos de prueba y guarda el resultado en `progress/impl_<modulo>.md`. Ejemplos según tipo:

| Tipo de módulo | Prueba funcional mínima |
|----------------|--------------------------|
| Genera un documento (propuestas, brief) | Ejecutarlo con un caso de ejemplo y comprobar que el archivo de salida cumple cada `R<n>`. |
| Sincroniza datos (sync GHL/Supabase) | Ejecutar la sincronización y comprobar que los datos esperados aparecen en `DATA/`. |
| Procesa una entrada (reuniones) | Pasarle una transcripción de ejemplo y comprobar que el resumen y los action items son correctos. |
| Herramienta interactiva (dashboard, audit-tool) | Abrirla/ejecutarla y comprobar el flujo principal de uso. |

## 3. Trazabilidad
En `progress/impl_<modulo>.md`, el `builder` deja el mapa `R<n> → cómo se comprobó`:
```markdown
## Trazabilidad
- R1 → Ejecutado `generar.ps1`; se creó el brief con las 24h. ✓
- R2 → Probado sin pipeline; el brief indica "pipeline no disponible". ✓
```

## 4. Checklist de cierre (lo valida el reviewer)
- [ ] `verify.ps1` verde.
- [ ] Cada `R<n>` del spec tiene su comprobación en `progress/impl_<modulo>.md`.
- [ ] Todas las tasks de `tasks.md` están `[x]`.
- [ ] El módulo tiene `README.md` en lenguaje sencillo.
- [ ] Sin credenciales en archivos.
- [ ] `build_backlog.json` actualizado y resumen movido a `progress/history.md`.
