// ============================================================================
// lib.js — utilidades compartidas del comando /actualizar-dashboard
// ----------------------------------------------------------------------------
// Código determinista, sin IA. Localiza el dashboard del proyecto, carga su
// fuente de verdad (window.DATOS) en un sandbox y produce una "foto" con el
// recuento de elementos por sección, que sirve para detectar pérdidas.
// Genérico: sirve para cualquier AIOS que use la plantilla de dashboard.
// ============================================================================
const fs = require('fs');
const path = require('path');
const vm = require('vm');

// Localiza BUILD/dashboard/datos.js subiendo desde el directorio de trabajo.
// Soporta ejecutarse desde la raíz del proyecto o desde dentro del dashboard.
function findDatos() {
  const tries = [];
  let dir = process.cwd();
  for (let i = 0; i < 12; i++) {
    tries.push(path.join(dir, 'BUILD', 'dashboard', 'datos.js'));
    tries.push(path.join(dir, 'datos.js')); // por si el cwd ya es la carpeta del dashboard
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  for (const t of tries) {
    if (fs.existsSync(t)) return t;
  }
  return null;
}

// Carga datos.js en un sandbox y devuelve window.DATOS. Lanza si el JS no parsea.
function loadDatos(filePath) {
  const code = fs.readFileSync(filePath, 'utf8');
  const sandbox = { window: {} };
  vm.createContext(sandbox);
  vm.runInContext(code, sandbox, { filename: filePath });
  if (!sandbox.window || !sandbox.window.DATOS) {
    throw new Error('El archivo no define window.DATOS');
  }
  return sandbox.window.DATOS;
}

// Recorre el objeto y registra la longitud de cada array por su ruta con puntos
// (p. ej. "fases", "auditoria.decisiones"). Genérico para cualquier esquema.
function countArrays(obj, prefix, out) {
  out = out || {};
  if (Array.isArray(obj)) {
    out[prefix] = obj.length;
    return out; // no se entra dentro de los elementos del array
  }
  if (obj && typeof obj === 'object') {
    for (const k of Object.keys(obj)) {
      const p = prefix ? prefix + '.' + k : k;
      countArrays(obj[k], p, out);
    }
  }
  return out;
}

// Foto comparable del estado: fecha + recuento de arrays por sección.
function snapshot(datos) {
  return {
    actualizado: datos.actualizado || null,
    counts: countArrays(datos, '', {}),
  };
}

// Carpeta y ruta del archivo de foto, junto al propio datos.js.
function backupsDir(datosPath) {
  return path.join(path.dirname(datosPath), '.backups');
}
function snapshotPath(datosPath) {
  return path.join(backupsDir(datosPath), '_snapshot-antes.json');
}

// ============================================================================
// Helpers de la RAMA DE NEGOCIO (dashboard de cartera de proyectos).
// No tocan la lógica de proyecto de arriba. Localizan la raíz del negocio
// (Mi-Empresa/), su hermana Proyectos/, el datos.js del dashboard de negocio y
// listan los proyectos con su ESTADO.md.
// ============================================================================

// Localiza la carpeta Mi-Empresa/ subiendo desde el directorio de trabajo.
// - Si el cwd (o un ancestro) ES Mi-Empresa, la devuelve.
// - Si el cwd (o un ancestro) CONTIENE una subcarpeta Mi-Empresa, la devuelve.
// Misma lógica de localización que /crear-proyecto (Paso 3). Devuelve null si
// no la encuentra.
function findMiEmpresa() {
  let dir = process.cwd();
  for (let i = 0; i < 12; i++) {
    if (path.basename(dir) === 'Mi-Empresa' && fs.existsSync(dir)) return dir;
    const hijo = path.join(dir, 'Mi-Empresa');
    if (fs.existsSync(hijo) && fs.statSync(hijo).isDirectory()) return hijo;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return null;
}

// Devuelve la ruta de la carpeta Proyectos/ hermana de Mi-Empresa/.
// OJO: puede no existir todavía (negocio nuevo sin proyectos): el que llama
// debe comprobar fs.existsSync. Si no encuentra Mi-Empresa, devuelve null.
function findProyectosDir(miEmpresa) {
  const me = miEmpresa || findMiEmpresa();
  if (!me) return null;
  return path.join(path.dirname(me), 'Proyectos');
}

// Ruta del datos.js del dashboard de negocio (puede no existir aún).
function findDatosNegocio(miEmpresa) {
  const me = miEmpresa || findMiEmpresa();
  if (!me) return null;
  return path.join(me, 'BUILD', 'dashboard-negocio', 'datos.js');
}

// Deriva el nombre legible de un proyecto: primero del marcador .aios-proyecto
// (campo "nombre:"), si no del título "# ..." de su CLAUDE.md, si no del nombre
// de la carpeta.
function derivarNombreProyecto(carpeta) {
  const marcador = path.join(carpeta, '.aios-proyecto');
  if (fs.existsSync(marcador)) {
    const txt = fs.readFileSync(marcador, 'utf8');
    const m = txt.match(/^\s*nombre\s*:\s*(.+)$/mi);
    if (m && m[1].trim()) return m[1].trim();
  }
  const claude = path.join(carpeta, 'CLAUDE.md');
  if (fs.existsSync(claude)) {
    const txt = fs.readFileSync(claude, 'utf8');
    const m = txt.match(/^#\s+(.+)$/m);
    if (m && m[1].trim()) {
      // "AIOS — Proyecto: Bar Manolo" → "Bar Manolo"
      const t = m[1].replace(/^AIOS\s*[—-]\s*/i, '').replace(/^Proyecto\s*:\s*/i, '').trim();
      if (t && !/\{\{.*\}\}/.test(t)) return t;
    }
  }
  return path.basename(carpeta);
}

// Lista los proyectos de Proyectos/. Por cada subcarpeta devuelve:
//   { id, nombre, carpeta, estadoPath, estadoTexto }
// id = nombre de carpeta (slug). estadoPath/estadoTexto = null si no hay
// ESTADO.md. Si Proyectos/ no existe o está vacía, devuelve [].
function listarProyectos(proyectosDir) {
  const dir = proyectosDir || findProyectosDir();
  if (!dir || !fs.existsSync(dir)) return [];
  let entradas;
  try {
    entradas = fs.readdirSync(dir, { withFileTypes: true });
  } catch (e) {
    return [];
  }
  const out = [];
  for (const ent of entradas) {
    if (!ent.isDirectory()) continue;
    if (ent.name.startsWith('.')) continue;
    const carpeta = path.join(dir, ent.name);
    const estadoPath = path.join(carpeta, 'ESTADO.md');
    const hayEstado = fs.existsSync(estadoPath);
    out.push({
      id: ent.name,
      nombre: derivarNombreProyecto(carpeta),
      carpeta,
      estadoPath: hayEstado ? estadoPath : null,
      estadoTexto: hayEstado ? fs.readFileSync(estadoPath, 'utf8') : null,
    });
  }
  return out;
}

module.exports = {
  findDatos, loadDatos, countArrays, snapshot, backupsDir, snapshotPath,
  findMiEmpresa, findProyectosDir, findDatosNegocio, listarProyectos,
};
