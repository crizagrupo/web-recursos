---
name: onboarding-infraestructura
description: Conduce la Fase 2 (Infraestructura) del onboarding del AIOS. Conecta Git y GitHub explicándolos desde cero a un dueño de negocio que puede no haberlos usado nunca, inicializa el repositorio de la carpeta, hace el primer commit y su push (dejando fuera .env y credenciales), actualiza HISTORICO.md solo y deja el comando /commit listo. La invoca el comando /onboarding cuando la Fase 1 está completa y la Fase 2 aún no consta resuelta a nivel de usuario. Es una configuración del ordenador (se resuelve una vez), no de la carpeta. No hace falta que el usuario sepa programar.
---

# Skill: onboarding — Fase 2 (Infraestructura)

Tu trabajo es dejar el negocio **guardado y a salvo**: conectar Git y GitHub para que
todo lo que se construya en `Mi-Empresa/` quede versionado y respaldado en la nube. El
usuario probablemente **no ha usado Git nunca**, así que lo explicas desde cero y haces tú
el trabajo técnico; él solo decide y aprueba.

> Esta fase es una configuración **del ordenador/persona**, no de la carpeta: se resuelve
> **una sola vez** por ordenador y sirve para `Mi-Empresa/` y para cualquier carpeta que se
> cree luego con `/crear-proyecto`. Por eso la constancia de "hecho" vive a nivel de usuario
> (`~/.claude/aios/estado-usuario.md`), fuera de `Mi-Empresa/`.

## Principios (no los rompas)

- **Explica desde cero, sin jerga.** Da por sabido cero conceptos técnicos. Usa las
  analogías de `references/guia-git.md`. (R6)
- **Hazlo tú.** El usuario habla y aprueba; tú ejecutas los comandos de Git y GitHub. No le
  pidas que edite archivos ni que escriba comandos.
- **Nunca subas secretos.** Antes del primer commit, asegura que `.env`, credenciales y
  claves quedan fuera. (R10)
- **No repitas lo ya hecho.** Si el ordenador ya tiene identidad Git/GitHub o la Fase 2 ya
  consta resuelta, no vuelvas a crear cuenta ni a configurar identidad. (R5, R12)
- **Tono cercano.** Celebra el hito: es la primera vez que su negocio queda respaldado.

## Paso 0 — Requisito: la Fase 1 tiene que estar completa (R1)

Antes de nada, comprueba que existe `CONTEXT/negocio.md` en la carpeta actual. Si **no**
existe, la Fase 1 (Contexto) aún no está hecha: **no arranques la Fase 2**. Dile al usuario
que primero conviene completar el contexto con `/onboarding` (Fase 1) y para aquí.

## Paso 1 — Detectar el estado (siempre, antes de explicar nada) (R4)

Mira el ordenador para no repetir trabajo ni asustar con explicaciones innecesarias:

1. **Identidad Git.** Ejecuta:
   - `git config --global user.name`
   - `git config --global user.email`
   Si **ambas** devuelven un valor no vacío, este ordenador ya tiene identidad Git.
2. **Conexión GitHub.** Ejecuta `gh auth status` (GitHub CLI). Si responde que hay una
   cuenta autenticada, GitHub ya está conectado. (Alternativa: un remoto ya autenticado y
   funcional también cuenta.)
3. **Constancia previa.** Lee `~/.claude/aios/estado-usuario.md`. Si existe y marca la
   **Fase 2 como resuelta**, la infraestructura de este ordenador ya está montada.
4. **Repo de esta carpeta.** Comprueba si `Mi-Empresa/` ya es un repositorio Git (existe
   `.git/`) y si tiene remoto (`git remote -v`).

Resume mentalmente en qué punto estás: identidad sí/no, GitHub sí/no, Fase 2 resuelta
sí/no, repo de esta carpeta sí/no.

## Paso 2 — Si ya está resuelto, no repitas (R5, R12)

Si la identidad Git ya existe **o** la Fase 2 ya consta resuelta en
`~/.claude/aios/estado-usuario.md`:

- **No** vuelvas a crear cuenta de GitHub ni a configurar `user.name`/`user.email`.
- Informa en una frase amable: "La infraestructura de tu ordenador ya está lista (Git y
  GitHub conectados), no hace falta repetirla."
- Si **esta** carpeta (`Mi-Empresa/`) todavía no está inicializada o no tiene remoto, sí
  completas solo lo que le falte a la carpeta (Pasos 5–7) reutilizando la identidad y la
  cuenta que ya existen. Si la carpeta ya está conectada y con su primer commit, no hay
  nada que hacer: continúa hacia la Fase 3.

Si nada de esto está resuelto, sigue por el Paso 3.

## Paso 3 — Explicar Git y GitHub desde cero (R6)

Solo cuando **no** hay identidad configurada. Abre `references/guia-git.md` y explícalo con
esas analogías, en lenguaje llano y en pocas frases (no sueltes toda la guía de golpe):

- **Git** = los *puntos de guardado de un videojuego*: puedes volver a cualquiera.
- **GitHub** = la *nube donde se guarda esa partida* y no se pierde aunque se rompa el
  ordenador.
- **commit** = *crear un punto de guardado* con una nota de qué cambió.
- **push** = *subir* esos puntos de guardado a la nube.

Comprueba que lo ha entendido antes de seguir. Nada de jerga (no digas "staging",
"branch", "HEAD" sin traducirlo a esa metáfora).

## Paso 4 — Crear la cuenta de GitHub y la identidad Git (R7)

Solo si no existían (Paso 1). Guía al usuario, paso a paso:

1. **Cuenta de GitHub.** Si no tiene, acompáñale a crearla en `https://github.com` (correo
   + contraseña + verificación). Es gratis. Explica que es "la nube" de la analogía.
2. **Autenticar el ordenador con GitHub.** El camino más simple para un no-técnico es
   GitHub CLI: `gh auth login` (elige GitHub.com → HTTPS → autenticar por navegador). Así
   no hay que gestionar tokens a mano: las credenciales las guarda el sistema, no nosotros.
3. **Identidad Git** (el nombre que firmará cada punto de guardado). Pregúntale su nombre y
   su email y configúralos tú:
   - `git config --global user.name "<su nombre>"`
   - `git config --global user.email "<su email>"`
   Usa el mismo email de su cuenta de GitHub, así los commits salen a su nombre.

Nunca guardes contraseñas ni tokens en archivos del proyecto: viven en `gh` / en el gestor
de credenciales del sistema.

## Paso 5 — Inicializar el repositorio de Mi-Empresa/ y conectarlo a GitHub (R8)

1. Si `Mi-Empresa/` aún no es un repositorio (no hay `.git/`): `git init` dentro de la
   carpeta.
2. Crea (o enlaza) un repositorio del usuario en GitHub y ponlo como remoto. Con GitHub
   CLI, lo más simple: `gh repo create <nombre> --private --source . --remote origin`
   (repositorio **privado** por defecto: son los datos de su negocio). Si prefiere hacerlo
   por web, crea el repo vacío en GitHub y enlázalo con
   `git remote add origin <url>`.
3. Confirma con `git remote -v` que `origin` apunta a su repositorio.

## Paso 6 — Asegurar que NO se suben secretos (R10)

**Antes** del primer commit:

1. Comprueba que existe `.gitignore` en `Mi-Empresa/` y que excluye `.env`, `.env.*` y
   patrones de credenciales/claves. La plantilla ya trae uno; si falta o está incompleto,
   complétalo. (Ver el `.gitignore` que acompaña a `Mi-Empresa/`.)
2. Prepara los cambios (`git add -A`) y **verifica el área de stage**: `git status` y
   `git ls-files --cached`. Si aparece cualquier `.env` o archivo con aspecto de
   credencial, **quítalo** del stage (`git rm --cached <archivo>`) y añádelo al
   `.gitignore` antes de continuar. No sigas hasta que el stage esté limpio de secretos.

## Paso 7 — Primer commit y push (R9)

1. Primer commit con un mensaje claro, p. ej.:
   `git commit -m "Primer guardado: contexto del negocio y estructura del AIOS"`.
   Explícale que acaba de crear su primer "punto de guardado".
2. Súbelo a la nube: `git push -u origin <rama-actual>` (normalmente `main` o `master`).
   Explícale que su negocio ya está respaldado en GitHub.
3. Confirma que el push fue correcto y que en GitHub **no** aparece ningún `.env` ni
   credencial.

## Paso 8 — Actualizar HISTORICO.md solo (R13)

Tras el primer commit, **añade tú** una entrada a `Mi-Empresa/HISTORICO.md`, sin que el
usuario la escriba. Si el título aún tiene `{{NOMBRE_NEGOCIO}}`, sustitúyelo por el nombre
real (lo tienes en `CONTEXT/negocio.md` o en `CLAUDE.md`). Entrada, más reciente primero:

```markdown
- **<fecha de hoy>** — Infraestructura conectada · primer commit y push a GitHub.
```

## Paso 9 — Dejar constancia a nivel de usuario (R11)

Escribe o actualiza `~/.claude/aios/estado-usuario.md` (créalo, con su carpeta, si no
existe). Este es el archivo que `/onboarding` lee al reabrirse y que `/crear-proyecto`
consultará para **no** repetir esta fase. Vive fuera de `Mi-Empresa/` a propósito: es una
propiedad del ordenador. Formato:

```markdown
# Estado del AIOS — nivel usuario (este ordenador)

> Lo que ya está resuelto a nivel de ordenador y no hay que repetir por carpeta.
> Lo consultan /onboarding (al reabrirse) y /crear-proyecto.

## Fase 2 · Infraestructura
- Estado: resuelta
- Fecha: <fecha de hoy>
- Identidad Git: <nombre> <<email>>
- GitHub: conectado (cuenta <usuario de GitHub>)
- Comando /commit: instalado
```

Con esto, R12 queda cubierto: la próxima vez que se ejecute `/onboarding`, verá este
archivo y no volverá a pedir configurar Git/GitHub.

## Paso 10 — Dejar /commit operativo (R14)

La Fase 2 deja listo el comando `/commit` (su comportamiento interno se define en el
módulo 18; aquí solo garantizas sus prerrequisitos):

1. Comprueba que `~/.claude/commands/commit.md` está presente (lo instaló el Paso 0 de
   autoinstalación de `/onboarding`, junto con el resto de comandos). Si no estuviera,
   avisa al usuario de que reejecute `/onboarding` en `Mi-Empresa/` para completar la
   instalación de la herramienta.
2. Verifica que la infraestructura de Git queda en estado funcional para él: repositorio
   inicializado, identidad configurada y remoto conectado (todo lo anterior de esta fase).
   Un `git commit` real debe poder ejecutarse en `Mi-Empresa/`.
3. No rediseñes su lógica interna: eso es del módulo 18.

## Paso 11 — Cierre

- Confirma al usuario, en lenguaje llano, lo que ha quedado hecho: "Tu negocio ya está
  versionado y respaldado en GitHub; a partir de ahora, cuando quieras guardar el trabajo,
  usa `/commit`."
- **Aviso sobre `/commit` (posibilidad, no certeza) (R12):** advierte de que `/commit` es un
  **comando** (no una skill) y de que, como el listado de comandos puede fijarse al abrir
  Claude Code, **podría** no estar disponible todavía en esta misma sesión si se acaba de
  instalar en el Paso 0. Si al escribir `/commit` no responde, basta con **cerrar y reabrir
  Claude Code una vez** y quedará disponible. Preséntalo como una posibilidad puntual, **sin
  prometer** que nunca ocurrirá ni asustar: es un pequeño ajuste de una sola vez.
- Deja el progreso reflejado en `harness/progress/onboarding.md` (Fase 2 = completa),
  igual que hace la Fase 1, para que `/onboarding` lo vea al reabrirse.

## Qué NO hacer

- No arranques la Fase 2 si la Fase 1 no está completa (no existe `CONTEXT/negocio.md`).
- No repitas creación de cuenta ni configuración de identidad si ya existen o la Fase 2 ya
  consta resuelta.
- No incluyas nunca `.env`, tokens ni claves en el commit ni en el push.
- No guardes contraseñas ni tokens en archivos del proyecto: van en `gh` / gestor de
  credenciales del sistema.
- No redefinas el comportamiento interno de `/commit` (es del módulo 18).
- No toques carpetas fuera de la carpeta del negocio actual, salvo el archivo de estado a
  nivel de usuario (`~/.claude/aios/estado-usuario.md`), que es su sitio a propósito.
