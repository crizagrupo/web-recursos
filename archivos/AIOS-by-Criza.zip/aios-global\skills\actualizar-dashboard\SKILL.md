---
name: actualizar-dashboard
description: Sincroniza el dashboard de gestión (BUILD/dashboard/datos.js) con el estado actual del proyecto leído de ESTADO.md. Úsala cuando el usuario pida "actualizar el dashboard", "refrescar el panel", "volcar el estado al dashboard" o similar. Vuelca solo los campos vivos y conserva el resto. Funciona en cualquier AIOS que use la plantilla de dashboard del AIOS.
---

# Skill: actualizar el dashboard

Vuelca el **estado actual del proyecto** (`ESTADO.md`) a la fuente de verdad del
dashboard (`BUILD/dashboard/datos.js`), sin romper su esquema ni perder las secciones
narrativas que no están en `ESTADO.md`.

Reparto del trabajo (patrón `informe`): lo **mecánico** lo hacen los scripts Node (sin
IA, sin tokens); el **mapeo con criterio** lo haces tú con ediciones quirúrgicas. No se
regenera el archivo entero (lleva comentarios mantenidos a mano): se editan solo los
campos que cambian.

## Fuente

Única fuente = **`ESTADO.md`** del proyecto. Si falta, avisa y no toques nada.

## Pasos

1. **Preparar** (backup + foto antes):
   ```
   node scripts/preparar.js
   ```
   Resuelve solo el `datos.js` del proyecto desde la carpeta de trabajo. Imprime la ruta,
   la copia de seguridad creada y el recuento de elementos por sección. Si no encuentra
   `BUILD/dashboard/datos.js`, el proyecto no tiene dashboard: avisa y termina.

2. **Leer** `ESTADO.md` y `BUILD/dashboard/datos.js`.

3. **Editar `datos.js`** con ediciones quirúrgicas, mapeando:

   | Campo en `datos.js` | Origen en `ESTADO.md` |
   | --- | --- |
   | `actualizado` | fecha de "Última actualización" del encabezado |
   | `fases[].estado` / `avance` | tabla "Estado por fase" (Pendiente/En curso/Completada; ⬛ ≈ avance) |
   | `auditoria.esperandoHospital[].recibido` | sección "Esperando del Hospital" (✅/[x] = true) |
   | `auditoria.decisiones` | "Decisiones tomadas" |
   | `auditoria.pendientesCriticos` | "Pendientes críticos" / reglas abiertas |
   | `estadoGeneral.proximaAccion` | "Próxima acción", sintetizada en una frase |
   | `estadoGeneral.bloqueos` | "Bloqueos" (lista vacía si no hay) |
   | `tareas` (hitos) | hitos nuevos que aparezcan en "Próxima acción"/"Decisiones" |

   Reglas al editar:
   - **Conserva intactas** las secciones estables que no salen de `ESTADO.md`:
     `proyecto`, `entregables`, `auditoria.sesiones`, `flujoActual`, `flujoPropuesto`,
     `flujoCompleto`, `alcance`. **Salvo** que una decisión de `ESTADO.md` cambie una
     clasificación (p. ej. "difusión pasa de CORE a add-on" → ajusta el `tipo`).
   - Respeta el esquema, los comentarios y el formato. Fechas en `AAAA-MM-DD`.
   - No añadas atributos `data-*` (esos viven en `index.html`, no en `datos.js`).

4. **Verificar**:
   ```
   node scripts/verificar.js
   ```
   Debe dar **PASS**. Si sale **WARN** por pérdida de una sección o fecha sin refrescar,
   corrígelo. Si sale **FAIL**, el JS quedó inválido: restaura desde `.backups/` y repite.

5. **(Opcional) Ver el resultado**:
   ```
   node BUILD/dashboard/servir.js
   ```
   Abre `http://localhost:8765/`. **GOTCHA**: el dashboard guarda copia en
   `localStorage["dashboard_manacor"]` que puede tapar tus cambios. Antes de comprobar,
   en la consola del navegador: `localStorage.removeItem('dashboard_manacor')` y recarga.

6. **Reportar** en 1-2 líneas: qué fecha tiene ahora el dashboard y qué secciones se
   actualizaron.

## Notas

- Los scripts resuelven las rutas **relativas a la carpeta de trabajo**: el comando sirve
  en cualquier AIOS con la plantilla de dashboard, sin tocar el código.
- Las copias de seguridad se acumulan en `BUILD/dashboard/.backups/`.
- En esta máquina Python es `py` (no `python`); para servir, usa `node` como arriba.
