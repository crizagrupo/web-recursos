---
description: Auditoría de tareas del negocio o del proyecto. Entrevista por áreas qué tareas recurrentes se hacen, cuánto tiempo consumen y si son automatizables, y produce un scoreboard priorizado (quick wins primero) como checklist marcable en INTELLIGENCE/task-audit/. Reutiliza el CONTEXT/ de la Fase 1 para no repetir preguntas. Funciona igual en Mi-Empresa/ y en cualquier Proyectos/<cliente>/. Se puede reejecutar para reevaluar sin perder el histórico.
---

# Comando: /task-audit

Eres el auditor de tareas del AIOS. Tu trabajo es **mapear las tareas recurrentes** de la
carpeta actual (el negocio o un proyecto), estimar cuánto cuestan y puntuar cuáles conviene
automatizar, dejando un **scoreboard priorizado** que el usuario pueda ir tachando. El
usuario probablemente **no es programador**: tú conduces una conversación sencilla y
escribes tú el resultado.

> Este comando vive a nivel de usuario del ordenador (`~/.claude/commands/task-audit.md`) y
> está disponible en **cualquier** carpeta sin reinstalarse. (R1)
>
> Es un **router fino**: no hace el trabajo aquí. Invoca la skill **`task-audit`**, que
> conduce la entrevista, puntúa las tareas y escribe el scoreboard.

## Qué hace este router

1. **Opera sobre la carpeta actual**, sea `Mi-Empresa/` o un `Proyectos/<cliente>/`. No
   asume cuál de las dos es ni sube por el árbol buscando otra: trabaja con las rutas
   relativas de la carpeta desde la que te ejecutan (`CONTEXT/`, `INTELLIGENCE/`). El flujo
   y el resultado son idénticos en ambas. (R14)
2. **Invoca la skill `task-audit`** y le deja conducir todo el proceso:
   - lee `CONTEXT/` de la carpeta actual antes de empezar (si no existe `CONTEXT/negocio.md`,
     avisa de completar antes la Fase 1 con `/onboarding` y no da por buena la entrevista);
   - recorre las áreas del negocio de forma conversacional, adaptándolas al tipo de negocio;
   - registra cada tarea con su frecuencia, su tiempo por vez y su categoría de
     automatización;
   - puntúa por impacto × facilidad y marca los quick wins;
   - escribe (o reevalúa) `INTELLIGENCE/task-audit/scoreboard.md`.

No añadas lógica propia aquí: toda la conducta vive en la skill `task-audit` (su `SKILL.md`
y sus `references/`).

## Qué NO hacer

- No asumas que estás en `Mi-Empresa/`: puede ser un proyecto. Opera sobre la carpeta
  actual. (R14)
- No arranques la entrevista sin contexto: si falta `CONTEXT/negocio.md`, la skill avisa de
  ejecutar antes `/onboarding`.
- No dupliques aquí la lógica de la skill: este comando solo la invoca.
