---
description: Actualiza el panel de seguimiento (de negocio o de proyecto).
---

Actualiza el dashboard que corresponda al sitio donde estés.

1. **En un proyecto**: usa la skill `actualizar-dashboard` para sincronizar `BUILD/dashboard/datos.js` con el `ESTADO.md` del proyecto.
2. **A nivel negocio**: actualiza `BUILD/dashboard-negocio/` recorriendo las carpetas de `Escritorio/Proyectos/`, leyendo el `ESTADO.md` de cada una y agregando su estado.

Al terminar, indica cómo abrir el panel (ejecutar su `index.html` / `servir.js`).
