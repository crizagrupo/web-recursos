# Seguimientos pendientes

Clientes o leads sin contacto reciente que requieren seguimiento.
