# HISTÓRICO — {{NOMBRE_NEGOCIO}}

> Registro cronológico de hitos y decisiones del negocio (más reciente primero).
> El AIOS añade entradas aquí solo (por ejemplo, tras el primer commit de la Fase 2 del
> onboarding, o cada vez que usas `/commit`). No hace falta editarlo a mano.

---

<!-- Las entradas se añaden encima de esta línea, la más reciente primero. -->
