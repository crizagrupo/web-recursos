# ESTADO — {{NOMBRE_NEGOCIO}} (negocio)

> Última actualización: {{FECHA}}
> Lo actualiza la IA tras cualquier tarea relevante a nivel negocio.
> Registro cronológico → `HISTORICO.md`. Estado de cada proyecto → su propio `ESTADO.md`.

## Foco actual

{{FOCO_ACTUAL}}

## Proyectos activos

> El dashboard de negocio agrega el estado de cada carpeta en `Escritorio/Proyectos/`.

- TODO — listar proyectos en marcha.

## Pendientes a nivel negocio

- TODO

## Bloqueos

- Ninguno.
