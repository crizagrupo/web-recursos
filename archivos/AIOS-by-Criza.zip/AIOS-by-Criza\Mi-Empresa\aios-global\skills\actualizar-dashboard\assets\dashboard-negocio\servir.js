// ============================================================================
// servir.js — Servidor local para previsualizar / verificar el dashboard.
// ----------------------------------------------------------------------------
// Uso:   node servir.js [puerto]      (por defecto 8765)
// Luego abre la URL que imprime en el navegador (o con Playwright).
//
// ¿Por qué existe? Playwright bloquea el protocolo file://, así que para
// comprobar cambios en index.html / datos.js hay que servir esta carpeta por
// HTTP. Esto evita reescribir un servidor a mano cada vez.
//
// Nota: NO hace falta para usar el dashboard (basta doble clic en
// index.html). Esto es solo una herramienta de verificación al desarrollar.
// ============================================================================
const http = require("http"), fs = require("fs"), path = require("path"), url = require("url");

const dir  = __dirname;
const port = process.argv[2] || 8765;
const TIPOS = {
  ".html": "text/html", ".js": "text/javascript", ".css": "text/css",
  ".json": "application/json", ".png": "image/png", ".svg": "image/svg+xml",
  ".ico": "image/x-icon"
};

http.createServer((req, res) => {
  let p = decodeURIComponent(url.parse(req.url).pathname);
  if (p === "/") p = "/index.html";
  const fp = path.join(dir, p);
  fs.readFile(fp, (e, data) => {
    if (e) { res.writeHead(404); res.end("No encontrado"); return; }
    res.writeHead(200, { "content-type": TIPOS[path.extname(fp)] || "application/octet-stream" });
    res.end(data);
  });
}).listen(port, () => console.log("Dashboard en http://localhost:" + port + "/  (Ctrl+C para parar)"));
