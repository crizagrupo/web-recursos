# Dashboard de negocio — {{NOMBRE_NEGOCIO}}

Vista agregada de **todos los proyectos del negocio**: una tarjeta por proyecto con su nombre, avance, próxima acción y bloqueos. No necesita instalar nada ni conexión a internet.

## Cómo abrirlo

Doble clic en **`index.html`**. Se abre en el navegador (mejor con **Edge** o **Chrome**).

## Qué muestra

- **Cartera de proyectos**: una tarjeta por cada `Proyectos/<cliente>/` del negocio, con su estado (pendiente / en curso / completada), su barra de avance, su próxima acción y sus bloqueos.
- Si todavía no hay proyectos, muestra un aviso claro ("Aún no hay proyectos") en vez de datos inventados.

## Es de solo lectura

A diferencia del dashboard de cada proyecto, este **no se edita a mano**: se **regenera** siempre desde el estado real de los proyectos. Para actualizarlo, ejecuta **`/dashboard`** a nivel negocio (dentro de `Mi-Empresa/`): la skill `actualizar-dashboard` recorre cada `Proyectos/<cliente>/ESTADO.md` y reescribe `datos.js`.

## Archivos

- `index.html` — el dashboard (no hace falta tocarlo).
- `datos.js` — la cartera de proyectos (lo reescribe `/dashboard`; no lo edites a mano).
- `servir.js` — herramienta para desarrolladores (no hace falta para usarlo).
- `LEEME.md` — este archivo.
