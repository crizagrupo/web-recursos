# Integración — [HERRAMIENTA]

> Plantilla para documentar una conexión del negocio. La Fase 3 del onboarding
> (`onboarding-datos`) copia este archivo, lo renombra (p. ej. `google-drive.md`) y lo
> rellena por ti. **Nunca** se escriben aquí claves ni contraseñas: solo, si acaso, el
> **nombre** de una variable de entorno.

[Descripción en una línea: qué herramienta es y para qué la usa el negocio.]

## Para qué se usa
- [Caso de uso 1, en las palabras del negocio.]
- [Caso de uso 2, si aplica.]

## Tipo de conexión
- [ ] MCP (alcance de usuario) — servidor MCP oficial/conocido, registrado con `--scope user`.
- [ ] Conector a medida (patrón `mcp-integration`) — no había servidor MCP; se montó uno.

## Credenciales
- Autenticación gestionada por: [el cliente MCP (OAuth) / variable de entorno].
- Variable de entorno (solo el **nombre**, nunca el valor): [`NOMBRE_VARIABLE` o "no aplica"].
- Nunca se guardan claves, tokens ni contraseñas en este archivo ni en ningún archivo versionado.

## Qué aporta a la IA
- [Qué información o capacidad gana la IA gracias a esta conexión: qué puede leer, buscar o
  hacer ahora. Esto alimenta `key-metrics.md`.]

## Estado
- [ ] Conectada — fecha: [YYYY-MM-DD] · verificado: [qué se comprobó].
- [ ] Pendiente de conectar — se retomará al reejecutar `/onboarding` (Fase 3).
