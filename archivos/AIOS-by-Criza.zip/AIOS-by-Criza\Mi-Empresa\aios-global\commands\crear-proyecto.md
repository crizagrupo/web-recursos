---
description: Crea una carpeta nueva de proyecto (un cliente o iniciativa) hermana de Mi-Empresa/, con el mismo esquema de carpetas (más ligero) y su propio repositorio Git. Sustituye al paso manual de "copia la plantilla y renómbrala". Reutiliza la infraestructura y las conexiones ya resueltas a nivel de ordenador: no reinstala ni reconfigura nada. Al terminar, indica abrir la carpeta y ejecutar /onboarding para la Fase 1 de proyecto.
---

# Comando: /crear-proyecto

Eres el creador de proyectos del AIOS. Tu trabajo es montar, de forma automática, una carpeta
nueva para un **proyecto** (un cliente o una iniciativa interna del negocio), hermana de
`Mi-Empresa/`, con el mismo esquema de capas (más ligero) y su **propio repositorio Git**. El
usuario probablemente **no es programador**: tú haces el trabajo técnico; él solo da el nombre
y aprueba.

> Un proyecto es hermano del negocio, **no** parte de él: va en `Proyectos/<nombre>/`, nunca
> dentro de `Mi-Empresa/`. Tiene su propio repositorio Git (historial aislado por cliente).
> La herramienta (comandos, skills) y las conexiones se **heredan** de `~/.claude`; aquí no se
> reinstala ni se reconecta nada.

## Principios (no los rompas)

- **No crees nada antes de tener el nombre.** Primero pregunta (Paso 1).
- **Nunca dentro de `Mi-Empresa/`.** El proyecto es una carpeta **hermana**, dentro de
  `Proyectos/`.
- **No sobrescribas.** Si la carpeta ya existe, avisa y pide alternativa (Paso 4).
- **No reconfigures la identidad Git ni la cuenta de GitHub.** Reutiliza la que dejó la
  Fase 2 del onboarding del negocio. Aquí solo `git init` + primer commit de esta carpeta.
- **Nunca commitees secretos.** Antes del primer commit, asegura que `.env`, credenciales y
  claves quedan fuera (vía `.gitignore`).
- **Tono cercano.** Es un hito: el cliente estrena su carpeta en el AIOS.

## Paso 1 — Pedir el nombre (antes de crear nada) (R2)

Pregunta el **nombre del cliente o proyecto** en lenguaje normal (p. ej. "Bar Manolo",
"Rediseño web Acme", "Cliente Pérez"). No crees ninguna carpeta hasta tenerlo. Si el usuario
lo dio ya al invocar el comando, úsalo y confírmalo en una frase.

## Paso 2 — Derivar un nombre de carpeta seguro (R3)

A partir del nombre, deriva un nombre de carpeta **seguro para el sistema de archivos**, que
siga siendo **reconocible**:

- Pásalo a minúsculas y sustituye los espacios por guiones (`-`).
- Elimina o sustituye por `-` los caracteres inválidos en Windows/macOS/Linux:
  `< > : " / \ | ? *` y los de control; quita acentos si complican (p. ej. `Rediseño` →
  `rediseno`).
- Colapsa guiones repetidos y recorta guiones al principio/final.
- Ejemplos: "Bar Manolo" → `bar-manolo`; "Cliente Pérez" → `cliente-perez`.

Enséñale el nombre de carpeta resultante en una frase ("Lo crearé como `bar-manolo`"). Si al
usuario no le convence, acepta el que prefiera (saneándolo igual).

## Paso 3 — Ubicar el destino: `Proyectos/<nombre>/` hermana de `Mi-Empresa/` (R4)

1. **Localiza la carpeta del negocio** `Mi-Empresa/`: parte de la carpeta actual y sube por el
   árbol hasta encontrar una carpeta que contenga `Mi-Empresa/`. Esa carpeta contenedora es la
   **raíz del espacio de trabajo**.
   - Si te ejecutan **desde dentro de** `Mi-Empresa/`, la raíz es su carpeta padre (`..`).
   - Si te ejecutan desde dentro de un proyecto (`Proyectos/<x>/`), la raíz es `../..`.
   - Si **no** encuentras `Mi-Empresa/`, pregunta al usuario dónde está la carpeta de su
     negocio y no continúes hasta saberlo.
2. En esa raíz, **usa o crea** la carpeta `Proyectos/` (hermana de `Mi-Empresa/`). Si no
   existe, créala.
3. El proyecto irá en `Proyectos/<nombre>/`. **Nunca** lo crees dentro de `Mi-Empresa/`.

## Paso 4 — Comprobar colisión (no sobrescribir) (R5)

Antes de copiar nada, comprueba si `Proyectos/<nombre>/` **ya existe**:

- Si **existe**, avisa al usuario ("Ya hay una carpeta `Proyectos/<nombre>/`") y **no la
  toques**. Pide un **nombre alternativo** (vuelve al Paso 2 con el nuevo nombre) o una
  **confirmación explícita** de qué hacer. No sobrescribas ni mezcles contenido.
- Si **no existe**, continúa.

## Paso 5 — Copiar el molde y personalizarlo (R6, R7)

1. **Copia el molde** desde `Recursos/plantilla-proyecto/` de la `Mi-Empresa/` **ya localizada
   en el Paso 3** (es decir, `<Mi-Empresa>/Recursos/plantilla-proyecto/`; reutiliza esa misma
   localización, no busques de nuevo) a `Proyectos/<nombre>/` con todo su esquema ligero:
   - Carpetas de capas: `CONTEXT/ DATA/ INTELLIGENCE/ AUTOMATION/ BUILD/` (cada una con su
     `README.md`) y `harness/` (`build_backlog.json` vacío, `progress/.gitkeep`, `verify.ps1`).
   - Raíz: `CLAUDE.md ESTADO.md MAPA.md HISTORICO.md .gitignore`.
   - `BUILD/docs/_index.md` **vacío** (lo rellenará `/commit`, módulo 18) (R7).
   - `CONTEXT/` arranca **sin** `proyecto.md`: lo escribirá la Fase 1 del onboarding.
2. **Sustituye los marcadores** en todos los archivos copiados que los contengan (incluidos
   los de `BUILD/dashboard/`):
   - `{{NOMBRE_PROYECTO}}` → el nombre del cliente/proyecto (el original legible, p. ej.
     "Bar Manolo").
   - `{{NOMBRE_NEGOCIO}}` → el nombre real del negocio, **leído** de `Mi-Empresa/CONTEXT/negocio.md`
     (título) o, si no, de `Mi-Empresa/CLAUDE.md`. No lo inventes; si no lo encuentras,
     pregúntalo.
   - `{{PROVEEDOR}}` → el **mismo valor** que `{{NOMBRE_NEGOCIO}}` (el negocio es el proveedor de
     sus propios proyectos; no hay un tercero). Lo usa el dashboard del proyecto.
   - `{{SLUG}}` → el **nombre de carpeta seguro** derivado en el Paso 2 (p. ej. `bar-manolo`). Es
     la clave de `localStorage` del dashboard: debe ser única por proyecto.
   - `{{PIE_PROYECTO}}` → el nombre del negocio (crédito del pie de la barra lateral del dashboard;
     mismo valor que `{{NOMBRE_NEGOCIO}}`).
   Tras sustituir, **ningún archivo del proyecto** —incluidos los de `BUILD/dashboard/`
   (`index.html`, `datos.js`)— debe conservar ningún marcador `{{...}}` sin resolver. Antes de
   pasar al Paso 6, comprueba explícitamente (p. ej. una búsqueda de `{{` en todo el proyecto)
   que el resultado es **cero**; si queda alguno, resuélvelo antes de continuar.
3. **Aplicar la marca del negocio al dashboard del proyecto (si ya está definida).** Si existe
   `Mi-Empresa/CONTEXT/branding/guia-marca.md`, aplica sus colores al bloque `:root` de
   `Proyectos/<nombre>/BUILD/dashboard/index.html`, mapeando por rol (sigue la skill
   `identidad-visual` para el criterio):

   | Token de `guia-marca.md` | Variable del dashboard |
   | --- | --- |
   | `--primario` | `--azul` |
   | `--primario-oscuro` (o `--acento` si no hay oscuro) | `--azul-claro` |
   | `--bg` | `--gris-bg` |
   | `--surface` | `--panel` |
   | `--ink` | `--texto` |
   | `--muted` | `--texto-suave` |
   | `--line` | `--borde` |

   `--azul-bg` no tiene equivalente directo: genera un tinte muy claro del nuevo `--primario`.
   **No toques** `--verde/--verde-bg`, `--ambar/--ambar-bg`, `--rojo/--rojo-bg` ni `--sombra`:
   son semántica de estado, no identidad de marca. Si `guia-marca.md` **no** existe todavía (el
   negocio no ha completado ese tema de `/onboarding`), deja la paleta azul por defecto sin
   más: no es un error, solo falta ese tema.

## Paso 6 — Escribir el marcador de proyecto (R8)

Crea en la raíz del proyecto el archivo **`.aios-proyecto`** (es lo que hará que `/onboarding`
sepa que esta carpeta es un proyecto, no `Mi-Empresa/`). Contenido legible, por ejemplo:

```
tipo: proyecto
nombre: <nombre del cliente/proyecto>
negocio: <nombre del negocio>
creado: <fecha de hoy YYYY-MM-DD>
```

Este archivo **sí** se commitea (es parte de la identidad del proyecto).

## Paso 7 — Inicializar el repositorio Git propio (R9, R10, R11)

El proyecto tiene su **propio** repositorio, independiente del de `Mi-Empresa/`.

1. **No reconfigures la identidad ni la cuenta.** Reutiliza la identidad Git ya configurada en
   la Fase 2 del onboarding del negocio (`git config --global user.name` / `user.email`). Si,
   excepcionalmente, el ordenador **no** tuviera identidad Git (la Fase 2 no se completó),
   **no la configures aquí**: avisa al usuario de que complete antes `/onboarding` (Fase 2) en
   `Mi-Empresa/` y para. (Puedes confirmarlo también leyendo `~/.claude/aios/estado-usuario.md`.)
2. **Asegura el `.gitignore`** de la carpeta: el molde ya trae uno que excluye `.env`,
   `.env.*` y patrones de credenciales/claves. Comprueba que está presente; si faltara, complétalo.
   (R11)
3. `git init` **dentro de** `Proyectos/<nombre>/`.
4. Prepara los cambios (`git add -A`) y **verifica el área de stage** (`git status`,
   `git ls-files --cached`): si aparece cualquier `.env` o archivo con aspecto de credencial,
   **quítalo** del stage (`git rm --cached <archivo>`) y añádelo al `.gitignore` antes de
   seguir. No commitees hasta que el stage esté limpio de secretos. (R11)
5. **Primer commit** del contenido inicial, con un mensaje claro, p. ej.:
   `git commit -m "Proyecto <nombre>: estructura inicial del AIOS"`. (R9)

> Este `git init` es una acción trivial **por carpeta**; es distinto de configurar la
> identidad Git del ordenador (eso ya lo hizo la Fase 2 y no se repite). (R10)

## Paso 8 — Cerrar indicando el siguiente paso (R12)

Confírmale, en lenguaje llano, qué ha quedado hecho: "Tu proyecto `<nombre>` ya está creado en
`Proyectos/<nombre>/`, con su estructura y su primer punto de guardado."

Luego indícale el **siguiente paso**:

> Abre la carpeta `Proyectos/<nombre>/` en Claude Code y ejecuta **`/onboarding`**: te hará una
> entrevista corta sobre este cliente/proyecto (Fase 1 · Contexto) y escribirá su
> `CONTEXT/proyecto.md`. No te pedirá reconectar Git ni las fuentes de datos: ya están
> resueltas a nivel de tu ordenador.

## Qué NO hacer

- No crees ninguna carpeta antes de tener el nombre.
- No crees el proyecto **dentro** de `Mi-Empresa/`: siempre en `Proyectos/<nombre>/`, hermana.
- No sobrescribas una carpeta de proyecto existente.
- No reconfigures la identidad Git ni la cuenta de GitHub del ordenador: reutiliza la de la
  Fase 2. Aquí solo `git init` + primer commit de esta carpeta.
- No incluyas nunca `.env`, tokens ni claves en el primer commit.
- No arranques tú la Fase 1: solo indícale que ejecute `/onboarding` en la carpeta nueva.
