# Guía de Git y GitHub — explicado desde cero

Referencia para la skill `onboarding-infraestructura`. Sirve para explicar la
infraestructura a alguien que **no ha usado Git nunca**, sin dar por sabido ningún
concepto técnico. Usa estas analogías; no sueltes la guía entera de golpe: explica una
idea, comprueba que se entiende, y sigue.

Regla de oro: **cero jerga sin traducir**. Si dices "repositorio", "commit", "push",
"branch" o "remoto", tradúcelo siempre a la metáfora del videojuego.

---

## La idea en una frase

Vamos a poner tu negocio a salvo: cada vez que cambies algo, quedará un **punto de
guardado** al que siempre puedes volver, y una **copia en la nube** por si al ordenador le
pasa algo. Eso es todo lo que hacen Git y GitHub.

## Git = los puntos de guardado de un videojuego

Imagina un videojuego: antes de una parte difícil, **guardas la partida**. Si algo sale
mal, cargas ese guardado y vuelves a estar como antes.

**Git** hace justo eso con tu trabajo: guarda "fotos" del estado de tus archivos en
momentos concretos. Puedes volver a cualquiera de esas fotos cuando quieras. Nunca pierdes
nada, y nunca "rompes" el trabajo sin remedio: siempre hay un punto anterior al que volver.

- Git vive **en tu ordenador**. Funciona aunque no tengas internet.
- No borra nada: cada guardado se suma a la lista, no pisa al anterior.

## commit = crear un punto de guardado (con una nota)

Un **commit** es *crear un punto de guardado* de Git. Lo especial es que cada punto lleva
una **nota** que explica qué cambió ("añadí el contexto del negocio", "actualicé precios").

Así, la lista de commits es como el diario del proyecto: puedes leer qué pasó y cuándo, y
volver a cualquiera de esos momentos.

## GitHub = la nube donde se guarda la partida

Los puntos de guardado de Git están **solo en tu ordenador**. Si el disco se estropea o
pierdes el portátil, se van con él.

**GitHub** es una **nube** (una web, gratis para lo que necesitas) donde subes esos puntos
de guardado. Así:

- Tu trabajo está **respaldado**: aunque se rompa el ordenador, tu negocio sigue a salvo.
- Puedes recuperarlo desde otro ordenador.
- Queda un histórico ordenado de todo lo que has hecho.

Piensa en GitHub como el "guardado en la nube" de una consola moderna: la partida no
depende de una sola máquina.

## push = subir los puntos de guardado a la nube

**push** es *subir* a GitHub los puntos de guardado que has creado en tu ordenador. Haces
tus commits (guardas la partida) y, cuando quieras, haces push (la subes a la nube).

El orden natural es siempre: **commit → push**. Primero guardas, luego subes.

## Identidad Git = quién firma cada guardado

Cada punto de guardado se firma con **tu nombre y tu email**, para que quede claro quién
hizo cada cambio. Se configura una sola vez en el ordenador. No es una contraseña: es solo
la firma que aparece en el diario del proyecto.

## Lo que NO se sube nunca

Algunos archivos guardan **secretos**: contraseñas, claves de acceso a otras herramientas
(lo que suele ir en un archivo llamado `.env`). Esos **no se suben nunca** a la nube. El
AIOS los deja fuera automáticamente con una "lista de exclusión" (el archivo `.gitignore`),
para que un secreto no acabe publicado sin querer.

---

## Resumen para el usuario

| Palabra | Qué es, en cristiano |
|---------|----------------------|
| Git | Los puntos de guardado de tu trabajo, en tu ordenador. |
| commit | Crear un punto de guardado, con una nota de qué cambió. |
| GitHub | La nube donde subes esos guardados para que no se pierdan. |
| push | Subir tus guardados a la nube. |
| identidad Git | Tu nombre y email, la firma de cada guardado. |
| `.gitignore` | La lista de lo que NO se sube (secretos, `.env`). |
