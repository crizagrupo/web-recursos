# Proyecto — {{NOMBRE_PROYECTO}}

> Contexto específico de este proyecto/cliente. Lo general del negocio se hereda del nivel global.
> Estado: scaffold — responde las secciones `TODO`.

## Qué es este proyecto
TODO — cliente o iniciativa, en una frase.

## Alcance
TODO — qué entra y qué no.

## Objetivos
TODO — qué se quiere conseguir y para cuándo.

## Interlocutores
TODO — quién es quién por parte del cliente y por la nuestra.

## Particularidades
TODO — reglas, restricciones o contexto propio de este proyecto.
