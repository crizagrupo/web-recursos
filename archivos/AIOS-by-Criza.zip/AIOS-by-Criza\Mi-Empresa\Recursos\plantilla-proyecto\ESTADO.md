# ESTADO — Proyecto: {{NOMBRE_PROYECTO}}

> Estado vivo de este proyecto: en qué punto está y qué queda pendiente.
> El AIOS lo mantiene al día; no hace falta editarlo a mano.

## Fase actual

- **Onboarding de proyecto (Fase 1 · Contexto):** pendiente.
  Ejecuta `/onboarding` en esta carpeta para definir el contexto del proyecto.

## Qué está resuelto (heredado del negocio)

- **Infraestructura (Git/GitHub):** resuelta a nivel de ordenador (no se repite por proyecto).
- **Datos y conexiones (MCP):** resueltas a nivel de ordenador (no se repiten por proyecto).

> Estas dos se comprueban leyendo `~/.claude/aios/estado-usuario.md`. Si no constan
> resueltas, completa antes `/onboarding` en `Mi-Empresa/`.

## Pendientes

- Completar la Fase 1 (Contexto) de este proyecto con `/onboarding`.
