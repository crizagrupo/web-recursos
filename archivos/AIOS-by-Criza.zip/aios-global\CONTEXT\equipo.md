# Equipo — {{NOMBRE_NEGOCIO}}

> Capa 1 (Context). Perfiles, responsabilidades y quién decide.
> Estado: scaffold — responde las secciones `TODO`.

## Personas
TODO — una entrada por persona: nombre, rol, de qué se encarga.

## Quién decide
TODO — quién toma las decisiones operativas y quién las de negocio.
