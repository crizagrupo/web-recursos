# Áreas del negocio y rúbrica de puntuación

Referencia para la skill `task-audit`. Define **qué áreas recorrer** (con preguntas guía y
ejemplos por área), **cómo adaptarlas** al tipo de negocio, y **cómo puntuar** cada tarea.
La skill usa este catálogo para conducir la entrevista y para ordenar el scoreboard.

---

## Parte 1 — Catálogo de áreas

Recorre estas ocho áreas (R5). No las vuelques todas de golpe: ve **de una en una o de
pocas en pocas** (R7). Para cada área, usa las preguntas guía como punto de partida y los
ejemplos para inspirar al usuario, pero **adáptalos a su negocio** (ver Parte 2).

### 1. Marketing y contenido
- **Preguntas guía:** ¿Publicas o creas contenido con regularidad (redes, newsletter, blog,
  fotos, vídeos)? ¿Preparas material comercial (folletos, catálogos, promociones)? ¿Cada
  cuánto y quién lo hace?
- **Ejemplos de tareas:** programar posts de redes, redactar la newsletter, hacer fotos de
  producto, actualizar la web, montar una promoción.

### 2. Ventas y pipeline
- **Preguntas guía:** ¿Cómo entran los interesados y qué haces con cada uno? ¿Preparas
  presupuestos o propuestas? ¿Haces seguimiento de los que no cierran?
- **Ejemplos de tareas:** responder solicitudes de presupuesto, preparar propuestas, seguir
  leads fríos, actualizar el CRM, confirmar pedidos.

### 3. Entrega a cliente
- **Preguntas guía:** una vez que alguien te compra, ¿qué pasos das para entregarle lo que
  pagó y darle seguimiento? ¿Qué parte se repite igual cada vez?
- **Ejemplos de tareas:** preparar y enviar el pedido, coordinar una entrega/instalación,
  onboarding del cliente, enviar seguimiento posventa, recoger opiniones.

### 4. Operaciones y administración
- **Preguntas guía:** ¿Qué tareas de "papeleo" o de gestión interna repites? ¿Facturación,
  cobros, pagos, compras, inventario, cuadres?
- **Ejemplos de tareas:** emitir facturas, cuadrar caja, conciliar el banco, controlar
  stock, hacer pedidos a proveedores, gestionar cobros pendientes.

### 5. Equipo
- **Preguntas guía:** ¿Coordinas a personas? ¿Turnos, tareas, nóminas, formación,
  seguimiento del trabajo del equipo?
- **Ejemplos de tareas:** montar el cuadrante de turnos, repartir tareas, preparar nóminas,
  formar a alguien nuevo, revisar el trabajo hecho.

### 6. Datos y reporting
- **Preguntas guía:** ¿Miras números con regularidad (ventas, gastos, resultados)? ¿Preparas
  informes para ti o para otros? ¿A mano en Excel?
- **Ejemplos de tareas:** montar el informe de ventas semanal, calcular márgenes, preparar un
  cuadro de mando, exportar y cruzar datos de varias herramientas.

### 7. Comunicación
- **Preguntas guía:** ¿Qué mensajes repites (a clientes, proveedores, equipo)? ¿Respuestas
  parecidas una y otra vez? ¿Recordatorios, confirmaciones, avisos?
- **Ejemplos de tareas:** responder las mismas preguntas de clientes, confirmar citas,
  mandar recordatorios, avisos de estado de pedido, atención por WhatsApp/email.

### 8. Estratégico / creativo
- **Preguntas guía:** ¿Qué haces que requiere tu criterio, decisión o creatividad y no se
  delega fácil? Sirve para marcar lo que **NO** se automatiza y despejar el foco.
- **Ejemplos de tareas:** decidir precios, diseñar un producto nuevo, negociar con un
  cliente grande, definir la estrategia del trimestre, la parte de oficio manual del negocio
  (cocinar, cortar el pelo, operar, diseñar).

---

## Parte 2 — Adaptar y omitir áreas según el negocio (R6)

Antes de entrevistar, lee el `CONTEXT/` de la carpeta y **ajusta** el recorrido al tipo de
negocio que describe:

- **Adapta los ejemplos** de cada área al sector real. Ej.: en un obrador que vende a bares,
  "Entrega a cliente" = preparar y repartir pedidos; en una consultora = entregar el informe
  y presentarlo.
- **Omite un área que claramente no aplique.** Ej.: un autónomo sin personas a cargo no tiene
  área "Equipo"; un negocio sin actividad comercial de captación puede tener "Ventas y
  pipeline" muy reducida. Si dudas, pregunta en una frase en vez de dar por hecho que no
  aplica.
- **No repreguntes lo que ya sabes.** Si `CONTEXT/procesos.md` ya describe cómo entra y se
  entrega un cliente, o `CONTEXT/servicios-pricing.md` qué vende, parte de ahí: pregunta solo
  el detalle que falta para puntuar (frecuencia, tiempo, categoría), no el "qué hace". (R4)
- **Señala el punto de partida.** Al abrir un área, reconoce lo que ya consta ("Por tu
  contexto, veo que repartís a bares por las mañanas; ¿cuánto tiempo os lleva preparar esos
  pedidos y con qué frecuencia?").

---

## Parte 3 — Rúbrica de puntuación

Para **cada tarea** recogida, registra tres cosas y deriva su prioridad.

### 3.1 Datos que registras por tarea
- **Frecuencia:** cada cuánto se hace (varias veces al día, diaria, semanal, quincenal,
  mensual, trimestral…). (R8)
- **Tiempo por vez:** cuánto consume cada vez, en minutos u horas aproximados. (R8)
- **Categoría de automatización** (una de las cuatro) (R9):

| Categoría | Qué significa | Facilidad |
|-----------|---------------|-----------|
| **Totalmente automatizable** | Se puede dejar que lo haga el sistema casi sin intervención | **Alta** |
| **Parcialmente automatizable** | Se automatiza una parte; el resto necesita a una persona | **Media** |
| **No automatizable todavía** | Hoy no, pero podría serlo con más medios/madurez | **Baja** |
| **Solo humano** | Requiere criterio, trato o manos humanas; no es objetivo de automatización | **No aplica** |

### 3.2 Impacto = tiempo × frecuencia (horas/mes) (R10)
Convierte la frecuencia a **veces por mes** y multiplícala por el tiempo por vez en horas:

`impacto (h/mes) = (tiempo_por_vez_min ÷ 60) × veces_al_mes`

Conversión de frecuencia a veces/mes (aprox., días laborables):

| Frecuencia | Veces/mes (aprox.) |
|------------|--------------------|
| Varias veces al día (×N) | 22 × N |
| Diaria | 22 |
| Varias veces por semana (×N) | 4,3 × N |
| Semanal | 4,3 |
| Quincenal | 2 |
| Mensual | 1 |
| Trimestral | 0,33 |

Así una tarea **corta pero muy frecuente** (5 min, diaria → ~1,8 h/mes) puede pesar tanto
como una **larga y esporádica** (2 h, mensual → 2 h/mes).

Bandas de impacto (para clasificar y ordenar):

| Banda | Umbral (h/mes) |
|-------|----------------|
| **Alto** | ≥ 8 |
| **Medio** | 2 – 8 |
| **Bajo** | < 2 |

### 3.3 Facilidad
Se deriva de la categoría (tabla de 3.1): totalmente → **alta**, parcialmente → **media**,
no todavía → **baja**, solo humano → **no aplica** (queda fuera de la priorización de
automatización).

### 3.4 Prioridad y quick wins (R10, R11)
Combina impacto y facilidad en una **prioridad** para ordenar:

`prioridad = impacto_h_mes × factor_facilidad`  · factor: alta = 1,0 · media = 0,6 · baja = 0,3

- Ordena las tareas automatizables (totalmente / parcialmente / no todavía) por prioridad
  **descendente**.
- **Quick win** = impacto **alto** (≥ 8 h/mes) **y** facilidad **alta** (totalmente
  automatizable). Son la mejor relación esfuerzo/retorno: van **primero** en el scoreboard.
- Las tareas **solo humano** quedan fuera de la priorización: no se puntúan para
  automatizar; se listan aparte como referencia (lo que el negocio hace y seguirá haciendo a
  mano).

> Estas fórmulas son una guía para ordenar con criterio, no una ciencia exacta. Usa números
> redondos y el sentido común; lo importante es que el usuario vea, de un vistazo, por dónde
> empezar.
