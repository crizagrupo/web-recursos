# AUTOMATION — Automatizaciones del proyecto

Capa 4 del AIOS a nivel de proyecto. Aquí viven las **automatizaciones** específicas de este
cliente/iniciativa (tareas que se ejecutan solas o bajo demanda: procesos, generadores,
sincronizaciones…).

Arranca vacía. Cada automatización se construye con el **flujo del harness** (nada se
construye sin aprobación) y vive en su subcarpeta: `AUTOMATION/<nombre>/`, con su `README.md`
en lenguaje sencillo.

> Construcción → `~/.claude/harness/AGENTS.md`. La cola de construcción de este proyecto está
> en `harness/build_backlog.json`.
