# Guía de branding — cómo escribir `CONTEXT/branding/guia-marca.md`

Referencia para el **séptimo tema** de la skill `onboarding-contexto` (identidad visual y
tono de voz). Define **el esquema de secciones** que debe tener `CONTEXT/branding/guia-marca.md`.

> **Esto es un esquema de formato, NO de valores.** Las secciones y los tokens de abajo son
> el molde. El contenido —colores, tipografías, adjetivos, ejemplos de frase— es **siempre
> el del cliente**, confirmado en la entrevista o extraído de un documento de marca suyo.
> **Nunca** copies los valores de la guía de marca de Criza (navy, Playfair, "premium /
> minimalista", sus ejemplos de frase, etc.): son ejemplos de cómo se rellena cada sección,
> no la respuesta. Si copias los valores de Criza, el archivo está mal.

Reglas comunes (igual que el resto de `CONTEXT/`):
- Título: `# Guía de marca — <NOMBRE_NEGOCIO real>`.
- Todo el contenido es real del cliente. **Cero `TODO`, cero `{{...}}`, cero secciones
  vacías.** Si algo no aplica, dilo explícito ("Sin tipografía propia definida: …").
- Cada valor sale de lo que el usuario confirma o de un documento suyo. Nada inventado.

---

## Secciones obligatorias

### 1. Personalidad
Adjetivos de marca (3-5) + una o dos frases de carácter. Si el usuario cita referencias
("como X marca") anótalas. Ejemplo de **formato** (no de valores): *"Adjetivos · una frase
que explica el carácter · referencias opcionales."*

### 2. Dirección visual
Principios visuales en 2-4 viñetas: cantidad de aire/espacio, monocromo vs. color,
nivel de adorno (sobrio vs. expresivo), sensación general.

### 3. Color
Tabla con los tokens base y los colores de marca. Cada fila: token · hex · uso.

| Token | Hex | Uso |
| --- | --- | --- |
| `--bg` | `#…` | Fondo de página. |
| `--surface` | `#…` | Tarjetas y superficies. |
| `--ink` | `#…` | Texto principal. |
| `--muted` | `#…` | Texto secundario. |
| `--line` | `#…` | Bordes y separadores. |
| `--primario` | `#…` | **Color de marca principal**: botones y acentos fuertes. |
| `--primario-oscuro` | `#…` | Hover y degradados (variante más oscura del principal). |
| `--acento` | `#…` | Acento puntual (enlaces, micro-detalles), si el cliente tiene uno. |

- El **color de marca principal** (`--primario`) es el que va a `branding.json` como
  `color_primario`.
- El **color de marca secundario/oscuro** (`--primario-oscuro` o el acento) va como
  `color_tabla_cabecera`. Si el cliente solo tiene un color de marca, usa una variante más
  oscura del principal o el mismo color, y **confírmalo** con el usuario.
- Renombra los tokens de marca al vocabulario del cliente si lo prefiere; los tokens base
  (`--bg/--surface/--ink/--muted/--line`) sí conviene mantenerlos.

### 4. Tipografía
- **Titulares:** familia + pesos, si la tiene.
- **Cuerpo y UI:** familia + pesos.
Si no tiene tipografías propias, dilo explícito y, si procede, propón una dirección (ver la
regla de "nada inventado / dirección propuesta" en `SKILL.md`).

### 5. Formas y profundidad
Radio de esquinas (cuadrado / suave / muy redondeado) y nivel de sombra (plano / sutil /
marcado).

### 6. Imágenes y gráficos
Uso de fotografía (sí/no, estilo), apoyos visuales (formas, degradados) y estilo de
iconografía (línea fina, relleno, etc.).

### 7. Tono de voz
Descripción del tono (cercano/formal, directo/detallado, con o sin emojis) + **ejemplos
reales del cliente**: un titular y una frase de apoyo escritos en su voz.

### 8. Logo
Ruta del archivo guardado (`CONTEXT/branding/logo.<ext>`, conservando la extensión que suba
el cliente) y una nota de cómo usarlo (sobre fondo claro/oscuro, con o sin recorte).

---

## Nota para el módulo 25 (`aios2-propuestas`)
La skill `propuestas` **no** vuelve a entrevistar sobre branding. Lee este mismo
`CONTEXT/branding/guia-marca.md` + `logo.<ext>` y reutiliza el `branding.json` que ya deja
listo este módulo vía `scripts/aplicar-branding.py`. Si necesita más campos que los cuatro
actuales (`empresa`, `email`, `color_primario`, `color_tabla_cabecera`), se amplían en
`aplicar-branding.py` (fuente única de la propagación), no reintroduciendo preguntas de marca.
