# Informes

Informes con formato profesional (auditoría, tareas o genérico). Formato: `YYYY-MM-DD-nombre.docx`.
Se generan con el comando `/informe` (skill ya instalada).
