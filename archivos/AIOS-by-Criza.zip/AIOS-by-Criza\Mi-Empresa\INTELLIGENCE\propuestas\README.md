# Propuestas

Propuestas comerciales generadas para tus clientes o proyectos. Formato: `YYYY-MM-DD-nombre.html`.
Se generan con el comando `/propuestas` (skill ya instalada).
