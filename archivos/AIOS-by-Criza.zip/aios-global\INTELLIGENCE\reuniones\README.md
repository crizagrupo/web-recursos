# Reuniones

Actas y resúmenes de reuniones. Formato: `YYYY-MM-DD-nombre.md`.
Flujo: transcripción → resumen + pendientes → aquí.
