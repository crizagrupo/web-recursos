---
name: mcp-integration
description: Patrón de referencia para conectar una herramienta externa a la IA por MCP (Model Context Protocol). Explica los tipos de servidor MCP (stdio local y HTTP/SSE remoto), cómo registrarlos en Claude Code con el alcance correcto, cómo gestionar la autenticación sin exponer credenciales, y cómo montar un conector a medida cuando no existe un servidor MCP oficial para la herramienta. La usan otras skills (p. ej. onboarding-datos) cuando hay que montar un conector a medida.
---

# Skill: mcp-integration (patrón de conexión por MCP)

> Skill de referencia del **AIOS Starter Kit**, instalada a nivel de usuario como parte de
> la herramienta. Define el "cómo" técnico de conectar una herramienta por MCP. Otras skills
> (como `onboarding-datos`) se **remiten** a ella; no la redefinen.

Su trabajo es dar el patrón para **conectar una herramienta externa a la IA** por MCP: qué
tipo de servidor usar, cómo registrarlo, cómo autenticar sin guardar secretos, y cómo montar
un conector a medida cuando no hay servidor oficial.

## 1. Qué es MCP

**MCP (Model Context Protocol)** es un protocolo estándar para que la IA se conecte a
herramientas y fuentes de datos externas (Drive, un CRM, una base de datos, una API). Un
**servidor MCP** expone las capacidades de una herramienta (leer archivos, buscar, crear
registros…) como **tools** que la IA puede invocar. El **cliente MCP** (Claude Code) se
conecta a esos servidores y usa sus tools.

Ventaja frente a un script a medida: conectas una vez y la IA usa la herramienta cuando la
necesita, sin mantener un pipeline propio por cada integración.

## 2. Antes de montar nada: ¿ya existe un servidor MCP?

Comprueba primero si la herramienta tiene un **servidor MCP oficial o conocido**. Muchas
plataformas (almacenamiento tipo Google Drive / Microsoft 365, algunas de bases de datos y
productividad) ya lo tienen. Si existe, **úsalo**: es menos trabajo y más robusto que un
conector a medida. Solo montas un conector a medida (sección 5) cuando **no** hay servidor
para esa herramienta.

## 3. Tipos de servidor MCP

| Tipo | Cómo corre | Cuándo se usa |
|------|-----------|----------------|
| **stdio** | Un comando local que Claude Code arranca (p. ej. `npx <paquete>`) y con el que habla por entrada/salida estándar | Servidores que se ejecutan en la máquina del usuario (paquetes npm/uvx, conectores locales) |
| **HTTP / SSE** | Un servicio remoto al que Claude Code se conecta por URL (Server-Sent Events / HTTP streaming) | Servidores alojados (SaaS) que exponen un endpoint MCP |

## 4. Registrar un servidor MCP en Claude Code

Alta con `claude mcp add`. Lo decisivo es el **alcance** (`--scope`):

| Alcance | Dónde se guarda | ¿Otras carpetas lo heredan? |
|---------|-----------------|------------------------------|
| `user` | Configuración del usuario del ordenador | **Sí, todas** |
| `project` | `.mcp.json` en la carpeta (compartible) | Solo esa carpeta / quien la comparta |
| `local` | Config privada de esa carpeta | No |

Para conexiones que deben servir a todo el ordenador, usa **alcance de usuario**:

```
# Servidor stdio (comando local):
claude mcp add --scope user <nombre> -- <comando> [args...]

# Servidor remoto HTTP/SSE:
claude mcp add --scope user --transport sse <nombre> <url>
```

Comprueba el alta con `claude mcp list` y, si hace falta, `claude mcp get <nombre>`.

## 5. Montar un conector a medida (no hay servidor MCP)

Cuando la herramienta no tiene servidor MCP, se monta uno a medida que exponga sus
capacidades como tools MCP. Patrón mínimo:

1. **Definir el alcance útil.** Qué necesita leer/hacer la IA con esa herramienta (p. ej.
   "listar y leer notas", "buscar contactos"). No expongas más de lo necesario.
2. **Elegir el transporte.** stdio (un pequeño servidor local que hable con la API de la
   herramienta) suele ser lo más simple para el caso de un no-técnico.
3. **Implementar las tools** contra la API de la herramienta, siguiendo el SDK de MCP. Cada
   tool = una capacidad (buscar, leer, crear).
4. **Autenticación** (sección 6): la clave/token va en variable de entorno, nunca en el
   código ni en el repo.
5. **Registrar** el conector con `claude mcp add --scope user …` (sección 4).
6. **Documentar** en `DATA/integraciones/<herramienta>.md`: para qué se usa, tipo (conector a
   medida), estado y el **nombre** de la variable de entorno (no su valor).

## 6. Autenticación y credenciales (regla dura)

- **OAuth** (Google Drive, Microsoft 365…): el flujo lo gestiona el cliente MCP / el servidor.
  El usuario hace login en el navegador cuando se le pide; las credenciales las guarda el
  sistema. **No** se guarda nada en archivos del repo.
- **Claves de API / tokens** (conectores a medida): van en **variables de entorno** o en el
  gestor de credenciales del sistema. En la documentación se registra solo el **nombre** de
  la variable, nunca el valor.
- **Nunca** commitees claves, tokens ni contraseñas. Ningún archivo versionado (código,
  `.md`, `.json`) debe contener un secreto en claro.

## 7. Usar las tools ya conectadas

Una vez registrado el servidor, sus tools quedan disponibles para la IA en cualquier carpeta
(si el alcance es de usuario). La IA las invoca cuando la tarea lo requiere (leer un
documento del Drive, buscar un contacto en el CRM…). No hace falta que el usuario haga nada
más: la conexión es persistente.

## Qué NO hacer

- No montes un conector a medida si ya existe un servidor MCP oficial para la herramienta.
- No registres servidores con alcance de carpeta/proyecto cuando deban servir a todo el
  ordenador: usa alcance de usuario.
- No guardes nunca claves, tokens ni contraseñas en el código ni en archivos versionados.
- No expongas más capacidades de las necesarias en un conector a medida.
