# Índice de INTELLIGENCE

Aquí vive el **conocimiento vivo** del negocio: lo que la IA consulta y va acumulando
con el uso (reuniones, informes, propuestas, auditorías de tareas). No es documentación
técnica de sistemas; eso vive en `BUILD/docs/`.

> Las subcarpetas se crean solas al primer uso. Si alguna aún no existe, aparecerá la
> primera vez que se genere contenido de ese tipo.

## Subcarpetas

| Carpeta | Qué se guarda |
| --- | --- |
| `reuniones/` | Actas y resúmenes de reuniones (`YYYY-MM-DD-nombre.md`). |
| `informes/` | Informes generados con el comando `/informe` (`.docx`). |
| `propuestas/` | Propuestas comerciales generadas para clientes o proyectos. |
| `task-audit/` | Resultados de `/task-audit`: scoreboard de tareas automatizables. Se crea al primer uso. |
