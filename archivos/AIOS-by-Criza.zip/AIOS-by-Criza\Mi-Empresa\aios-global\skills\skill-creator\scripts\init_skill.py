#!/usr/bin/env python3
# init_skill.py - Andamia una skill nueva del AIOS.
# Crea la carpeta <nombre>/ en la ubicacion elegida y escribe SKILL.md a partir de
# la plantilla references/plantilla-SKILL.md, rellenando 'name' y 'description'.
# Crea scripts/ y/o references/ SOLO si se piden (nunca vacias sin motivo).
#
# Uso:
#   py init_skill.py --name <kebab-case> --description "<que hace y cuando>" \
#       [--scope user|project] [--with-scripts] [--with-references] [--dest <carpeta>]
#
#   --scope user     -> ~/.claude/skills/<nombre>/   (por defecto: transversal)
#   --scope project  -> .claude/skills/<nombre>/     (carpeta actual: especifica de proyecto)
#   --dest <carpeta> -> crea <nombre>/ dentro de esa carpeta (sobrescribe --scope;
#                       util para pruebas o para una ubicacion a medida)
#   --with-scripts     crea la subcarpeta scripts/
#   --with-references  crea la subcarpeta references/
#
# Solo usa la libreria estandar (portable Windows / Mac).

import argparse
import re
import sys
from pathlib import Path

NAME_MAX = 64
DESCRIPTION_MAX = 1024
KEBAB_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")

SCRIPT_DIR = Path(__file__).resolve().parent
TEMPLATE = SCRIPT_DIR.parent / "references" / "plantilla-SKILL.md"

GITKEEP_NOTE = (
    "# Marcador para que la carpeta se conserve en Git hasta que se anada el primer\n"
    "# archivo real. Borralo cuando pongas aqui el contenido de la skill.\n"
)


def parent_dir(scope, dest):
    if dest:
        return Path(dest).expanduser().resolve()
    if scope == "user":
        return (Path.home() / ".claude" / "skills").resolve()
    # scope == "project"
    return (Path.cwd() / ".claude" / "skills").resolve()


def main(argv):
    ap = argparse.ArgumentParser(
        description="Andamia una skill nueva del AIOS."
    )
    ap.add_argument("--name", required=True, help="Nombre en kebab-case (= nombre de carpeta).")
    ap.add_argument("--description", required=True, help="Que hace y cuando se usa.")
    ap.add_argument("--scope", choices=["user", "project"], default="user",
                    help="user = ~/.claude/skills (por defecto); project = .claude/skills de la carpeta actual.")
    ap.add_argument("--with-scripts", action="store_true", help="Crea la subcarpeta scripts/.")
    ap.add_argument("--with-references", action="store_true", help="Crea la subcarpeta references/.")
    ap.add_argument("--dest", default=None, help="Carpeta padre a medida (sobrescribe --scope).")
    args = ap.parse_args(argv[1:])

    name = args.name.strip()
    description = args.description.strip()

    # Validaciones de entrada (fallar pronto y claro).
    problemas = []
    if not KEBAB_RE.match(name):
        problemas.append(
            "El nombre no esta en kebab-case (solo minusculas, numeros y guiones): '" + name + "'."
        )
    if len(name) > NAME_MAX:
        problemas.append("El nombre excede " + str(NAME_MAX) + " caracteres.")
    if not description:
        problemas.append("La descripcion no puede estar vacia.")
    if len(description) > DESCRIPTION_MAX:
        problemas.append("La descripcion excede " + str(DESCRIPTION_MAX) + " caracteres.")
    if not TEMPLATE.is_file():
        problemas.append("No se encuentra la plantilla: " + str(TEMPLATE))
    if problemas:
        sys.stderr.write("No se puede andamiar la skill:\n")
        for p in problemas:
            sys.stderr.write("  - " + p + "\n")
        return 2

    parent = parent_dir(args.scope, args.dest)
    skill_dir = parent / name
    skill_md = skill_dir / "SKILL.md"

    if skill_md.exists():
        sys.stderr.write("Ya existe " + str(skill_md) + " - no se sobrescribe. Aborta.\n")
        return 3

    # Crear carpeta de la skill y SKILL.md desde la plantilla.
    skill_dir.mkdir(parents=True, exist_ok=True)
    plantilla = TEMPLATE.read_text(encoding="utf-8")
    contenido = plantilla.replace("{{NAME}}", name).replace("{{DESCRIPTION}}", description)
    skill_md.write_text(contenido, encoding="utf-8")

    creadas = []
    if args.with_scripts:
        d = skill_dir / "scripts"
        d.mkdir(exist_ok=True)
        (d / ".gitkeep").write_text(GITKEEP_NOTE, encoding="utf-8")
        creadas.append("scripts/")
    if args.with_references:
        d = skill_dir / "references"
        d.mkdir(exist_ok=True)
        (d / ".gitkeep").write_text(GITKEEP_NOTE, encoding="utf-8")
        creadas.append("references/")

    print("Skill andamiada en: " + str(skill_dir))
    print("  - SKILL.md (rellena el cuerpo: que hace / cuando se usa / protocolo)")
    for c in creadas:
        print("  - " + c + " (anade aqui su contenido; no la dejes vacia)")
    print("Siguiente: completa el cuerpo y valida con quick_validate.py sobre esta carpeta.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
