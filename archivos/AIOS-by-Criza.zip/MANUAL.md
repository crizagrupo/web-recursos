# AIOS by Criza — Manual de instalación y uso

Sistema operativo de IA para tu negocio. Una capa que se instala sobre Claude Code y convierte la IA en el centro de operación de tu empresa: conoce tu negocio, gestiona tus proyectos, automatiza tareas y construye tus propias herramientas.

Este manual te lleva desde cero —sin nada instalado— hasta tener el AIOS funcionando y tu primer proyecto en marcha. No necesitas saber programar.

---

## 1. Qué es y cómo funciona

El AIOS trabaja en **dos niveles**:

- **Nivel negocio (global).** El cerebro. Vive en la configuración de tu equipo y está activo siempre, trabajes donde trabajes. Contiene la identidad de tu negocio, sus integraciones, sus herramientas y la vista de todos tus proyectos.
- **Nivel proyecto (local).** Una carpeta por cada cliente o iniciativa. Hereda todo lo del negocio y añade su propio registro (estado, mapa, histórico) y sus tareas.

Idea base: **el negocio se define una vez; los proyectos se crean tantos como necesites.** Cada proyecto ya "sabe" quién eres porque hereda el cerebro.

El AIOS distingue dos formas de trabajar:

- **Operar** — preguntar, consultar, registrar el día a día. Respuesta directa.
- **Construir** — crear automatizaciones o herramientas nuevas. Sigue un flujo controlado en el que **tú apruebas antes de que se construya nada**.

---

## 2. Requisitos previos

Antes de instalar el AIOS necesitas tres cosas. Se instalan una sola vez.

### 2.1. Cuenta de Claude
Una suscripción activa de Claude (Pro o superior) en [claude.ai](https://claude.ai). Es la que da acceso a la IA y a las integraciones (Google Drive, Microsoft 365, Figma, etc.).

### 2.2. Claude Code
La aplicación sobre la que corre el AIOS.

- **Opción recomendada (no técnica):** descarga la **app de escritorio de Claude Code** para Windows o Mac desde [claude.com/claude-code](https://claude.com/claude-code) e instálala como cualquier programa.
- **Opción por terminal:** si te manejas con la línea de comandos, `npm install -g @anthropic-ai/claude-code`.

Al abrirla por primera vez, inicia sesión con tu cuenta de Claude.

### 2.3. Node.js
Necesario para el dashboard y las verificaciones internas. Descarga la versión **LTS** desde [nodejs.org](https://nodejs.org) e instálala con las opciones por defecto.

Para comprobar que quedó bien, abre una terminal y escribe `node --version`: debe responder con un número de versión.

---

## 3. Instalación del AIOS

### 3.1. Descargar y descomprimir
Descarga el archivo `AIOS-by-Criza.zip` y descomprímelo. Verás dos piezas:

- `aios-global/` — el cerebro del negocio.
- `plantilla-proyecto/` — el molde para crear cada proyecto.

### 3.2. Colocar el cerebro en su sitio
El contenido de `aios-global/` va dentro de la **carpeta de configuración de Claude Code**:

- **Windows:** `C:\Users\TU-USUARIO\.claude`
- **Mac:** `/Users/TU-USUARIO/.claude`

> La carpeta `.claude` está oculta. En Windows activa "Elementos ocultos" en el Explorador; en Mac pulsa `Cmd + Shift + .` para verla.

Copia **el contenido** de `aios-global/` dentro de `.claude`. Si ya tenías archivos ahí (por ejemplo un `CLAUDE.md` con tus preferencias), **no se borran: se fusionan**. Ante la duda, haz una copia de seguridad de tu `.claude` antes.

### 3.3. Definir tu negocio
Abre la carpeta `.claude/CONTEXT/` y rellena los archivos. Cada uno tiene preguntas guía (marcadas como `TODO`) que solo tienes que responder:

| Archivo | Qué poner |
| --- | --- |
| `negocio.md` | Qué hace tu empresa, propuesta de valor, diferencial |
| `servicios-pricing.md` | Qué vendes y a qué precio |
| `equipo.md` | Quién es quién y quién decide |
| `clientes-objetivo.md` | A quién te diriges |
| `estrategia.md` | Objetivos y prioridades |
| `procesos.md` | Cómo entra un cliente y cómo se le entrega |

No hace falta que lo hagas a mano: puedes abrir Claude Code y pedirle *"ayúdame a rellenar el CONTEXT de mi negocio"*, e irá preguntándote.

### 3.4. Personalizar la identidad
En el archivo `.claude/CLAUDE.md` sustituye el nombre del negocio y del responsable donde aparezcan los marcadores `{{NOMBRE_NEGOCIO}}` y `{{DUENO}}`. También puedes pedírselo a la IA: *"personaliza la plantilla con estos datos…"*.

### 3.5. Conectar integraciones (opcional)
Si tu negocio usa plataformas (un CRM, base de datos, etc.):

1. Copia el archivo `.env.example` y renómbralo a `.env`.
2. Pega ahí tus credenciales (claves de API). El `.env` **nunca se comparte ni se sube a ningún sitio**.
3. Documenta cada plataforma en `.claude/DATA/integraciones/` usando la plantilla incluida.

Las integraciones que ya vienen con tu cuenta de Claude (Google Drive, Microsoft 365, Figma, Canva…) se activan desde la propia app de Claude, no requieren claves aquí.

### 3.6. Comprobar que funciona
Abre cualquier carpeta en Claude Code y pregunta: *"¿quién soy y cómo trabajas?"*. Si responde describiendo tu negocio, el cerebro está bien instalado.

---

## 4. Crear tu primer proyecto

Cada cliente o iniciativa interna es un proyecto. Para crear uno:

1. Crea (si no existe) una carpeta `Proyectos` en tu Escritorio. **Todos tus proyectos cuelgan de aquí** — es lo que permite la vista de negocio.
2. Copia la carpeta `plantilla-proyecto/` dentro de `Proyectos/` y renómbrala con el nombre del proyecto (ej. `Proyectos/Cliente-Acme`).
3. Ábrela en Claude Code.

El proyecto ya hereda todo tu negocio. Dentro tiene su propio registro:

- `ESTADO.md` — cómo va el proyecto ahora mismo.
- `MAPA.md` — índice de dónde está cada cosa.
- `HISTORICO.md` — lo que se ha ido haciendo.
- Las carpetas de trabajo (`CONTEXT`, `DATA`, `INTELLIGENCE`, `AUTOMATION`, `BUILD`).

Rellena el `CONTEXT` del proyecto solo con lo específico de ese cliente; lo general del negocio ya lo conoce.

---

## 5. Cómo usarlo en el día a día

Hablas con la IA en lenguaje normal. Ella reconoce si quieres operar o construir.

### Operar (consultar y registrar)
- *"¿Cómo va el proyecto Acme?"*
- *"Guarda esta reunión: [notas]"* → la archiva y extrae los pendientes.
- *"Resúmeme el estado de todos mis proyectos."*
- *"Actualízame el estado tras esta llamada."*

### Construir (crear algo nuevo)
- *"Automatiza el seguimiento de clientes sin contacto."*
- *"Móntame una herramienta para generar propuestas."*

Cuando pides construir, la IA **no empieza a la primera**. Primero investiga, escribe un plan y **te lo presenta para que lo apruebes**. Solo cuando dices "aprobado" construye, y al terminar verifica que funciona y lo registra. Nunca fabrica nada a tus espaldas.

### Comandos
Escribiendo `/` accedes a comandos directos. Los principales:

| Comando | Qué hace |
| --- | --- |
| `/estado` | Resumen rápido del proyecto o del negocio |
| `/informe` | Genera un informe con formato profesional a partir de notas o reuniones |
| `/dashboard` | Actualiza el panel de seguimiento |

---

## 6. El dashboard de seguimiento

El AIOS lleva dos vistas:

- **Dashboard de negocio** — recorre todos los proyectos de tu carpeta `Proyectos/` y muestra el estado de cada uno en un solo panel. Lo actualizas con `/dashboard` desde el nivel negocio.
- **Dashboard de proyecto** — el detalle de un proyecto concreto, alimentado por su `ESTADO.md`.

Para abrir un panel, ejecuta su archivo y se mostrará en tu navegador.

---

## 7. Preguntas frecuentes

**¿Necesito saber programar?**
No. Todo se hace hablando con la IA en lenguaje normal. Los pasos técnicos (instalar, copiar carpetas) son los del manual.

**¿Mis datos son privados?**
Sí. El AIOS vive en tu equipo. Las credenciales van en un archivo `.env` que no se comparte. Tú controlas qué se conecta.

**¿Puedo tener muchos proyectos?**
Los que quieras. Todos heredan el mismo cerebro de negocio y aparecen en el dashboard.

**¿La IA puede construir cosas sin avisarme?**
No. Cualquier construcción se para y pide tu aprobación antes de tocar nada.

**Instalé el cerebro pero no reconoce mi negocio.**
Revisa que copiaste el contenido de `aios-global/` *dentro* de `.claude` (no la carpeta `aios-global` entera) y que rellenaste `CONTEXT/`.

---

## 8. Soporte

Este AIOS es un producto de **Criza Grupo**. Para dudas, instalación asistida o personalización avanzada, contacta con el equipo de Criza.

---

*AIOS by Criza — convierte la IA en el sistema operativo de tu negocio.*
