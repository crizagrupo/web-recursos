# AIOS by Criza — v2

Sistema operativo de IA para tu negocio, sobre Claude Code. v2 es un rediseño de la v1
(que vive en `Plantillas/AIOS-by-Criza/`) con una idea central: **el AIOS se instala
solo**. En vez de editar archivos con marcadores a mano, un instalador conversacional
(`/onboarding`) te entrevista y monta tu negocio por ti.

> El onboarding entrega hoy la **Fase 1 (Contexto)**, la **Fase 2 (Infraestructura /
> Git)** y la **Fase 3 (Datos / conexiones · MCP)**. El comando `/onboarding` es un router
> que ofrece la fase que toque según lo que ya esté hecho. Además, el comando
> **`/crear-proyecto`** abre una carpeta nueva por cada cliente o iniciativa (hermana de
> `Mi-Empresa/`), y `/onboarding` **también** sabe funcionar dentro de esos proyectos,
> ofreciendo solo su Fase 1 de contexto. Con el contexto ya hecho, el comando
> **`/task-audit`** audita tus tareas recurrentes y te dice cuáles conviene automatizar
> primero.

## Cómo está organizado

El producto es una **sola carpeta**, `Mi-Empresa/`, que trae dentro todo lo necesario: la
**herramienta** (lo que hace funcionar el AIOS) y el **contenido** (los datos de tu negocio).
La herramienta viaja en una subcarpeta `aios-global/` que **se autoinstala** en `~/.claude`
la primera vez que ejecutas `/onboarding`, y luego desaparece de la carpeta:

```
AIOS-by-Criza-v2/
└── Mi-Empresa/             → la carpeta de tu negocio (lo único que abres en Claude Code)
    ├── aios-global/        → copia de fábrica de la herramienta; el Paso 0 de /onboarding
    │   │                      la instala UNA vez en ~/.claude y luego la borra de aquí
    │   ├── agents/          → agentes del harness (construcción)
    │   ├── commands/        → comandos (/onboarding, /commit, /crear-proyecto, /task-audit…)
    │   ├── harness/         → motor de construcción (agentes, docs, checkpoints)
    │   ├── rules/           → reglas de comportamiento y de git
    │   └── skills/          → skills (onboarding-contexto, onboarding-infraestructura,
    │                          onboarding-datos, onboarding-proyecto, mcp-integration,
    │                          task-audit, skill-creator, informe, automatizar,
    │                          actualizar-dashboard, identidad-visual)
    ├── Recursos/
    │   └── plantilla-proyecto/ → molde ligero que /crear-proyecto copia por cada proyecto
    ├── CLAUDE.md           → identidad del negocio (con {{NOMBRE_NEGOCIO}})
    ├── ESTADO.md           → estado vivo del AIOS (fases de onboarding, pendientes)
    ├── MAPA.md             → índice de navegación por intención
    ├── HISTORICO.md        → hitos del negocio (el AIOS lo actualiza solo)
    ├── .gitignore          → lista de lo que NUNCA se sube (protege .env y claves)
    ├── CONTEXT/            → quién es el negocio (lo rellena /onboarding · Fase 1)
    ├── DATA/               → conexiones del negocio y qué sabe la IA (lo rellena Fase 3)
    └── harness/            → estado y construcciones de esta carpeta

    (INTELLIGENCE/, AUTOMATION/ y BUILD/ no vienen pre-creadas: se crean solas la
    primera vez que hace falta cada una — p. ej. INTELLIGENCE/task-audit/ al
    ejecutar /task-audit.)

En tiempo de ejecución, /crear-proyecto genera, junto a Mi-Empresa/:
Proyectos/
└── <cliente>/              → copia del molde + marcador .aios-proyecto + repo Git propio
```

- **`Mi-Empresa/aios-global/`** reproduce la estructura de `~/.claude`. **No la copias tú a
  mano:** el Paso 0 de `/onboarding` la instala en `~/.claude` una sola vez por ordenador (sin
  pisar nada que ya tuvieras) y luego la borra de la carpeta. A partir de ahí, la herramienta
  está disponible en cualquier carpeta que abras, incluidas las que crees con `/crear-proyecto`.
- **`Mi-Empresa/`** es la raíz de tu negocio (su contenido).
- **`Mi-Empresa/Recursos/plantilla-proyecto/`** es el molde ligero que `/crear-proyecto` copia
  por cada proyecto nuevo (mismo esquema de capas que el negocio, más ligero).
- **`Proyectos/<cliente>/`** son las carpetas de cada cliente o iniciativa, **hermanas** de
  `Mi-Empresa/`. Las crea `/crear-proyecto` copiando `Recursos/plantilla-proyecto/` y dándole
  su **propio repositorio Git**.

## Qué hace (Fase 1 · Contexto)

- **Entrada:** tus respuestas en una entrevista en lenguaje normal, o documentos que ya
  tengas del negocio (dossier, web, deck, notas) que el AIOS lee y aprovecha.
- **Qué produce:** los seis archivos de `CONTEXT/` (`negocio.md`,
  `servicios-pricing.md`, `equipo.md`, `clientes-objetivo.md`, `estrategia.md`,
  `procesos.md`) escritos con el contenido real de tu negocio, y tu `CLAUDE.md`
  personalizado con el nombre real (sin marcadores ni `TODO`).
- **Cómo se ejecuta:** abre `Mi-Empresa/` en Claude Code y escribe **`/onboarding`**. Si
  aún no conoce tu negocio, arranca la entrevista. Puedes cortar cuando quieras: al
  volver, retoma por donde ibas.

Al terminar, el AIOS te resume tu negocio ("¿quién soy y cómo trabajas?"), te pide
confirmar que está bien y sugiere el siguiente paso: `/task-audit`.

## Qué hace (Fase 2 · Infraestructura)

Cuando la Fase 1 está lista, `/onboarding` puede conectar tu negocio a **Git y GitHub**
para que todo tu trabajo quede guardado y respaldado en la nube. Está pensado para alguien
que **nunca ha usado Git**: el AIOS lo explica desde cero (con la analogía de "los puntos
de guardado de un videojuego") y hace el trabajo técnico por ti.

- **Qué necesita:** una cuenta de GitHub (gratis; te guía a crearla si no la tienes) y tu
  nombre y email para firmar los guardados. Nada más.
- **Qué deja hecho:** tu cuenta de GitHub conectada, la carpeta de tu negocio convertida en
  un repositorio con su primer "punto de guardado" subido a la nube (dejando fuera `.env` y
  cualquier credencial), una entrada nueva en tu `HISTORICO.md` y el comando **`/commit`**
  listo para guardar tu trabajo cuando quieras.
- **Se resuelve UNA vez por ordenador**, no por carpeta. Como Git/GitHub son una propiedad
  del ordenador, el AIOS lo apunta a nivel de usuario (en `~/.claude`), así cualquier
  carpeta nueva que crees después (con `/crear-proyecto`) ya lo hereda y no te vuelve a
  preguntar. Si el ordenador ya tenía Git/GitHub configurado, el AIOS lo detecta y no
  repite nada.
- **Cómo se ejecuta:** con la Fase 1 completa, vuelve a escribir **`/onboarding`**; te
  ofrecerá la Fase 2.

## Qué hace (Fase 3 · Datos y conexiones · MCP)

Con la Fase 1 lista, `/onboarding` puede **conectar tus herramientas a la IA**: te pregunta
qué usas en tu día a día (reuniones, CRM, almacenamiento tipo Google Drive o Microsoft 365,
y lo que añadas) y las enchufa por **MCP** para que la IA pueda leer y usar esa información.
No hace falta que la Fase 2 (Git) esté hecha: son independientes.

- **Qué necesita:** que le digas qué herramientas usas. Para cada una, el AIOS hace el
  trabajo técnico; tú solo apruebas y, cuando toca, haces el login de esa herramienta en tu
  navegador (por ejemplo, para dar acceso a tu Drive).
- **De una en una, a tu ritmo:** si no quieres conectarlo todo de golpe, eliges por cuál
  empezar; lo que aplaces queda anotado como pendiente y se retoma cuando vuelvas.
- **Qué deja hecho:** cada herramienta conectada, una ficha por herramienta en
  `DATA/integraciones/` (para qué se usa, tipo de conexión y estado, **sin** guardar
  contraseñas), y un `DATA/key-metrics.md` legible que explica, por cada herramienta, **qué
  sabe ahora la IA** gracias a ella.
- **Si una herramienta no tiene "enchufe" MCP:** el AIOS monta un conector a medida
  siguiendo su skill de referencia `mcp-integration`, sin que tengas que programar nada.
- **Se resuelve UNA vez por ordenador:** como las conexiones son una propiedad del
  ordenador, el AIOS las registra a nivel de usuario, así cualquier carpeta nueva que crees
  después (con `/crear-proyecto`) ya las hereda y no te vuelve a preguntar. Al reabrir
  `/onboarding`, no repite las conexiones ya hechas.
- **Nunca sube secretos:** las claves y contraseñas las gestiona el sistema o la propia
  herramienta; no se guardan en el repositorio.
- **Cómo se ejecuta:** con la Fase 1 completa, escribe **`/onboarding`**; te ofrecerá la
  Fase 3.

## Qué hace (proyectos · `/crear-proyecto` + Fase 1 de proyecto)

Cuando quieras trabajar un **cliente** o una **iniciativa** concreta, no ensucias la carpeta
del negocio: le das su propia carpeta con `/crear-proyecto`.

- **`/crear-proyecto`** — te pide el nombre del cliente/proyecto y monta, de forma automática,
  una carpeta nueva en **`Proyectos/<cliente>/`** (hermana de `Mi-Empresa/`, **nunca** dentro
  de ella). Copia el molde `Recursos/plantilla-proyecto/` (mismo esquema de capas, más ligero: `CONTEXT/`,
  `DATA/`, `INTELLIGENCE/`, `AUTOMATION/`, `BUILD/` y `harness/`), le da su **propio repositorio
  Git** con un primer punto de guardado (dejando fuera `.env` y cualquier credencial) y escribe
  un marcador `.aios-proyecto` que identifica la carpeta como proyecto. **No** vuelve a
  configurar tu identidad de Git ni tu cuenta de GitHub: reutiliza la que ya dejó la Fase 2.
- **Fase 1 de proyecto** — al abrir esa carpeta nueva y ejecutar **`/onboarding`**, el sistema
  detecta el marcador y sabe que está en un proyecto: te ofrece **solo** una entrevista **corta**
  sobre ese cliente (qué es, alcance, objetivos, interlocutores, particularidades), o te deja
  **importar un archivo** (dossier, propuesta, notas). Escribe él mismo `CONTEXT/proyecto.md` con
  el contenido real y **no** repite lo que ya define tu negocio (`Mi-Empresa/CONTEXT/`).
- **No repite Infraestructura ni Datos** — dentro de un proyecto, `/onboarding` **nunca** ofrece
  la Fase 2 (Git/GitHub) ni la Fase 3 (Datos): esas se resolvieron una vez para tu ordenador y
  el proyecto las **hereda**. Si aún no estuvieran resueltas, te avisa y te sugiere completar
  primero `/onboarding` en `Mi-Empresa/`.

### Herencia sin reinstalar nada

Una carpeta de proyecto **no** lleva copia de la herramienta: los comandos (`/onboarding`,
`/crear-proyecto`, `/commit`, `/estado`, `/informe`…) y las conexiones de datos viven en
`~/.claude`, instaladas una sola vez, así que responden **igual** dentro de `Proyectos/<cliente>/`
que dentro de `Mi-Empresa/`. Lo único propio de cada proyecto es su contenido (su `CONTEXT/`, su
repositorio Git y su marcador). Conectar una vez, disponible en todas partes.

## Qué hace (guardar tu trabajo · `/commit`)

Cuando termines una tanda de trabajo (en `Mi-Empresa/` o en cualquier `Proyectos/<cliente>/`),
escribe **`/commit`** y el AIOS **guarda la sesión** por ti, sin que tengas que saber Git:

- **Guarda un "punto de guardado"** de la carpeta con todo lo que has cambiado, para que
  siempre puedas volver a este momento.
- **Nunca sube secretos:** deja fuera `.env` y cualquier archivo con claves o contraseñas,
  aunque estuvieran a punto de colarse. Es una regla sin excepciones.
- **Documenta solo lo que construyes:** si has creado o cambiado de forma importante una
  herramienta en `BUILD/`, apunta una entrada en `BUILD/docs/_index.md` (qué es y dónde
  vive) sin que se lo pidas.
- **Actualiza tu historial solo:** añade una línea a `HISTORICO.md` con lo que hiciste y la
  fecha, para que el diario del negocio quede al día sin escribirlo a mano.
- **Nunca sube nada sin preguntar:** primero guarda en tu ordenador y solo sube a la nube
  (GitHub) si tú lo confirmas.
- **Mensaje a tu gusto:** puedes darle el texto tú (`/commit "ajuste de precios"`) o dejar
  que redacte uno claro a partir de tus cambios.

Funciona **igual** en la carpeta del negocio y en la de cualquier proyecto: es un comando
del ordenador (vive en `~/.claude`), no algo que se instale por carpeta.

## Qué hace (auditoría de tareas · `/task-audit`)

Cuando tu negocio ya está descrito (Fase 1 hecha), escribe **`/task-audit`** y el AIOS te
hace una **auditoría de tareas**: te va preguntando, área por área, qué cosas repites en el
día a día y te dice **cuáles conviene automatizar primero**. Sirve para saber por dónde
empezar a sacarle partido al sistema, sin adivinar.

- **Qué necesita:** la Fase 1 (`/onboarding`) hecha, para partir de tu `CONTEXT/` y **no
  repetirte** preguntas que ya respondiste sobre tu negocio. Si aún no hay contexto, te avisa
  de que hagas antes `/onboarding`.
- **Cómo trabaja:** recorre las áreas del negocio (marketing, ventas, entrega a cliente,
  operaciones, equipo, datos, comunicación y lo estratégico) de forma **conversacional** —una
  cada vez, no un formulario— y adapta las preguntas a tu tipo de negocio. Por cada tarea
  anota cada cuánto la haces, cuánto tiempo te lleva y si es automatizable (del todo, en
  parte, todavía no, o solo humano).
- **Qué produce:** un **scoreboard** priorizado en `INTELLIGENCE/task-audit/scoreboard.md`,
  con los **quick wins** primero (lo de más impacto y más fácil de automatizar) y el resto
  ordenado por lo que más tiempo te ahorra. Es una **lista marcable**: vas tachando (`[x]`)
  cada tarea a medida que la resuelves. Donde ya hay un comando o skill del AIOS que la
  resuelve, te lo indica como siguiente paso.
- **Se puede repetir:** vuelve a ejecutar `/task-audit` cuando quieras para **reevaluar**. El
  scoreboard anterior se guarda con su fecha en `INTELLIGENCE/task-audit/historico/` (no se
  pierde) y lo que ya habías marcado como resuelto **sigue marcado**.
- **Cómo se ejecuta:** en `Mi-Empresa/` o en cualquier `Proyectos/<cliente>/`, escribe
  **`/task-audit`**. El resultado se guarda en la `INTELLIGENCE/` de esa misma carpeta.

## Qué hace (crear capacidades nuevas · `skill-creator`)

A medida que uses el AIOS irás queriendo **enseñarle a hacer cosas nuevas** (una automatización
o una herramienta a tu medida). Cuando eso ocurre, conviene empaquetar esa capacidad como una
**skill**: una carpetita con instrucciones que la IA reconoce y lanza sola cuando toca. Para que
esas skills salgan siempre bien hechas —y no cada una a su manera— el AIOS trae `skill-creator`.

- **Qué es:** una "skill para crear skills". No la usas tú directamente en el día a día; la usa
  la IA por dentro cuando, construyendo algo nuevo, hace falta dejarlo empaquetado como skill
  reutilizable.
- **Cuándo se usa:** al construir una capacidad nueva (con el harness) que quieras que quede
  disponible para volver a usarla. En vez de montar la estructura a mano y arriesgarse a un
  formato que la IA no reconozca, se sigue esta skill.
- **Qué produce:** una skill nueva **bien formada** — su carpeta con el nombre correcto, su
  archivo de instrucciones (`SKILL.md`) con los datos que la IA necesita para reconocerla (qué
  hace y cuándo activarla), y, solo si la skill lo necesita, sus subcarpetas de código o de
  material de consulta (nunca vacías). Antes de darla por buena, **se autovalida**: si algo no
  cumple, lo señala y no la da por terminada hasta arreglarlo.
- **Dónde la instala:** si la capacidad sirve para cualquier cliente, la deja disponible para
  todo el ordenador; si depende de un cliente concreto, la deja dentro de la carpeta de ese
  proyecto. Misma regla de siempre: general → para todo; específico → dentro del proyecto.

## Instalación (resumen)

Sin copiar nada a mano: el propio `/onboarding` se instala a sí mismo la primera vez.

1. **Descomprime** el ZIP donde guardes tu trabajo (p. ej. el Escritorio).
2. **Abre `Mi-Empresa/`** en Claude Code.
3. **Ejecuta `/onboarding`.** En su primer arranque instala la herramienta en `~/.claude`
   (Paso 0, una sola vez) y sigue, en la misma conversación, con la entrevista de tu negocio.

A partir de ahí, cuando quieras abrir un cliente o iniciativa ejecuta `/crear-proyecto`; luego
abre la carpeta `Proyectos/<cliente>/` y ejecuta `/onboarding` para su Fase 1 de contexto.

No necesitas saber programar ni copiar archivos a `~/.claude`. Todo se hace hablando con la IA.
