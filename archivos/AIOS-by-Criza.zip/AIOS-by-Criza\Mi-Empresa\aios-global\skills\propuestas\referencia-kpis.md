# Referencia — cómo elegir los KPIs de "Impacto esperado"

Este documento se carga siempre antes de redactar la sección "Impacto esperado"
de una propuesta. No es teoría genérica de ventas: es el criterio destilado de
propuestas reales, para aplicarlo a cualquier cliente.

## Las cuatro lentes, en este orden de prioridad

1. **Riesgo** — ¿qué se pierde si el proceso falla? Busca en las notas de
   descubrimiento palabras como "crítico", "plazo", "error", "cumplimiento",
   "seguridad". Si hay un riesgo grave y explícito, ese es el KPI de cabecera
   — no el tiempo. (Ejemplo: en un despacho con plazos críticos, "plazos
   protegidos" pesa más que las horas, porque perder un plazo no es un problema
   de eficiencia, es un problema existencial para ese negocio.)
2. **Tiempo** — procesos descritos como "a mano", "manualmente", con una
   cadencia clara (diario/semanal/mensual). Es el KPI más fácil de cuantificar
   y el más universal, pero rara vez el más persuasivo por sí solo.
3. **Dinero** — solo con una tarifa horaria ilustrativa conservadora si no hay
   dato real del cliente, y siempre etiquetada como tal. Regla de honestidad
   económica (ver abajo): no se infla la tarifa para que la cifra "cuadre" con
   la cuota.
4. **Capacidad de crecer** — si el cliente mencionó explícitamente crecer,
   escalar o ampliar equipo en la reunión de descubrimiento, ese KPI pesa más
   porque es SU propia ambición, no una que le impone la propuesta.

## Cómo elegir el KPI de cabecera para un cliente nuevo

No se aplican las cuatro lentes por igual siempre. Antes de redactar, identifica
qué tipo de negocio es y qué le duele de verdad:

| Tipo de negocio | Lo que suele resonar más | Ejemplo de KPI de cabecera |
| --- | --- | --- |
| Legal / regulado (despachos, clínicas, finanzas) | Riesgo y cumplimiento | "100% de plazos/obligaciones detectados" |
| Comercio / e-commerce | Ventas perdidas, tiempo de respuesta | "0 pedidos sin confirmar", "de X h a Y min de respuesta" |
| Agencias / servicios creativos | Cumplimiento de entregas, capacidad | "capacidad de aceptar más clientes sin ampliar equipo" |
| Operaciones internas (backoffice, RRHH) | Tiempo y coste | "horas/mes liberadas", equivalencia en jornadas |

Si el negocio no encaja claramente en una fila, vuelve a las notas de
descubrimiento: la lente que más se repite ahí (riesgo, tiempo, dinero,
crecimiento) es la que debe liderar.

## Regla de conexión a la realidad

Cada cifra debe rastrearse a algo dicho en las notas de descubrimiento
(un proceso descrito, una cadencia, un volumen, una ambición declarada).
Lo que no esté grounded así se marca explícitamente como **ilustrativo**
— nunca se inventa un número sin decirlo. Esto no es solo honestidad: es lo
que permite que la propuesta se recalcule sin perder credibilidad cuando
lleguen los datos reales del cliente en la Fase 1.

## Regla de honestidad económica

Antes de cerrar la cifra en euros de "Impacto esperado":

1. Calcula `horas_mes × tarifa_hora_ilustrativa`.
2. Compara ese resultado con la cuota mensual propuesta.
3. Si el valor liberado no se acerca a la cuota (o la supera claramente), **no
   subas la tarifa horaria para forzarlo** — una tarifa horaria debe seguir
   siendo defendible (coste medio cargado de un perfil administrativo/de
   soporte en España; España 2026: orientativamente 20-45 €/h según el perfil).
4. En su lugar, reformula la frase que acompaña la cifra: reconoce que el
   tiempo es solo una parte del valor, y que el resto viene del riesgo evitado
   y de la capacidad de crecer (que no se pueden reducir limpiamente a euros).

Ejemplo: en un despacho con plazos críticos, esto llevó a fijar la tarifa en el
extremo defendible del rango (perfil de gestión/soporte cualificado) en vez de
forzar una tarifa irreal para que las horas liberadas "pagaran" la cuota por sí solas.

## Estructura de la cifra de cabecera

Cuando el cliente pide (o cuando el peso del argumento lo justifica) mostrar
tiempo Y dinero, ambas cifras van **al mismo nivel visual** — dos bloques
grandes lado a lado, no una grande y una pequeña como nota al pie. Si solo hay
una cifra sólida (p. ej. no hay tarifa horaria defendible para ese cliente),
se muestra solo el tiempo liberado como única cifra de cabecera.

## Caso resuelto de referencia (ejemplo anónimo)

- **Negocio:** despacho profesional con plazos críticos. Lo que más pesaba: el
  riesgo de perder un plazo por error humano (no la eficiencia).
- **KPI de cabecera:** "100% de plazos detectados" + "de ~30 min a segundos"
  por notificación — no el tiempo agregado, aunque también se mostró.
- **Cifra económica:** horas/mes × tarifa ilustrativa defendible = valor liberado
  (~70% de la cuota), presentado junto a las horas/mes, mismo tamaño visual.
- **Capacidad de crecer:** "~30% más de volumen sin ampliar equipo" — elegido
  porque el cliente pidió explícitamente en la reunión una colaboración que
  apoyara objetivos de crecimiento ambiciosos.
- **Sin nombres propios de personas** en ninguna cifra ni KPI (solo áreas/roles).

Cada cliente nuevo que pase por este skill puede añadirse aquí como otro caso
resuelto (anónimo), para que el criterio se afine con el uso — no hace falta pedir
permiso para leerlo, pero si un caso resulta especialmente instructivo (un KPI
que no encajaba en las cuatro lentes, una corrección del cliente sobre qué
argumento pesaba más), vale la pena anotarlo en esta misma sección.
