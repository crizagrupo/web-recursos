# Servicios y precios — {{NOMBRE_NEGOCIO}}

> Capa 1 (Context). Qué vende el negocio y a qué precio.
> Estado: scaffold — responde las secciones `TODO`.

## Servicios / productos
TODO — lista de lo que se vende, con una línea por cada uno.

## Precios
TODO — modelo de precio (por servicio, suscripción, proyecto…).

## Condiciones
TODO — pagos, plazos, garantías.
