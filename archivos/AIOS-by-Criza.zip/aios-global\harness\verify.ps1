# verify.ps1 - Verificacion de invariantes del harness del AIOS
# Reemplaza al init.sh de los ejemplos. Ejecutar desde la raiz del AIOS.
# Sale con codigo 0 si todo esta verde, != 0 si hay algun fallo.
# (Sin acentos a proposito: PowerShell 5.1 ejecuta este script y los
#  caracteres no-ASCII pueden romper el parseo segun la codificacion.)

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$problemas = @()

function Fail($msg) { $script:problemas += $msg }

# 1. build_backlog.json valido
$backlogPath = Join-Path $root "build_backlog.json"
if (-not (Test-Path $backlogPath)) {
    Fail "Falta build_backlog.json"
    $backlog = $null
} else {
    try {
        $backlog = Get-Content $backlogPath -Raw -Encoding UTF8 | ConvertFrom-Json
    } catch {
        Fail ("build_backlog.json no es JSON valido: " + $_.Exception.Message)
        $backlog = $null
    }
}

if ($backlog) {
    $modules = @($backlog.modules)

    # 2. Como maximo un modulo in_progress
    $enCurso = @($modules | Where-Object { $_.status -eq "in_progress" })
    if ($enCurso.Count -gt 1) {
        Fail ("Hay " + $enCurso.Count + " modulos en in_progress (maximo 1): " + ($enCurso.name -join ', '))
    }

    # 3. Todo modulo sdd in_progress/done tiene specs/<name>/ con los 3 archivos
    foreach ($m in $modules) {
        if ($m.sdd -eq $true -and ($m.status -eq "in_progress" -or $m.status -eq "done")) {
            $specDir = Join-Path $root ("specs\" + $m.name)
            foreach ($f in @("requirements.md", "design.md", "tasks.md")) {
                if (-not (Test-Path (Join-Path $specDir $f))) {
                    Fail ("El modulo '" + $m.name + "' esta en '" + $m.status + "' pero falta specs\" + $m.name + "\" + $f)
                }
            }
        }
    }

    # 4. Sin specs huerfanos (carpeta en specs/ sin entrada en el backlog)
    $specsRoot = Join-Path $root "specs"
    if (Test-Path $specsRoot) {
        $nombres = $modules.name
        Get-ChildItem $specsRoot -Directory -ErrorAction SilentlyContinue | ForEach-Object {
            if ($nombres -notcontains $_.Name) {
                Fail ("Spec huerfano: specs\" + $_.Name + " no tiene entrada en build_backlog.json")
            }
        }
    }
}

# 5. Sin credenciales evidentes en archivos versionados (.md / .json / .ps1)
$patrones = @('sk-[A-Za-z0-9]{20,}', '(?i)api[_-]?key\W{0,3}[A-Za-z0-9]{16,}', '(?i)bearer\W{1,3}[A-Za-z0-9_\-\.]{20,}')
$exclude = @('verify.ps1')
Get-ChildItem $root -Recurse -Include *.md, *.json, *.ps1 -File -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -notmatch '\\\.git\\' -and $_.FullName -notmatch 'Harness Engineering' -and $exclude -notcontains $_.Name } |
    ForEach-Object {
        $contenido = Get-Content $_.FullName -Raw -ErrorAction SilentlyContinue
        foreach ($p in $patrones) {
            if ($contenido -and ($contenido -match $p)) {
                Fail ("Posible credencial en " + $_.FullName.Replace($root, '.') + " (patron: " + $p + ")")
            }
        }
    }

# Resultado
Write-Host ""
if ($problemas.Count -eq 0) {
    Write-Host "[harness] verify.ps1 OK - todas las invariantes verdes." -ForegroundColor Green
    exit 0
} else {
    Write-Host ("[harness] verify.ps1 FALLO - " + $problemas.Count + " problema(s):") -ForegroundColor Red
    $problemas | ForEach-Object { Write-Host ("  - " + $_) -ForegroundColor Red }
    exit 1
}
