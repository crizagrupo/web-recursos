﻿# AGENTS.md — Mapa de navegación para agentes de IA

> Punto de entrada para cualquier agente que trabaje en el AIOS de {{NOMBRE_NEGOCIO}}.
> No es una biblia de reglas: es un **mapa**. Lee solo lo que necesites,
> cuando lo necesites (divulgación progresiva).

---

## 1. Dos modos de trabajo

**Modo operación (por defecto).** Preguntas de negocio, consultas, lectura del
contexto, operación diaria → responde directamente usando las 5 capas del AIOS.
No hace falta el flujo de construcción.

**Modo construcción.** Cuando {{DUENO}} pide **construir/automatizar algo nuevo**
(una automatización o herramienta) → actúas como `leader` y sigues el flujo SDD
de §4. Ver `.claude/agents/leader.md`.

## 2. Las 5 capas del AIOS (contexto del negocio)

| Capa | Carpeta | Para qué |
|------|---------|----------|
| 1 Context | `CONTEXT/` | Quién es {{NOMBRE_NEGOCIO}}. Léelo antes de especificar cualquier módulo. |
| 2 Data | `DATA/` | Datos e integraciones (GHL, Supabase, M365). |
| 3 Intelligence | `INTELLIGENCE/` | Reuniones, daily brief, pipeline, seguimientos. |
| 4 Automation | `AUTOMATION/` | Dónde se construyen las **automatizaciones**. |
| 5 Build | `BUILD/` | Dónde se construyen las **herramientas**. |

## 3. Mapa del harness (gobierno de la construcción)

| Archivo / carpeta | Qué contiene | Cuándo leerlo |
|-------------------|--------------|---------------|
| `build_backlog.json` | Cola de módulos a construir con su estado | Siempre, al empezar una construcción |
| `progress/current.md` | Estado de la sesión activa | Siempre, al empezar |
| `progress/history.md` | Bitácora append-only de sesiones | Si necesitas contexto histórico |
| `specs/<modulo>/` | requirements + design + tasks de un módulo | Antes de construir ese módulo |
| `docs/harness/architecture.md` | Qué es "buen trabajo" | Antes de construir |
| `docs/harness/conventions.md` | Nombres, ubicaciones, estilo | Antes de construir |
| `docs/harness/specs.md` | Proceso SDD: EARS-lite, 3 archivos, aprobación | Antes de redactar o leer un spec |
| `docs/harness/verification.md` | Cómo verificar un módulo | Antes de declarar `done` |
| `CHECKPOINTS.md` | Criterios de "estado final correcto" | Para auto-evaluarte |
| `.claude/agents/` | leader, explorer, spec_author, builder, reviewer | Si orquestas trabajo |
| `verify.ps1` | Verificación de invariantes | Al empezar y al cerrar |

## 4. Flujo de construcción (SDD)

```
pending → [spec_author] → spec_ready → ⏸ {{DUENO}} APRUEBA → in_progress → [builder → reviewer] → done
```

1. El `leader` detecta el primer módulo `pending` en `build_backlog.json`.
2. (Opcional, si hace falta investigar) lanza 1-3 `explorer` que escriben en `progress/explore_<modulo>.md`.
3. El `leader` lanza `spec_author`, que crea `specs/<modulo>/{requirements,design,tasks}.md` y marca `spec_ready`.
4. **Pausa.** {{DUENO}} lee el spec y aprueba (o pide cambios).
5. Aprobado → el `leader` pasa a `in_progress` y lanza `builder`.
6. El `builder` ejecuta `tasks.md` una a una, construye en `AUTOMATION/` o `BUILD/`, verifica y escribe `progress/impl_<modulo>.md`.
7. El `reviewer` comprueba trazabilidad y CHECKPOINTS → `progress/review_<modulo>.md`.
8. Si aprueba, se marca `done` y el resumen se mueve a `progress/history.md`.

## 5. Reglas duras (no negociables)

- **Un módulo a la vez.** Nunca más de un `in_progress`.
- **No construyas sin spec aprobado** por {{DUENO}}.
- **No saltes la puerta de aprobación** entre `spec_ready` e `in_progress`.
- **No marques `done` sin verificación** (`verify.ps1` verde + prueba funcional).
- **Estado en disco, no en chat.** Los subagentes escriben en archivos y devuelven solo una referencia.
- **Nunca commitees credenciales.** Variables de entorno.
- **Documenta mientras trabajas** en `progress/current.md`, no al final.

## 6. Cierre de sesión

1. Ejecuta `verify.ps1` — todo verde.
2. Si el módulo está acabado: `status: "done"` en `build_backlog.json`.
3. Mueve el resumen de `progress/current.md` al final de `progress/history.md`.
4. Vacía `progress/current.md` dejando la plantilla.
5. Sin archivos temporales ni TODOs sin contexto.

## 7. Si te bloqueas
Relee la sección relevante de `docs/harness/`. No inventes workarounds: documenta el bloqueo en `progress/current.md`, marca el módulo `blocked` y para.
