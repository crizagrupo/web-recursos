# Guía de CONTEXT/ — qué escribir en cada archivo

Referencia para la skill `onboarding-contexto`. Define el **mapeo tema → archivo** y las
secciones de cada uno de los seis `.md`. Todo el contenido debe ser **real** (lo que ha
dicho el usuario o lo extraído de sus documentos) y quedar **sin `TODO`**.

Reglas comunes a los seis archivos:
- Título: `# <Sección> — <NOMBRE_NEGOCIO real>` (sustituye `{{NOMBRE_NEGOCIO}}`).
- Redacta en frases claras, no en telegramas. Prosa breve o viñetas, lo que se lea mejor.
- Si una sección no aplica al negocio, dilo explícito ("No aplica: …"), no la dejes vacía.
- No dejes ninguna línea con `TODO`, `TBD`, `{{...}}` ni "por completar".

---

## 1. `negocio.md` — qué hace, propuesta de valor, diferencial
Tema de entrevista: *qué hace el negocio*.

Secciones:
- **Qué es** — en una o dos frases: qué hace y para quién.
- **Propuesta de valor** — qué problema resuelve y por qué el cliente paga.
- **Diferencial** — por qué este negocio y no la competencia.
- **Cifras clave** (si el usuario las da) — facturación, nº de clientes, año de
  fundación / hitos. Si no las quiere dar, omite la sección o pon "No facilitado".

## 2. `servicios-pricing.md` — qué vende y a qué precio
Tema de entrevista: *qué vende y a qué precios*.

Secciones:
- **Servicios / productos** — lista de lo que vende, una línea por cada uno.
- **Precios** — modelo de precio (por servicio, suscripción, proyecto, por hora…) y
  rangos o precios concretos que dé el usuario.
- **Condiciones** — pagos, plazos, garantías, mínimos, si aplica.

## 3. `equipo.md` — quién es quién y quién decide
Tema de entrevista: *quién forma el equipo y quién decide*.

Secciones:
- **Personas** — una entrada por persona: nombre, rol, de qué se encarga.
- **Quién decide** — quién toma las decisiones operativas del día a día y quién las de
  negocio (dueño/socios). Útil para que el AIOS sepa a quién escalar.

## 4. `clientes-objetivo.md` — a quién se dirige
Tema de entrevista: *a quién sirve / cliente objetivo*.

Secciones:
- **Cliente ideal (ICP)** — a quién se dirige: perfil, sector, tamaño.
- **Segmentos** — segmentos de cliente y prioridad de cada uno (p. ej. particulares vs
  empresas), si tiene más de uno.
- **A quién NO se dirige** — para no gastar esfuerzo en clientes que no encajan (si el
  usuario lo tiene claro).

## 5. `estrategia.md` — objetivos y prioridades actuales
Tema de entrevista: *cuáles son sus prioridades actuales*.

Secciones:
- **Objetivos** — objetivos del periodo (trimestre / año).
- **Canales** — por dónde llegan los clientes (referidos, ads, redes, boca a boca…).
- **Prioridades actuales** — en qué está el foco ahora mismo (p. ej. "abrir un segundo
  punto de venta"). Esta sección es la que más usarán el daily brief y `/task-audit`.

## 6. `procesos.md` — cómo entra y cómo se entrega
Tema de entrevista: *cómo entra un cliente y cómo se le entrega*.

Secciones:
- **Cómo entra un lead / cliente** — de dónde viene y qué pasa cuando entra.
- **De lead a cliente** — pasos hasta el cierre de una venta.
- **Entrega del servicio / producto** — cómo se entrega y se da seguimiento.
- **Herramientas por paso** — qué herramienta usa en cada fase (CRM, facturación,
  reuniones, WhatsApp…). Esto prepara la Fase 3 (conexión de datos).

---

## Mapa rápido tema → archivo

| Tema de la entrevista | Archivo |
|-----------------------|---------|
| Qué hace, propuesta de valor, diferencial | `negocio.md` |
| Qué vende y a qué precio | `servicios-pricing.md` |
| Quién es quién y quién decide | `equipo.md` |
| A quién se dirige | `clientes-objetivo.md` |
| Objetivos y prioridades actuales | `estrategia.md` |
| Cómo entra un cliente y cómo se le entrega | `procesos.md` |
| Identidad visual y tono de voz (7.º tema) | `branding/guia-marca.md` — esquema en `guia-branding.md` |
