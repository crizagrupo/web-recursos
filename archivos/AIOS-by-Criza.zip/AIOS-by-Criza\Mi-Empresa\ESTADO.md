# ESTADO — {{NOMBRE_NEGOCIO}}

> Estado vivo del negocio: en qué punto está el AIOS y qué queda pendiente.
> El AIOS lo mantiene al día; no hace falta editarlo a mano.

## Fase actual

- **Onboarding · Fase 1 (Contexto):** pendiente.
  Ejecuta `/onboarding` en esta carpeta para definir quién es el negocio.
- **Onboarding · Fase 2 (Infraestructura · Git/GitHub):** pendiente.
  Se ofrece tras completar la Fase 1. Se resuelve una vez por ordenador.
- **Onboarding · Fase 3 (Datos y conexiones · MCP):** pendiente.
  Se ofrece tras completar la Fase 1. Se resuelve una vez por ordenador.

## Qué está resuelto

*(vacío hasta que completes alguna fase de `/onboarding`)*

## Pendientes

- Completar la Fase 1 (Contexto) con `/onboarding`.
- Con la Fase 1 lista, considerar `/task-audit` para priorizar qué automatizar primero.
