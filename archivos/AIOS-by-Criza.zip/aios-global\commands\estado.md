---
description: Resumen rápido del estado — del negocio o del proyecto en el que estés.
---

Da un resumen breve y accionable del estado actual.

1. Si estás en una carpeta de proyecto (`Escritorio/Proyectos/<nombre>/`), lee su `ESTADO.md` y resume: foco, pendientes y bloqueos de ese proyecto.
2. Si estás a nivel negocio, lee el `ESTADO.md` del negocio y, si existe la carpeta `Escritorio/Proyectos/`, resume el estado de cada proyecto activo.

Formato: máximo 5 líneas. Ve al grano: qué está en marcha, qué falta, qué bloquea.
