# AIOS — {{NOMBRE_NEGOCIO}} (nivel negocio)

Este es el **cerebro del AIOS**: el nivel negocio, activo en cualquier carpeta que abras. Define quién es el negocio, cómo se trabaja y con qué herramientas. Cada proyecto que crees hereda todo esto.

> Nivel negocio = identidad + herramientas. Nivel proyecto = trabajo concreto (vive en `Escritorio/Proyectos/<nombre>/`).

## Dos modos de trabajo

- **Operación** (por defecto): preguntas, consultas, registro del día a día → responde directo. Abre `MAPA.md` y lee solo lo necesario.
- **Construcción**: crear/automatizar algo nuevo → entra en el flujo del harness (`harness/AGENTS.md`). **Nada se construye sin que {{DUENO}} apruebe el plan.**

Disparadores de construcción: "construye", "automatiza", "crea una herramienta", "monta un flujo". Operar (preguntar, guardar, resumir) nunca lo activa.

## Reglas duras

1. **Carga bajo demanda**: lee `MAPA.md` antes de actuar y abre solo lo que pida la intención. No abras `CONTEXT/` entero por defecto.
2. **Empieza por el contexto**: antes de actuar sobre el negocio, lee lo relevante de `CONTEXT/`.
3. **Construir = aprobación previa**: en modo construcción, presenta el spec y espera el "aprobado" de {{DUENO}} antes de tocar nada.
4. **Nunca commitees credenciales**: van en `.env` (variables de entorno).

## Pointers

- Identidad del negocio → `CONTEXT/` (índice en `MAPA.md`)
- Navegación (operación) → `MAPA.md`
- Construcción (harness) → `harness/AGENTS.md`
- Estado del negocio → `ESTADO.md` · Histórico → `HISTORICO.md`
- Comportamiento y estilo → `rules/`
- Comandos → `commands/` (`/estado`, `/informe`, `/dashboard`)

## Capas del negocio (transversales)

`CONTEXT/` (quién es) · `DATA/` (integraciones y datos) · `INTELLIGENCE/` (conocimiento vivo) · `AUTOMATION/` (automatizaciones que cruzan proyectos) · `BUILD/` (herramientas comunes + dashboard de negocio).

Idioma de trabajo: **español**.
