---
description: Instalador conversacional del AIOS. Router que detecta si estás en la raíz del negocio (Mi-Empresa/) o en una carpeta de proyecto, y ofrece las fases que correspondan. En Mi-Empresa/, pone en marcha el negocio por fases (Contexto, Infraestructura, Datos). En un proyecto, ofrece solo la Fase 1 (Contexto de proyecto) y no repite Infraestructura ni Datos, ya resueltas a nivel de usuario.
---

Este archivo es un **arrancador temporal**: existe únicamente para que Claude Code reconozca
`/onboarding` como comando disponible la primera vez que se abre esta carpeta, antes de que la
herramienta esté instalada en `~/.claude`. Se autoborra en cuanto cumple su función (lo hace el
Paso 0.5 de las instrucciones reales, más abajo) — no lo edites ni lo dupliques a mano.

- Si existe `./aios-global/commands/onboarding.md` en esta misma carpeta, **léelo ahora mismo**
  con la herramienta de lectura de archivos y sigue **al pie de la letra**, en este mismo turno,
  todas sus instrucciones empezando por su Paso 0 (autoinstalación). Ese archivo es la fuente
  real del comando; este solo existe para dispararlo.
- Si **no** existe (la instalación ya se completó en una sesión anterior y este arrancador
  debería haberse borrado con ella), lee en su lugar `~/.claude/commands/onboarding.md` y sigue
  esas instrucciones con normalidad.
