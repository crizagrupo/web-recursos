---
name: actualizar-dashboard
description: Sincroniza el dashboard de gestión con el estado actual leído de ESTADO.md. Cubre DOS niveles - NIVEL PROYECTO (BUILD/dashboard/datos.js, con el ESTADO.md del proyecto) y NIVEL NEGOCIO (Mi-Empresa/BUILD/dashboard-negocio/datos.js, cartera de proyectos, recorriendo cada Proyectos/<cliente>/ESTADO.md). Úsala cuando el usuario pida "actualizar el dashboard", "refrescar el panel", "volcar el estado al dashboard" o similar. Vuelca solo los campos vivos y conserva el resto. Funciona en cualquier AIOS que use la plantilla de dashboard del AIOS.
---

# Skill: actualizar el dashboard

Vuelca el **estado actual** a la fuente de verdad del dashboard, sin romper su esquema.
Reparto del trabajo (patrón `informe`): lo **mecánico** lo hacen los scripts Node (sin
IA, sin tokens); el **mapeo con criterio** lo haces tú con ediciones quirúrgicas.

## Detección de nivel (elige la rama antes de empezar)

- **Nivel proyecto** — estás dentro de una carpeta de proyecto: existe un marcador
  `.aios-proyecto` en la carpeta actual o en un ancestro. → sigue **Nivel proyecto**.
- **Nivel negocio** — estás en `Mi-Empresa/` (no hay `.aios-proyecto`): quieres la vista
  agregada de **cartera de proyectos**. → sigue **Nivel negocio**.

---

# Nivel proyecto

Vuelca el **estado actual del proyecto** (`ESTADO.md`) a `BUILD/dashboard/datos.js`, sin
perder las secciones narrativas que no están en `ESTADO.md`. No se regenera el archivo
entero (lleva comentarios mantenidos a mano): se editan solo los campos que cambian.

## Fuente

Única fuente = **`ESTADO.md`** del proyecto. Si falta, avisa y no toques nada.

## Pasos

1. **Preparar** (backup + foto antes):
   ```
   node scripts/preparar.js
   ```
   Resuelve solo el `datos.js` del proyecto desde la carpeta de trabajo. Imprime la ruta,
   la copia de seguridad creada y el recuento de elementos por sección. Si no encuentra
   `BUILD/dashboard/datos.js`, el proyecto no tiene dashboard: avisa y termina.

2. **Leer** `ESTADO.md` y `BUILD/dashboard/datos.js`.

3. **Editar `datos.js`** con ediciones quirúrgicas, mapeando:

   | Campo en `datos.js` | Origen en `ESTADO.md` |
   | --- | --- |
   | `actualizado` | fecha de "Última actualización" del encabezado |
   | `fases[].estado` / `avance` | tabla/sección de fases (pendiente/en_curso/completada; avance 0-100) |
   | `discovery.esperandoCliente[].recibido` | sección "Esperando del cliente" (✅/[x] = true) |
   | `discovery.actionItems[].estado` | "Action items" / pendientes con responsable |
   | `discovery.decisiones` | "Decisiones tomadas" |
   | `discovery.pendientesCriticos` | "Pendientes críticos" / reglas abiertas |
   | `estadoGeneral.proximaAccion` | "Próxima acción", sintetizada en una frase |
   | `estadoGeneral.bloqueos` | "Bloqueos" (lista vacía si no hay) |
   | `tareas` (hitos) | hitos nuevos que aparezcan en "Próxima acción"/"Decisiones" |

   Reglas al editar:
   - **Conserva intactas** las secciones estables que no salen de `ESTADO.md`:
     `proyecto`, `entregables`, `discovery.sesiones`, `roadmap`, los paneles propios del
     proyecto (`plataformas`, `fuentes`, `estilo`) y `alcance`. **Salvo** que una decisión
     de `ESTADO.md` cambie una clasificación (p. ej. "difusión pasa de CORE a add-on" →
     ajusta el `tipo`).
   - Respeta el esquema, los comentarios y el formato. Fechas en `AAAA-MM-DD`.
   - No añadas atributos `data-*` (esos viven en `index.html`, no en `datos.js`).

4. **Verificar**:
   ```
   node scripts/verificar.js
   ```
   Debe dar **PASS**. Si sale **WARN** por pérdida de una sección o fecha sin refrescar,
   corrígelo. Si sale **FAIL**, el JS quedó inválido: restaura desde `.backups/` y repite.

5. **(Opcional) Ver el resultado**:
   ```
   node BUILD/dashboard/servir.js
   ```
   Abre `http://localhost:8765/`. **GOTCHA**: el dashboard guarda copia en
   `localStorage["dashboard_<slug>"]` (el `<slug>` lo fija el `index.html` del proyecto)
   que puede tapar tus cambios. Antes de comprobar, en la consola del navegador:
   `localStorage.removeItem('dashboard_<slug>')` y recarga.

6. **Reportar** en 1-2 líneas: qué fecha tiene ahora el dashboard y qué secciones se
   actualizaron.

## Aplicar marca (si quedó pendiente al crear el proyecto)

`/crear-proyecto` ya intenta aplicar la marca del negocio al `BUILD/dashboard/index.html` del
proyecto en el momento de crearlo. Si en ese momento `CONTEXT/branding/guia-marca.md` todavía
no existía (el negocio no había completado ese tema de `/onboarding`), el dashboard quedó con
la paleta azul por defecto. Si el usuario pide re-brandearlo, o detectas que ya hay guía de
marca pero el dashboard sigue en azul por defecto, aplica la misma tabla de mapeo de tokens que
usa el **Nivel negocio** (más abajo) sobre `BUILD/dashboard/index.html`.

---

# Nivel negocio

Regenera la **cartera de proyectos** del negocio en
`Mi-Empresa/BUILD/dashboard-negocio/datos.js`: una entrada por cada `Proyectos/<cliente>/`,
con su nombre, avance, próxima acción y bloqueos. Es una vista de **solo lectura**: no se
edita a mano, se **regenera** siempre desde los `ESTADO.md` de los proyectos.

## Fuente

Un `ESTADO.md` por cada `Proyectos/<cliente>/`. Si un proyecto no tiene `ESTADO.md`, se
lista igual con lo que se pueda derivar (nombre) y el resto vacío/`null`. **No inventes**
datos que no consten.

## Pasos

1. **Preparar** (localizar, materializar si falta, listar proyectos, foto antes):
   ```
   node scripts/negocio-preparar.js
   ```
   - Localiza `Mi-Empresa/` y su hermana `Proyectos/` (misma lógica que `/crear-proyecto`).
   - Si `Mi-Empresa/BUILD/dashboard-negocio/` no existe, la **materializa** copiando el
     motor del asset y sustituyendo `{{NOMBRE_NEGOCIO}}` (de `CONTEXT/negocio.md` o
     `CLAUDE.md`) → cero `{{...}}`.
   - Imprime los proyectos detectados con la ruta de su `ESTADO.md`. Si `Proyectos/` no
     existe o está vacía, lo indica y sigue (cartera vacía).

   **Aplicar marca (solo si acabas de materializar el dashboard por primera vez, o si el
   usuario pide explícitamente re-brandearlo).** Si existe `CONTEXT/branding/guia-marca.md`,
   aplica sus colores al bloque `:root` de `BUILD/dashboard-negocio/index.html` en vez de
   dejar la paleta azul por defecto (sigue la skill `identidad-visual` para el criterio).
   Mapea por **rol**, no por nombre literal:

   | Token de `guia-marca.md` | Variable del dashboard |
   | --- | --- |
   | `--primario` | `--azul` |
   | `--primario-oscuro` (o `--acento` si no hay oscuro) | `--azul-claro` |
   | `--bg` | `--gris-bg` |
   | `--surface` | `--panel` |
   | `--ink` | `--texto` |
   | `--muted` | `--texto-suave` |
   | `--line` | `--borde` |

   `--azul-bg` no tiene equivalente directo en la guía: genera un tinte muy claro del nuevo
   `--primario` (mismo tono, muy aclarado) para conservar la legibilidad de la insignia
   "pendiente". **No toques** `--verde/--verde-bg`, `--ambar/--ambar-bg`, `--rojo/--rojo-bg`
   ni `--sombra`: son semántica de estado (éxito/aviso/error), no identidad de marca. Si
   `guia-marca.md` **no** existe todavía, deja la paleta por defecto sin más: no es un error,
   solo falta ese tema del onboarding.

2. **Leer** cada `ESTADO.md` listado y `BUILD/dashboard-negocio/datos.js`.

3. **Reescribir la lista `proyectos`** de `datos.js`. Por cada proyecto, una entrada:

   | Campo | Origen en el `ESTADO.md` del proyecto |
   | --- | --- |
   | `id` | slug de la carpeta (`Proyectos/<slug>/`) |
   | `nombre` | del `.aios-proyecto` / carpeta / título de `CLAUDE.md` (ya lo da `negocio-preparar.js`) |
   | `estado` | `pendiente` \| `en_curso` \| `completada` según la fase; si solo tiene el onboarding pendiente → `pendiente` |
   | `avance` | 0-100 derivado del avance/fase; `null` si no consta |
   | `proximaAccion` | síntesis en una frase de "Próxima acción" / "Pendientes" |
   | `bloqueos` | de "Bloqueos" (lista de textos; `[]` si no hay) |
   | `actualizado` | fecha de "Última actualización" del `ESTADO.md` (o `null`) |

   Reglas:
   - **No inventes**: lo que no conste queda vacío (`""`), `[]` o `null`.
   - Refresca `actualizado` (cabecera) a la fecha de hoy, formato `AAAA-MM-DD`.
   - Conserva `version` y `negocio`. Si no hay proyectos, deja `proyectos: []`.

4. **Verificar**:
   ```
   node scripts/negocio-verificar.js
   ```
   Debe dar **PASS**. Si sale **WARN** (fecha, campo mínimo, posible pérdida de proyectos),
   corrígelo. Si sale **FAIL**, el JS quedó inválido: restaura desde `.backups/` y repite.

5. **Reportar** en 1-2 líneas: cuántos proyectos tiene la cartera y su fecha; recuerda que
   se abre con doble clic en `BUILD/dashboard-negocio/index.html`.

## Notas

- Los scripts resuelven las rutas **relativas a la carpeta de trabajo**: el comando sirve
  en cualquier AIOS con la plantilla de dashboard, sin tocar el código.
- Las copias de seguridad se acumulan en `BUILD/dashboard/.backups/` (proyecto) y
  `BUILD/dashboard-negocio/.backups/` (negocio).
