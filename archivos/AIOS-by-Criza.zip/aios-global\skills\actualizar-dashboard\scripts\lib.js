// ============================================================================
// lib.js — utilidades compartidas del comando /actualizar-dashboard
// ----------------------------------------------------------------------------
// Código determinista, sin IA. Localiza el dashboard del proyecto, carga su
// fuente de verdad (window.DATOS) en un sandbox y produce una "foto" con el
// recuento de elementos por sección, que sirve para detectar pérdidas.
// Genérico: sirve para cualquier AIOS que use la plantilla de dashboard.
// ============================================================================
const fs = require('fs');
const path = require('path');
const vm = require('vm');

// Localiza BUILD/dashboard/datos.js subiendo desde el directorio de trabajo.
// Soporta ejecutarse desde la raíz del proyecto o desde dentro del dashboard.
function findDatos() {
  const tries = [];
  let dir = process.cwd();
  for (let i = 0; i < 12; i++) {
    tries.push(path.join(dir, 'BUILD', 'dashboard', 'datos.js'));
    tries.push(path.join(dir, 'datos.js')); // por si el cwd ya es la carpeta del dashboard
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  for (const t of tries) {
    if (fs.existsSync(t)) return t;
  }
  return null;
}

// Carga datos.js en un sandbox y devuelve window.DATOS. Lanza si el JS no parsea.
function loadDatos(filePath) {
  const code = fs.readFileSync(filePath, 'utf8');
  const sandbox = { window: {} };
  vm.createContext(sandbox);
  vm.runInContext(code, sandbox, { filename: filePath });
  if (!sandbox.window || !sandbox.window.DATOS) {
    throw new Error('El archivo no define window.DATOS');
  }
  return sandbox.window.DATOS;
}

// Recorre el objeto y registra la longitud de cada array por su ruta con puntos
// (p. ej. "fases", "auditoria.decisiones"). Genérico para cualquier esquema.
function countArrays(obj, prefix, out) {
  out = out || {};
  if (Array.isArray(obj)) {
    out[prefix] = obj.length;
    return out; // no se entra dentro de los elementos del array
  }
  if (obj && typeof obj === 'object') {
    for (const k of Object.keys(obj)) {
      const p = prefix ? prefix + '.' + k : k;
      countArrays(obj[k], p, out);
    }
  }
  return out;
}

// Foto comparable del estado: fecha + recuento de arrays por sección.
function snapshot(datos) {
  return {
    actualizado: datos.actualizado || null,
    counts: countArrays(datos, '', {}),
  };
}

// Carpeta y ruta del archivo de foto, junto al propio datos.js.
function backupsDir(datosPath) {
  return path.join(path.dirname(datosPath), '.backups');
}
function snapshotPath(datosPath) {
  return path.join(backupsDir(datosPath), '_snapshot-antes.json');
}

module.exports = { findDatos, loadDatos, countArrays, snapshot, backupsDir, snapshotPath };
