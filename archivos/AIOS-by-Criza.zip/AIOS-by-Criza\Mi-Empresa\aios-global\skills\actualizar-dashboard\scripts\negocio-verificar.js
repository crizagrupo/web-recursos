#!/usr/bin/env node
// ============================================================================
// negocio-verificar.js — paso FINAL de /dashboard a NIVEL NEGOCIO (sin IA)
// ----------------------------------------------------------------------------
// Sobre Mi-Empresa/BUILD/dashboard-negocio/datos.js comprueba que:
//   - sigue siendo JS válido y define window.DATOS,
//   - window.DATOS.proyectos es un array,
//   - la fecha "actualizado" tiene formato AAAA-MM-DD,
//   - cada proyecto tiene los campos mínimos (nombre, estado, bloqueos array),
//   - no se han perdido proyectos respecto a la "foto antes".
// Sale con código 1 solo si hay un fallo duro (JS inválido / falta datos.js).
// Lo demás se reporta como WARN. Resultado esperado tras sincronizar: PASS.
// ============================================================================
const fs = require('fs');
const path = require('path');
const { findDatosNegocio, loadDatos, backupsDir } = require('./lib');

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const ESTADOS = new Set(['pendiente', 'en_curso', 'completada']);

function main() {
  const warns = [];

  const datosPath = findDatosNegocio();
  if (!datosPath || !fs.existsSync(datosPath)) {
    console.error('FAIL: no encuentro BUILD/dashboard-negocio/datos.js.');
    process.exit(1);
  }

  let datos;
  try {
    datos = loadDatos(datosPath);
  } catch (e) {
    console.error('FAIL: datos.js no es válido: ' + e.message);
    console.error('Restaura la copia de .backups/ y revisa la edición.');
    process.exit(1);
  }

  if (!Array.isArray(datos.proyectos)) {
    console.error('FAIL: window.DATOS.proyectos no es una lista.');
    process.exit(1);
  }

  // Fecha principal.
  if (!datos.actualizado || !DATE_RE.test(datos.actualizado)) {
    warns.push(`"actualizado" no tiene formato AAAA-MM-DD: ${datos.actualizado}`);
  }

  // Campos mínimos por proyecto.
  datos.proyectos.forEach((p, i) => {
    if (!p.nombre) warns.push(`proyecto[${i}] sin "nombre"`);
    if (!ESTADOS.has(p.estado)) warns.push(`proyecto[${i}] ("${p.nombre || p.id || i}") estado inválido: ${p.estado}`);
    if (!Array.isArray(p.bloqueos)) warns.push(`proyecto[${i}] ("${p.nombre || p.id || i}") "bloqueos" no es una lista`);
    if (p.avance != null && (typeof p.avance !== 'number' || p.avance < 0 || p.avance > 100)) {
      warns.push(`proyecto[${i}] ("${p.nombre || p.id || i}") "avance" fuera de 0-100: ${p.avance}`);
    }
    if (p.actualizado && !DATE_RE.test(p.actualizado)) {
      warns.push(`proyecto[${i}] ("${p.nombre || p.id || i}") "actualizado" mal formada: ${p.actualizado}`);
    }
  });

  // Comparación con la foto antes (no perder proyectos).
  const snapFile = path.join(backupsDir(datosPath), '_snapshot-negocio-antes.json');
  if (fs.existsSync(snapFile)) {
    try {
      const before = JSON.parse(fs.readFileSync(snapFile, 'utf8'));
      const disco = before.proyectosEnDisco;
      if (typeof disco === 'number' && datos.proyectos.length < disco) {
        warns.push(`hay ${disco} proyectos en Proyectos/ pero solo ${datos.proyectos.length} en datos.js (¿alguno sin volcar?)`);
      }
      if (typeof before.proyectosAntes === 'number' && datos.proyectos.length < before.proyectosAntes) {
        warns.push(`datos.js pasó de ${before.proyectosAntes} a ${datos.proyectos.length} proyectos (¿pérdida?)`);
      }
    } catch (e) {
      warns.push('no pude leer la foto antes (_snapshot-negocio-antes.json).');
    }
  } else {
    warns.push('no hay foto previa: ejecuta negocio-preparar.js antes.');
  }

  // Marcadores sin resolver.
  const raw = fs.readFileSync(datosPath, 'utf8');
  if (/\{\{.*?\}\}/.test(raw)) {
    warns.push('quedan marcadores {{...}} sin resolver en datos.js');
  }

  // Resultado.
  console.log('Dashboard:   ' + datosPath);
  console.log('Negocio:     ' + (datos.negocio || '(sin nombre)'));
  console.log('actualizado: ' + (datos.actualizado || '(sin fecha)'));
  console.log('Proyectos:   ' + datos.proyectos.length);
  if (warns.length === 0) {
    console.log('\nPASS — datos.js válido, cartera coherente y fecha en formato correcto.');
  } else {
    console.log('\nWARN — revisa estos puntos:');
    for (const w of warns) console.log('  - ' + w);
  }
}

main();
